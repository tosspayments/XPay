#!/usr/bin/env bash
# Java 샘플을 JDK 별 배포용 zip 으로 묶는다.
#   dist/xpay-samples-java-jdk1.8-17.zip : XPayClient 4.1.0.0 (JDK 1.8 ~ 17), mall.conf 에 tx_version = 4
#   dist/xpay-samples-java-jdk1.7.zip    : XPayClient 4.1.0.0 (JDK 1.7 전용), mall.conf 에 tx_version 없음
#
# 사용법: tools/package-java.sh   (저장소 루트 어디에서 실행해도 됨, zip 명령 필요)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
JAVA="$ROOT/java"
OUT="$ROOT/dist"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
mkdir -p "$OUT"

package() {  # name  lib-dir-or-empty  mall.conf.example-source
  local name=$1 libsrc=$2 conf=$3
  local dst="$WORK/$name"
  mkdir -p "$dst/lgdacom/conf" "$dst/lgdacom/log"
  cp "$JAVA/README.md" "$dst/README.md"
  cp "$JAVA/lgdacom/conf/lgdacom.conf" "$dst/lgdacom/conf/"
  cp "$JAVA/lgdacom/conf/$conf" "$dst/lgdacom/conf/mall.conf.example"
  cp -R "$JAVA/webapp" "$dst/webapp"
  if [ -n "$libsrc" ]; then
    rm -f "$dst/webapp/WEB-INF/lib/"*.jar
    cp "$JAVA/$libsrc/"*.jar "$dst/webapp/WEB-INF/lib/"
  fi
  find "$dst" -name '.DS_Store' -delete
  rm -f "$OUT/$name.zip"
  (cd "$WORK" && zip -qr -X "$OUT/$name.zip" "$name")
  echo "created dist/$name.zip"
}

package xpay-samples-java-jdk1.8-17 ""           mall.conf.example
package xpay-samples-java-jdk1.7    lib-jdk1.7   mall.conf.jdk1.7.example
