<%@ CodePage=65001 Language="VBScript" %>
<%
Response.CharSet = "UTF-8"
%>
<%
' [빌링키 확인 페이지]  토스페이먼츠 XPay — UTF-8
'
' 인증 결과와 발급된 빌링키(LGD_BILLKEY)를 확인하고 저장한다.
' 빌링키는 카드 정보에 준하는 민감 정보이므로 암호화해서 저장하고 화면이나 로그에 남기지 않는다.
' 이후 결제는 card-billing 샘플처럼 LGD_PAN 에 빌링키를 넣어 CardAuth 로 요청한다.
%>
<%

    LGD_RESPCODE = Request.Form("LGD_RESPCODE")
    LGD_BILLKEY = Request.Form("LGD_BILLKEY")
    success = LGD_RESPCODE = "0000" And LGD_BILLKEY <> ""

    If success Then
        ' 인증 성공. LGD_BILLKEY 를 구매자 정보와 함께 암호화해서 DB 에 저장하세요.
    Else
        ' 인증 실패 결과를 기록하세요.
    End If

' ==================================================================
' 인증 응답 파라미터
' ==================================================================
' 주요 값은 활성, 나머지는 주석 처리해 두었습니다.
' 필요한 줄의 ' 만 지우면 화면에 함께 출력됩니다.
    Set show = Server.CreateObject("Scripting.Dictionary")
        show.Add "LGD_RESPCODE", "응답코드. 0000 이면 성공"
        show.Add "LGD_RESPMSG", "응답메시지. 최대 160자"
        show.Add "LGD_BILLKEY", "빌링키. 최대 128자. 이후 결제 시 카드번호 대신 사용"
        show.Add "LGD_PAYTYPE", "결제수단코드"
        show.Add "LGD_PAYDATE", "인증일시. yyyyMMddHHmmss"
        show.Add "LGD_FINANCECODE", "결제기관코드"
        show.Add "LGD_FINANCENAME", "결제기관명"

        ' ===== 카드 추가정보 =====
        ' show.Add "LGD_MID", "상점아이디"
        ' show.Add "LGD_CARDNUM", "신용카드번호. 일반 가맹점은 * 처리"
        ' show.Add "LGD_CARDGUBUN1", "0 개인 / 1 법인 / 9 미확인"
        ' show.Add "LGD_CARDGUBUN2", "0 신용 / 1 체크 / 2 기프트 / 9 미확인"
        ' show.Add "LGD_CARDACQUIRER", "카드 매입사 코드"
%>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>XPay 빌링키 발급 결과</title>
<style>
  body { font-family: sans-serif; font-size: 14px; max-width: 860px; margin: 20px; }
  table { border-collapse: collapse; }
  th, td { border: 1px solid #ccc; padding: 4px 8px; text-align: left; vertical-align: top; }
</style>
</head>
<body>

<h1>빌링키 발급 결과</h1>

<p><% If success Then Response.Write "빌링키 발급 성공" Else Response.Write "빌링키 발급 실패" %></p>

<table>
  <tr><th>변수명</th><th>설명</th><th>값</th></tr>
<% For Each k In show.Keys
       v = Request.Form(k)
%>
  <tr>
    <th><%= k %></th>
    <td><%= show(k) %></td>
    <td><%= v %></td>
  </tr>
<% Next %>
</table>

<p>이 페이지는 샘플입니다. 실제 연동에서는 빌링키를 화면에 노출하지 말고 암호화해서 저장하세요.</p>

</body>
</html>
