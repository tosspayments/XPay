<%@ CodePage=65001 Language="VBScript" %>
<%
Response.CharSet = "UTF-8"
%>
<%
' [최종 결제요청 페이지 (STEP 2-2)]  토스페이먼츠 XPay (PC용) — UTF-8
'
' 결제창에서 받은 LGD_PAYKEY(인증키)로 최종 결제를 요청한다.
' 승인결과 응답 파라미터는 아래 show 배열에 기재해 두었다.
' - 공통 파라미터는 그대로 화면에 출력
' - 결제수단별 파라미터는 주석 처리. 필요한 줄의 ' 만 지우면 된다.
%>
<%

    ' ---- 상점 설정 ★ 이 줄만 수정하세요 ----------------------------------

    ' 토스페이먼츠에서 제공한 환경파일(conf/lgdacom.conf, conf/mall.conf) 디렉터리
    configPath = "C:/lgdacom"

    ' ---- 최종 결제요청 ---------------------------------------------------

    CST_PLATFORM = Request.Form("CST_PLATFORM")   ' test 또는 service
    If CST_PLATFORM = "test" Then
        LGD_MID = "t" & Request.Form("CST_MID")
    Else
        LGD_MID = Request.Form("CST_MID")
    End If

    LGD_PAYKEY = Request.Form("LGD_PAYKEY")

    ' CST_PLATFORM 값에 따라 lgdacom.conf 의 test_url / url 이 선택된다.
    Set xpay = Server.CreateObject("XPayClientCOM.XPayClient")
    ' Init, Init_TX 는 성공하면 1, 실패하면 0 을 돌려준다. (VBScript 의 Not 은 비트 연산이므로 값으로 비교한다.)
    If xpay.Init(configPath, CST_PLATFORM) = 0 Or xpay.Init_TX(LGD_MID) = 0 Then
        Response.ContentType = "text/plain"
        Response.Write "환경파일 또는 상점아이디 설정을 확인하세요: " & xpay.resMsg
        Response.End
    End If
    xpay.Set "LGD_TXNAME", "PaymentByKey"
    xpay.Set "LGD_PAYKEY", LGD_PAYKEY

' 금액 위변조를 검증하려면 아래 주석을 푸세요.
' 금액은 반드시 위변조가 불가능한 곳(DB 또는 세션)에서 가져와야 합니다.
' 
' xpay.Set("LGD_AMOUNTCHECKYN", "Y");
' xpay.Set("LGD_AMOUNT", DB_AMOUNT);

    txOk     = (xpay.TX() = 1)   ' lgdacom.conf 의 URL 로 통신
    respCode = xpay.resCode
    respMsg = xpay.resMsg

    ' 응답 상세
    Set fields = Server.CreateObject("Scripting.Dictionary")
    For i = 0 To xpay.resNameCount - 1
        name = xpay.ResponseName(i)
        fields.Add name, xpay.Response(name, 0)
    Next

    ' 통신 성공이고 응답코드 "0000" 일 때만 결제 성공. 그 외는 모두 실패로 DB 처리한다.
    paid = txOk And respCode = "0000"

    If paid Then
        ' 결제 성공 DB 처리를 여기에서 수행하세요.
        isDBOK = true
        If Not isDBOK Then
            ' 결제는 성공했지만 상점 DB 처리에 실패했다면 자동취소를 요청합니다.
            xpay.Rollback "상점 DB 처리 실패 [TID:" & fields("LGD_TID") & ", OID:" & fields("LGD_OID") & "]"
        End If
    Else
        ' 결제 실패 DB 처리를 여기에서 수행하세요.
    End If

' ==================================================================
' 승인결과 응답 파라미터
' ==================================================================
' 공통은 활성, 결제수단별은 주석 처리해 두었습니다.
' 필요한 줄의 ' 만 지우면 화면에 함께 출력됩니다.
    Set show = Server.CreateObject("Scripting.Dictionary")

        ' ===== 공통 =====
        show.Add "LGD_RESPCODE", "응답코드. 최대 4자"
        show.Add "LGD_RESPMSG", "응답메시지. 최대 512자"
        show.Add "LGD_MID", "토스페이먼츠 발급 아이디. 최대 15자"
        show.Add "LGD_OID", "이용업체 거래번호(주문번호). 최대 64자"
        show.Add "LGD_AMOUNT", "결제금액. 최대 12자"
        show.Add "LGD_TID", "토스페이먼츠 거래번호. 최대 24자"
        show.Add "LGD_PAYTYPE", "결제수단. 최대 6자"
        show.Add "LGD_PAYDATE", "결제일시. yyyyMMddHHmmss 형식"
        show.Add "LGD_HASHDATA", "해쉬데이타"
        show.Add "LGD_TIMESTAMP", "타임스탬프. 결제요청 시 값을 리턴, 없으면 자동생성"
        show.Add "LGD_BUYER", "구매자명. 최대 10자"
        show.Add "LGD_PRODUCTINFO", "구매내역. 최대 128자"
        show.Add "LGD_BUYERID", "구매자아이디. 최대 15자"
        show.Add "LGD_BUYERADDRESS", "구매자주소. 최대 128자"
        show.Add "LGD_BUYERPHONE", "구매자휴대폰번호. 최대 15자"
        show.Add "LGD_BUYEREMAIL", "구매자메일. 최대 40자"
        show.Add "LGD_PRODUCTCODE", "상품코드. 최대 40자"
        show.Add "LGD_RECEIVER", "수취인. 최대 10자"
        show.Add "LGD_RECEIVERPHONE", "수취인전화번호. 최대 15자"
        show.Add "LGD_DELIVERYINFO", "배송정보. 최대 128자"
        show.Add "LGD_FINANCECODE", "결제기관코드. 최대 10자"
        show.Add "LGD_FINANCENAME", "결제기관명. 최대 20자"
        show.Add "LGD_ESCROWYN", "에스크로적용유무. 최대 1자"
        show.Add "LGD_TRANSAMOUNT", "환율적용금액"
        show.Add "LGD_EXCHANGERATE", "적용환율"

        ' ===== 신용카드 · 문화상품권 · 스마트문화상품권 · 도서문화상품권 =====
        ' show.Add "LGD_FINANCEAUTHNUM", "결제기관승인번호. 최대 20자"

        ' ===== 신용카드 =====
        ' show.Add "LGD_CARDNUM", "신용카드번호. 최대 20자"
        ' show.Add "LGD_CARDINSTALLMONTH", "신용카드할부개월. save 포인트는 할부개월+40, 포인트 결제는 +60, 현대카드 포인트는 +80"
        ' show.Add "LGD_CARDNOINTYN", "신용카드무이자여부. 0 일반할부 / 1 무이자할부"
        ' show.Add "LGD_AFFILIATECODE", "신용카드제휴코드. ISP만 제공됨. 최대 10자"
        ' show.Add "LGD_CARDGUBUN1", "신용카드추가정보1. 0 개인 / 1 법인 / 9 미확인"
        ' show.Add "LGD_CARDGUBUN2", "신용카드추가정보2. 0 신용 / 1 체크 / 2 기프트 / 9 미확인"
        ' show.Add "LGD_CARDACQUIRER", "신용카드매입사코드. 최대 2자"
        ' show.Add "LGD_PCANCELFLAG", "신용카드부분취소가능여부. 0 불가능 / 1 가능"
        ' show.Add "LGD_PCANCELSTR", "신용카드부분취소불가능사유. 부분취소 가능하면 ""0"" 리턴. 최대 128자"
        ' show.Add "LGD_DISCOUNTUSEYN", "신용카드 즉시할인 여부. 0 할인안됨 / 1 할인됨"
        ' show.Add "LGD_DISCOUNTUSEAMOUNT", "신용카드 즉시할인 금액. 최대 12자"

        ' ===== 계좌이체 =====
        ' show.Add "LGD_ACCOUNTOWNER", "계좌주명. 최대 40자"

        ' ===== 가상계좌 =====
        ' show.Add "LGD_ACCOUNTNUM", "가상계좌발급번호. 최대 20자"
        ' show.Add "LGD_PAYER", "가상계좌입금자명. 최대 40자"
        ' show.Add "LGD_CASTAMOUNT", "입금누적금액. 최대 12자"
        ' show.Add "LGD_CASCAMOUNT", "현입금금액. 최대 12자"
        ' show.Add "LGD_CASFLAG", "거래종류. R 할당 / I 입금 / C 취소"
        ' show.Add "LGD_CASSEQNO", "가상계좌일련번호. 최대 6자"
        ' show.Add "LGD_SAOWNER", "가상계좌 입금계좌주명. 상점명이 기본값으로 리턴. 최대 10자"
        ' show.Add "LGD_TELNO", "결제휴대폰번호. 최대 11자"

        ' ===== 계좌이체 · 가상계좌 : 현금영수증 =====
        ' show.Add "LGD_CASHRECEIPTNUM", "현금영수증승인번호. 최대 10자"
        ' show.Add "LGD_CASHRECEIPTSELFYN", "현금영수증자진발급제유무. Y 자진발급"
        ' show.Add "LGD_CASHRECEIPTKIND", "현금영수증종류. 0 소득공제 / 1 지출증빙"

        ' ===== OK캐쉬백 =====
        ' show.Add "LGD_OCBAMOUNT", "OK캐쉬백 사용금액"
        ' show.Add "LGD_OCBSAVEPOINT", "OK캐쉬백 적립포인트"
        ' show.Add "LGD_OCBTOTALPOINT", "OK캐쉬백 총누적포인트"
        ' show.Add "LGD_OCBUSABLEPOINT", "OK캐쉬백 사용가능포인트"
        ' show.Add "LGD_OCBTID", "OK캐쉬백 거래번호. LGD_TID 와 동일한 값이 추가로 리턴"
%>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>XPay 결제요청 결과</title>
<style>
  body { font-family: sans-serif; font-size: 14px; max-width: 860px; margin: 20px; }
  table { border-collapse: collapse; }
  th, td { border: 1px solid #ccc; padding: 4px 8px; text-align: left; vertical-align: top; }
</style>
</head>
<body>

<h1>최종 결제요청 결과</h1>

<% If Not txOk Then %>
  <p>통신 실패 — 결제요청을 완료하지 못했습니다. (<%= respCode %> <%= respMsg %>)</p>
<% ElseIf paid Then %>
  <p>결제 성공</p>
<% Else %>
  <p>결제 실패 (<%= respCode %> <%= respMsg %>)</p>
<% End If %>

<table>
  <tr><th>변수명</th><th>설명</th><th>값</th></tr>
<% For Each k In show.Keys
       v = ""
       If fields.Exists(k) Then v = fields(k)
%>
  <tr>
    <th><%= k %></th>
    <td><%= show(k) %></td>
    <td><%= v %></td>
  </tr>
<% Next %>
</table>

<%
' 명세에 없는 값까지 전부 확인하려면 아래 주석을 푸세요.
' 
' Response.Write("<h2>수신된 전체 응답</h2><table>");
' foreach (KeyValuePair<string, string> e in fields) {
' Response.Write("<tr><th>" + e.Key + "</th><td>" + e.Value + "</td></tr>");
' }
' Response.Write("</table>");
' 
%>

<p>이 페이지는 샘플입니다. 실제 연동에서는 결과를 화면에 노출하지 말고 DB에 기록하세요.</p>

</body>
</html>
