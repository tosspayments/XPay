# 통합결제창 결제 (PC)

결제창을 iframe으로 열어 인증한 뒤, XPayClient로 최종 승인(`PaymentByKey`)을 요청합니다.

## 흐름

```text
sample_crossplatform.html → payreq_crossplatform.asp → (통합결제창) → returnurl.asp → payres.asp
```

## 수정할 곳

| 파일 | 내용 |
| --- | --- |
| `payreq_crossplatform.asp` | `configPath`. "상점 설정"의 `LGD_RETURNURL`, `LGD_CASNOTEURL`을 실제 주소로 바꿉니다. 선택 파라미터는 폼 안 주석을 풀어 사용합니다. |
| `payres.asp` | `configPath`. 결제 성공·실패 DB 처리를 구현합니다. DB 처리에 실패하면 `Rollback()`으로 자동취소합니다. |

선택 파라미터는 모두 주석으로 들어 있습니다. 필요한 줄의 주석을 풀고, 입력 화면에도 같은 이름의 입력란을 추가합니다.

> **참고**
> 인증요청용 폼(`LGD_PAYINFO`)과 최종 결제요청용 폼(`LGD_PAYRES`)을 분리했습니다. 결제창 스크립트가 `LGD_PAYINFO`의 action을 덮어쓰기 때문입니다.

## 연동 가이드

통합결제창 결제, XPayClient 호출 패턴(결제창 결제 - PC)
