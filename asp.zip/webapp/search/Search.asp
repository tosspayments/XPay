<%@ CodePage=65001 Language="VBScript" %>
<%
Response.CharSet = "UTF-8"
%>
<%
' [거래 조회 요청 페이지]  토스페이먼츠 XPay — UTF-8
'
' 거래번호 또는 주문번호로 거래를 조회한다.
%>
<%

    ' ---- 상점 설정 ★ 이 줄만 수정하세요 ----------------------------------

    ' 토스페이먼츠에서 제공한 환경파일(conf/lgdacom.conf, conf/mall.conf) 디렉터리
    configPath = "C:/lgdacom"

    ' ---- 요청 파라미터 ---------------------------------------------------

    CST_PLATFORM = Request.Form("CST_PLATFORM")   ' test 또는 service
    If CST_PLATFORM = "test" Then   ' 테스트는 앞에 't'
        LGD_MID = "t" & Request.Form("CST_MID")
    Else
        LGD_MID = Request.Form("CST_MID")
    End If
    LGD_OID = Request.Form("LGD_OID")
    LGD_TID = Request.Form("LGD_TID")
    LGD_PAYTYPE = Request.Form("LGD_PAYTYPE")

    ' ---- 요청 -----------------------------------------------------------

    ' CST_PLATFORM 값에 따라 lgdacom.conf 의 test_url / url 이 선택된다.
    Set xpay = Server.CreateObject("XPayClientCOM.XPayClient")
    ' Init, Init_TX 는 성공하면 1, 실패하면 0 을 돌려준다. (VBScript 의 Not 은 비트 연산이므로 값으로 비교한다.)
    If xpay.Init(configPath, CST_PLATFORM) = 0 Or xpay.Init_TX(LGD_MID) = 0 Then
        Response.ContentType = "text/plain"
        Response.Write "환경파일 또는 상점아이디 설정을 확인하세요: " & xpay.resMsg
        Response.End
    End If

    xpay.Set "LGD_TXNAME", "Search"   ' 거래 조회
    xpay.Set "LGD_OID", LGD_OID   ' 주문번호
    xpay.Set "LGD_TID", LGD_TID   ' 토스페이먼츠 거래번호
    xpay.Set "LGD_PAYTYPE", LGD_PAYTYPE   ' 결제수단코드
    xpay.Set "LGD_BUYERIP", Request.ServerVariables("REMOTE_ADDR")   ' 요청한 구매자 IP

    txOk     = (xpay.TX() = 1)   ' lgdacom.conf 의 URL 로 통신
    respCode = xpay.resCode
    respMsg = xpay.resMsg

    ' 응답 상세
    Set fields = Server.CreateObject("Scripting.Dictionary")
    For i = 0 To xpay.resNameCount - 1
        name = xpay.ResponseName(i)
        fields.Add name, xpay.Response(name, 0)
    Next

    ' 통신 성공이고 응답코드 "0000" 일 때만 성공. 그 외는 모두 실패로 처리한다.
    success = txOk And respCode = "0000"

    If success Then
        ' 성공 결과를 DB 에 반영하세요.
    Else
        ' 실패 결과를 DB 에 기록하세요.
    End If

' ==================================================================
' 응답 파라미터
' ==================================================================
' 주요 값은 활성, 나머지는 주석 처리해 두었습니다.
' 필요한 줄의 ' 만 지우면 화면에 함께 출력됩니다.
    Set show = Server.CreateObject("Scripting.Dictionary")

        show.Add "LGD_RESPCODE", "응답코드. 0000 이면 성공"
        show.Add "LGD_RESPMSG", "응답메시지"
        show.Add "LGD_MID", "상점아이디"
        show.Add "LGD_TID", "토스페이먼츠 거래번호"
        show.Add "LGD_OID", "주문번호"
        show.Add "LGD_PAYTYPE", "결제수단코드"
%>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>거래 조회 결과</title>
<style>
  body { font-family: sans-serif; font-size: 14px; max-width: 860px; margin: 20px; }
  table { border-collapse: collapse; }
  th, td { border: 1px solid #ccc; padding: 4px 8px; text-align: left; vertical-align: top; }
</style>
</head>
<body>

<h1>거래 조회 결과</h1>

<% If Not txOk Then %>
  <p>통신 실패 — 요청을 완료하지 못했습니다. (<%= respCode %> <%= respMsg %>)</p>
<% ElseIf success Then %>
  <p>조회 성공</p>
<% Else %>
  <p>조회 실패 (<%= respCode %> <%= respMsg %>)</p>
<% End If %>

<table>
  <tr><th>변수명</th><th>설명</th><th>값</th></tr>
<% For Each k In show.Keys
       v = ""
       If fields.Exists(k) Then v = fields(k)
%>
  <tr>
    <th><%= k %></th>
    <td><%= show(k) %></td>
    <td><%= v %></td>
  </tr>
<% Next %>
</table>

<%
' 명세에 없는 값까지 전부 확인하려면 아래 주석을 푸세요.
' 
' Response.Write("<h2>수신된 전체 응답</h2><table>");
' foreach (KeyValuePair<string, string> e in fields) {
' Response.Write("<tr><th>" + e.Key + "</th><td>" + e.Value + "</td></tr>");
' }
' Response.Write("</table>");
' 
%>

<p>이 페이지는 샘플입니다. 실제 연동에서는 결과를 화면에 노출하지 말고 DB에 기록하세요.</p>

</body>
</html>
