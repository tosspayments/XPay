<%@ CodePage=65001 Language="VBScript" %>
<%
Response.CharSet = "UTF-8"
%>
<%
' [계좌 유효성 확인 요청 페이지]  토스페이먼츠 XPay — UTF-8
'
' 계좌번호와 예금주명이 일치하는지 AccCert 거래로 확인한다.
%>
<%

    ' ---- 상점 설정 ★ 이 줄만 수정하세요 ----------------------------------

    ' 토스페이먼츠에서 제공한 환경파일(conf/lgdacom.conf, conf/mall.conf) 디렉터리
    configPath = "C:/lgdacom"

    ' ---- 요청 파라미터 ---------------------------------------------------

    CST_PLATFORM = Request.Form("CST_PLATFORM")   ' test 또는 service
    If CST_PLATFORM = "test" Then   ' 테스트는 앞에 't'
        LGD_MID = "t" & Request.Form("CST_MID")
    Else
        LGD_MID = Request.Form("CST_MID")
    End If
    LGD_GUBUN = Request.Form("LGD_GUBUN")
    LGD_BANKCODE = Request.Form("LGD_BANKCODE")
    LGD_ACCOUNTNO = Request.Form("LGD_ACCOUNTNO")
    LGD_NAME = Request.Form("LGD_NAME")
    LGD_PRIVATENO = Request.Form("LGD_PRIVATENO")

    ' ---- 요청 -----------------------------------------------------------

    ' CST_PLATFORM 값에 따라 lgdacom.conf 의 test_url / url 이 선택된다.
    Set xpay = Server.CreateObject("XPayClientCOM.XPayClient")
    ' Init, Init_TX 는 성공하면 1, 실패하면 0 을 돌려준다. (VBScript 의 Not 은 비트 연산이므로 값으로 비교한다.)
    If xpay.Init(configPath, CST_PLATFORM) = 0 Or xpay.Init_TX(LGD_MID) = 0 Then
        Response.ContentType = "text/plain"
        Response.Write "환경파일 또는 상점아이디 설정을 확인하세요: " & xpay.resMsg
        Response.End
    End If

    xpay.Set "LGD_TXNAME", "AccCert"   ' 계좌 유효성 확인
    xpay.Set "LGD_GUBUN", LGD_GUBUN   ' 확인 구분. 2 ~ 6
    xpay.Set "LGD_BANKCODE", LGD_BANKCODE   ' 은행코드
    xpay.Set "LGD_ACCOUNTNO", LGD_ACCOUNTNO   ' 계좌번호
    xpay.Set "LGD_NAME", LGD_NAME   ' 예금주명. 구분 2, 3 필수
    xpay.Set "LGD_PRIVATENO", LGD_PRIVATENO   ' 생년월일 또는 사업자번호. 구분 3, 5 필수
    xpay.Set "LGD_BUYERIP", Request.ServerVariables("REMOTE_ADDR")   ' 요청한 구매자 IP

    ' ---- 선택 파라미터 : 필요한 줄의 주석만 푸세요 (입력 화면에도 같은 이름의 입력란을 추가) ----
    ' xpay.Set "LGD_CHECKNHYN", Request.Form("LGD_CHECKNHYN")   ' Y: 은행코드 011, 012 일 때 농협 중앙회·단위조합 여부 확인

    txOk     = (xpay.TX() = 1)   ' lgdacom.conf 의 URL 로 통신
    respCode = xpay.resCode
    respMsg = xpay.resMsg

    ' 응답 상세
    Set fields = Server.CreateObject("Scripting.Dictionary")
    For i = 0 To xpay.resNameCount - 1
        name = xpay.ResponseName(i)
        fields.Add name, xpay.Response(name, 0)
    Next

    ' 통신 성공이고 응답코드 "0000" 일 때만 성공. 그 외는 모두 실패로 처리한다.
    success = txOk And respCode = "0000"

    If success Then
        ' 성공 결과를 DB 에 반영하세요.
    Else
        ' 실패 결과를 DB 에 기록하세요.
    End If

' ==================================================================
' 응답 파라미터
' ==================================================================
' 주요 값은 활성, 나머지는 주석 처리해 두었습니다.
' 필요한 줄의 ' 만 지우면 화면에 함께 출력됩니다.
    Set show = Server.CreateObject("Scripting.Dictionary")

        show.Add "LGD_RESPCODE", "응답코드. 0000 이면 성공"
        show.Add "LGD_RESPMSG", "응답메시지"
        show.Add "LGD_TID", "토스페이먼츠 거래번호"
        show.Add "LGD_FINANCECODE", "은행코드"
        show.Add "LGD_FINANCENAME", "은행명"
        show.Add "LGD_NAME", "예금주명. 구분 2, 3, 6 일 때"

        ' ===== 기타 =====
        ' show.Add "LGD_MID", "상점아이디"
%>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>계좌 유효성 확인 결과</title>
<style>
  body { font-family: sans-serif; font-size: 14px; max-width: 860px; margin: 20px; }
  table { border-collapse: collapse; }
  th, td { border: 1px solid #ccc; padding: 4px 8px; text-align: left; vertical-align: top; }
</style>
</head>
<body>

<h1>계좌 유효성 확인 결과</h1>

<% If Not txOk Then %>
  <p>통신 실패 — 요청을 완료하지 못했습니다. (<%= respCode %> <%= respMsg %>)</p>
<% ElseIf success Then %>
  <p>확인 성공</p>
<% Else %>
  <p>확인 실패 (<%= respCode %> <%= respMsg %>)</p>
<% End If %>

<table>
  <tr><th>변수명</th><th>설명</th><th>값</th></tr>
<% For Each k In show.Keys
       v = ""
       If fields.Exists(k) Then v = fields(k)
%>
  <tr>
    <th><%= k %></th>
    <td><%= show(k) %></td>
    <td><%= v %></td>
  </tr>
<% Next %>
</table>

<%
' 명세에 없는 값까지 전부 확인하려면 아래 주석을 푸세요.
' 
' Response.Write("<h2>수신된 전체 응답</h2><table>");
' foreach (KeyValuePair<string, string> e in fields) {
' Response.Write("<tr><th>" + e.Key + "</th><td>" + e.Value + "</td></tr>");
' }
' Response.Write("</table>");
' 
%>

<p>이 페이지는 샘플입니다. 실제 연동에서는 결과를 화면에 노출하지 말고 DB에 기록하세요.</p>

</body>
</html>
