<%@ CodePage=65001 Language="VBScript" %>
<%
Response.CharSet = "UTF-8"
%>
<%
' [카드 비인증 결제 요청 페이지]  토스페이먼츠 XPay — UTF-8
'
' 카드번호를 직접 받아 CardAuth 거래로 승인을 요청한다.
' 결제는 성공했지만 상점 DB 처리에 실패하면 Rollback() 으로 자동취소한다.
%>
<%

    ' ---- 상점 설정 ★ 이 줄만 수정하세요 ----------------------------------

    ' 토스페이먼츠에서 제공한 환경파일(conf/lgdacom.conf, conf/mall.conf) 디렉터리
    configPath = "C:/lgdacom"

    ' ---- 요청 파라미터 ---------------------------------------------------

    CST_PLATFORM = Request.Form("CST_PLATFORM")   ' test 또는 service
    If CST_PLATFORM = "test" Then   ' 테스트는 앞에 't'
        LGD_MID = "t" & Request.Form("CST_MID")
    Else
        LGD_MID = Request.Form("CST_MID")
    End If
    LGD_OID = Request.Form("LGD_OID")
    LGD_AMOUNT = Request.Form("LGD_AMOUNT")
    LGD_BUYER = Request.Form("LGD_BUYER")
    LGD_PRODUCTINFO = Request.Form("LGD_PRODUCTINFO")
    LGD_PAN = Request.Form("LGD_PAN")
    LGD_INSTALL = Request.Form("LGD_INSTALL")
    VBV_ECI = Request.Form("VBV_ECI")
    LGD_EXPYEAR = Request.Form("LGD_EXPYEAR")
    LGD_EXPMON = Request.Form("LGD_EXPMON")

    ' ---- 요청 -----------------------------------------------------------

    ' CST_PLATFORM 값에 따라 lgdacom.conf 의 test_url / url 이 선택된다.
    Set xpay = Server.CreateObject("XPayClientCOM.XPayClient")
    ' Init, Init_TX 는 성공하면 1, 실패하면 0 을 돌려준다. (VBScript 의 Not 은 비트 연산이므로 값으로 비교한다.)
    If xpay.Init(configPath, CST_PLATFORM) = 0 Or xpay.Init_TX(LGD_MID) = 0 Then
        Response.ContentType = "text/plain"
        Response.Write "환경파일 또는 상점아이디 설정을 확인하세요: " & xpay.resMsg
        Response.End
    End If

    xpay.Set "LGD_TXNAME", "CardAuth"   ' 카드 승인
    xpay.Set "LGD_OID", LGD_OID   ' 주문번호. 최대 64자
    xpay.Set "LGD_AMOUNT", LGD_AMOUNT   ' 결제금액. 숫자만
    xpay.Set "LGD_PAN", LGD_PAN   ' 카드번호 (Swipe 는 트랙 데이터)
    xpay.Set "LGD_INSTALL", LGD_INSTALL   ' 할부개월. 00 일시불
    xpay.Set "VBV_ECI", VBV_ECI   ' 010 Key-in / 020 Swipe
    xpay.Set "LGD_BUYER", LGD_BUYER   ' 구매자명. 최대 10자
    xpay.Set "LGD_PRODUCTINFO", LGD_PRODUCTINFO   ' 상품명. 최대 128자
    xpay.Set "LGD_BUYERIP", Request.ServerVariables("REMOTE_ADDR")   ' 결제를 요청한 구매자 IP

    If VBV_ECI = "010" Then   ' Key-in 에만 해당
        xpay.Set "LGD_EXPYEAR", LGD_EXPYEAR   ' 유효기간 연. YY
        xpay.Set "LGD_EXPMON", LGD_EXPMON   ' 유효기간 월. MM
        ' 아래 두 값은 선택. LGD_PRIVATENO 를 보내지 않으면 비밀번호도 확인하지 않는다.
        ' xpay.Set "LGD_PIN", Request.Form("LGD_PIN")   ' 카드 비밀번호 앞 2자리
        ' xpay.Set "LGD_PRIVATENO", Request.Form("LGD_PRIVATENO")   ' 생년월일 6자리 또는 사업자번호 10자리
    End If

    ' ---- 선택 파라미터 : 필요한 줄의 주석만 푸세요 (입력 화면에도 같은 이름의 입력란을 추가) ----
    ' xpay.Set "LGD_BUYERID", Request.Form("LGD_BUYERID")   ' 구매자 아이디. 최대 15자
    ' xpay.Set "LGD_BUYERPHONE", Request.Form("LGD_BUYERPHONE")   ' 구매자 휴대폰번호. 최대 11자
    ' xpay.Set "LGD_BUYEREMAIL", Request.Form("LGD_BUYEREMAIL")   ' 구매자 이메일. 최대 40자
    ' xpay.Set "LGD_TAXFREEAMOUNT", Request.Form("LGD_TAXFREEAMOUNT")   ' 면세금액. 부분면세 계약 시
    ' xpay.Set "LGD_NOINT", "0"   ' 상점부담 무이자. 1 적용 / 0 일반할부 (별도 계약 필요)
    ' xpay.Set "LGD_POINTUSE", "N"   ' 포인트 사용. Y / N

    txOk     = (xpay.TX() = 1)   ' lgdacom.conf 의 URL 로 통신
    respCode = xpay.resCode
    respMsg = xpay.resMsg

    ' 응답 상세
    Set fields = Server.CreateObject("Scripting.Dictionary")
    For i = 0 To xpay.resNameCount - 1
        name = xpay.ResponseName(i)
        fields.Add name, xpay.Response(name, 0)
    Next

    ' 통신 성공이고 응답코드 "0000" 일 때만 성공. 그 외는 모두 실패로 처리한다.
    success = txOk And respCode = "0000"

    If success Then
        ' 결제 성공 DB 처리를 여기에서 수행하세요.
        isDBOK = true
        If Not isDBOK Then
            ' 결제는 성공했지만 상점 DB 처리에 실패했다면 자동취소를 요청합니다.
            xpay.Rollback "상점 DB 처리 실패 [TID:" & fields("LGD_TID") & ", OID:" & fields("LGD_OID") & "]"
        End If
    Else
        ' 결제 실패 DB 처리를 여기에서 수행하세요.
    End If

' ==================================================================
' 응답 파라미터
' ==================================================================
' 주요 값은 활성, 나머지는 주석 처리해 두었습니다.
' 필요한 줄의 ' 만 지우면 화면에 함께 출력됩니다.
    Set show = Server.CreateObject("Scripting.Dictionary")

        show.Add "LGD_RESPCODE", "응답코드. 0000 이면 성공"
        show.Add "LGD_RESPMSG", "응답메시지. 최대 160자"
        show.Add "LGD_MID", "상점아이디. 최대 15자"
        show.Add "LGD_OID", "주문번호. 최대 64자"
        show.Add "LGD_TID", "토스페이먼츠 거래번호. 최대 24자"
        show.Add "LGD_AMOUNT", "결제금액. 최대 12자"
        show.Add "LGD_PAYTYPE", "결제수단코드. 신용카드 SC0010"
        show.Add "LGD_PAYDATE", "결제일시. yyyyMMddHHmmss"
        show.Add "LGD_FINANCECODE", "결제기관코드. 최대 10자"
        show.Add "LGD_FINANCENAME", "결제기관명. 최대 20자"
        show.Add "LGD_FINANCEAUTHNUM", "결제기관 승인번호. 최대 20자"
        show.Add "LGD_CARDNUM", "신용카드번호. 일반 가맹점은 * 처리"
        show.Add "LGD_CARDINSTALLMONTH", "할부개월. 포인트 결제는 +60, 현대카드 포인트 +80, save 포인트 +40"

        ' ===== 구매자·상품 =====
        ' show.Add "LGD_BUYER", "구매자명"
        ' show.Add "LGD_BUYERID", "구매자 아이디"
        ' show.Add "LGD_BUYERPHONE", "구매자 휴대폰번호"
        ' show.Add "LGD_BUYEREMAIL", "구매자 이메일"
        ' show.Add "LGD_BUYERADDRESS", "구매자 주소"
        ' show.Add "LGD_BUYERSSN", "구매자 생년월일(또는 사업자번호)"
        ' show.Add "LGD_PRODUCTINFO", "상품명"
        ' show.Add "LGD_PRODUCTCODE", "상품코드"
        ' show.Add "LGD_RECEIVER", "수취인"
        ' show.Add "LGD_RECEIVERPHONE", "수취인 전화번호"

        ' ===== 카드 추가정보 =====
        ' show.Add "LGD_CARDACQUIRER", "카드 매입사 코드"
        ' show.Add "LGD_CARDGUBUN1", "0 개인 / 1 법인 / 9 미확인"
        ' show.Add "LGD_CARDGUBUN2", "0 신용 / 1 체크 / 2 기프트 / 9 미확인"
        ' show.Add "LGD_CARDNOINTEREST_YN", "카드사부담 무이자. 1 무이자 / 0 일반"
        ' show.Add "LGD_CARDNOINTYN", "상점부담 무이자. 1 무이자 / 0 일반"

        ' ===== 즉시할인·부분취소 =====
        ' show.Add "LGD_DCNO", "즉시할인 적용 거래면 DC"
        ' show.Add "LGD_DISCOUNTUSEYN", "즉시할인 적용. 1 적용 / 0 미적용"
        ' show.Add "LGD_DISCOUNTUSEAMOUNT", "즉시할인 금액"
        ' show.Add "LGD_PCANCELFLAG", "부분취소 가능. 1 가능 / 0 불가"
        ' show.Add "LGD_PCANCELSTR", "부분취소 불가 사유. 가능하면 0"

        ' ===== 기타 =====
        ' show.Add "LGD_TAXFREEAMOUNT", "면세금액"
        ' show.Add "LGD_ESCROWYN", "에스크로 적용. Y / N"
        ' show.Add "LGD_HASHDATA", "해쉬데이타"
        ' show.Add "LGD_TIMESTAMP", "타임스탬프"
%>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>카드 비인증 결제 요청 페이지 결과</title>
<style>
  body { font-family: sans-serif; font-size: 14px; max-width: 860px; margin: 20px; }
  table { border-collapse: collapse; }
  th, td { border: 1px solid #ccc; padding: 4px 8px; text-align: left; vertical-align: top; }
</style>
</head>
<body>

<h1>카드 비인증 결제 요청 페이지 결과</h1>

<% If Not txOk Then %>
  <p>통신 실패 — 요청을 완료하지 못했습니다. (<%= respCode %> <%= respMsg %>)</p>
<% ElseIf success Then %>
  <p>결제 성공</p>
<% Else %>
  <p>결제 실패 (<%= respCode %> <%= respMsg %>)</p>
<% End If %>

<table>
  <tr><th>변수명</th><th>설명</th><th>값</th></tr>
<% For Each k In show.Keys
       v = ""
       If fields.Exists(k) Then v = fields(k)
%>
  <tr>
    <th><%= k %></th>
    <td><%= show(k) %></td>
    <td><%= v %></td>
  </tr>
<% Next %>
</table>

<%
' 명세에 없는 값까지 전부 확인하려면 아래 주석을 푸세요.
' 
' Response.Write("<h2>수신된 전체 응답</h2><table>");
' foreach (KeyValuePair<string, string> e in fields) {
' Response.Write("<tr><th>" + e.Key + "</th><td>" + e.Value + "</td></tr>");
' }
' Response.Write("</table>");
' 
%>

<p>이 페이지는 샘플입니다. 실제 연동에서는 결과를 화면에 노출하지 말고 DB에 기록하세요.</p>

</body>
</html>
