<%@ CodePage=65001 Language="VBScript" %>
<%
Response.CharSet = "UTF-8"
%>
<%
' [현금영수증 발급·취소 요청 페이지]  토스페이먼츠 XPay — UTF-8
'
' LGD_METHOD 로 발급(AUTH)과 취소(CANCEL)를 나누고, 결제수단(LGD_PAYTYPE)에 따라 보내는 값이 다르다.
%>
<%

    ' ---- 상점 설정 ★ 이 줄만 수정하세요 ----------------------------------

    ' 토스페이먼츠에서 제공한 환경파일(conf/lgdacom.conf, conf/mall.conf) 디렉터리
    configPath = "C:/lgdacom"

    ' ---- 요청 파라미터 ---------------------------------------------------

    CST_PLATFORM = Request.Form("CST_PLATFORM")   ' test 또는 service
    If CST_PLATFORM = "test" Then   ' 테스트는 앞에 't'
        LGD_MID = "t" & Request.Form("CST_MID")
    Else
        LGD_MID = Request.Form("CST_MID")
    End If
    LGD_METHOD = Request.Form("LGD_METHOD")
    LGD_PAYTYPE = Request.Form("LGD_PAYTYPE")
    LGD_OID = Request.Form("LGD_OID")
    LGD_AMOUNT = Request.Form("LGD_AMOUNT")
    LGD_TID = Request.Form("LGD_TID")
    LGD_CASHCARDNUM = Request.Form("LGD_CASHCARDNUM")
    LGD_CASHRECEIPTUSE = Request.Form("LGD_CASHRECEIPTUSE")
    LGD_CUSTOM_MERTNAME = Request.Form("LGD_CUSTOM_MERTNAME")
    LGD_CUSTOM_BUSINESSNUM = Request.Form("LGD_CUSTOM_BUSINESSNUM")
    LGD_CUSTOM_MERTPHONE = Request.Form("LGD_CUSTOM_MERTPHONE")
    LGD_PRODUCTINFO = Request.Form("LGD_PRODUCTINFO")

    ' ---- 요청 -----------------------------------------------------------

    ' CST_PLATFORM 값에 따라 lgdacom.conf 의 test_url / url 이 선택된다.
    Set xpay = Server.CreateObject("XPayClientCOM.XPayClient")
    ' Init, Init_TX 는 성공하면 1, 실패하면 0 을 돌려준다. (VBScript 의 Not 은 비트 연산이므로 값으로 비교한다.)
    If xpay.Init(configPath, CST_PLATFORM) = 0 Or xpay.Init_TX(LGD_MID) = 0 Then
        Response.ContentType = "text/plain"
        Response.Write "환경파일 또는 상점아이디 설정을 확인하세요: " & xpay.resMsg
        Response.End
    End If

    xpay.Set "LGD_TXNAME", "CashReceipt"   ' 현금영수증
    xpay.Set "LGD_METHOD", LGD_METHOD   ' AUTH 발급 / CANCEL 취소
    xpay.Set "LGD_PAYTYPE", LGD_PAYTYPE   ' SC0030 계좌이체 / SC0040 가상계좌 / SC0100 무통장입금 단독

    If LGD_METHOD = "AUTH" Then   ' 현금영수증 발급
        xpay.Set "LGD_OID", LGD_OID   ' 주문번호. 최대 64자
        xpay.Set "LGD_AMOUNT", LGD_AMOUNT   ' 금액
        xpay.Set "LGD_CASHCARDNUM", LGD_CASHCARDNUM   ' 발급번호. 최대 20자
        xpay.Set "LGD_CASHRECEIPTUSE", LGD_CASHRECEIPTUSE   ' 1 소득공제 / 2 지출증빙
        xpay.Set "LGD_CUSTOM_MERTNAME", LGD_CUSTOM_MERTNAME   ' 상점명. 최대 20자
        xpay.Set "LGD_CUSTOM_BUSINESSNUM", LGD_CUSTOM_BUSINESSNUM   ' 사업자등록번호. 최대 10자
        xpay.Set "LGD_CUSTOM_MERTPHONE", LGD_CUSTOM_MERTPHONE   ' 상점 전화번호. 최대 11자

        If LGD_PAYTYPE = "SC0030" Then   ' 기결제된 계좌이체 건
            xpay.Set "LGD_TID", LGD_TID   ' 결제 때 받은 거래번호 (LGD_PAYKEY 아님)
        ElseIf LGD_PAYTYPE = "SC0040" Then   ' 기결제된 가상계좌 건
            xpay.Set "LGD_TID", LGD_TID
            xpay.Set "LGD_SEQNO", "001"   ' 가상계좌 일련번호. 001 고정
        Else   ' 무통장입금 단독 건
            xpay.Set "LGD_PRODUCTINFO", LGD_PRODUCTINFO   ' 상품명. 최대 128자
        End If

        ' ---- 선택 파라미터 : 필요한 줄의 주석만 푸세요 (입력 화면에도 같은 이름의 입력란을 추가) ----
        ' xpay.Set "LGD_CUSTOM_CEONAME", Request.Form("LGD_CUSTOM_CEONAME")   ' 상점 대표자명. 최대 12자
        ' xpay.Set "LGD_CUSTOM_MERTADDRESS", Request.Form("LGD_CUSTOM_MERTADDRESS")   ' 상점 주소. 최대 40자
        ' xpay.Set "LGD_TRADEDATE", Request.Form("LGD_TRADEDATE")   ' 발급일자. yyyyMMddhhmmss, 거래일로부터 최대 D-2
        ' xpay.Set "LGD_TAXFREEAMOUNT", Request.Form("LGD_TAXFREEAMOUNT")   ' 면세금액. 부분면세 계약 시
        ' xpay.Set "LGD_VAT", Request.Form("LGD_VAT")   ' 상점정의 부가세액
    Else   ' 현금영수증 취소
        xpay.Set "LGD_TID", LGD_TID   ' 취소할 현금영수증의 거래번호
        If LGD_PAYTYPE = "SC0040" Then   ' 가상계좌 건
            xpay.Set "LGD_SEQNO", "001"   ' 가상계좌 일련번호. 001 고정
        End If
    End If

    txOk     = (xpay.TX() = 1)   ' lgdacom.conf 의 URL 로 통신
    respCode = xpay.resCode
    respMsg = xpay.resMsg

    ' 응답 상세
    Set fields = Server.CreateObject("Scripting.Dictionary")
    For i = 0 To xpay.resNameCount - 1
        name = xpay.ResponseName(i)
        fields.Add name, xpay.Response(name, 0)
    Next

    ' 통신 성공이고 응답코드 "0000" 일 때만 성공. 그 외는 모두 실패로 처리한다.
    success = txOk And respCode = "0000"

    If success Then
        ' 성공 결과를 DB 에 반영하세요.
    Else
        ' 실패 결과를 DB 에 기록하세요.
    End If

' ==================================================================
' 응답 파라미터
' ==================================================================
' 주요 값은 활성, 나머지는 주석 처리해 두었습니다.
' 필요한 줄의 ' 만 지우면 화면에 함께 출력됩니다.
    Set show = Server.CreateObject("Scripting.Dictionary")

        show.Add "LGD_RESPCODE", "응답코드. 0000 이면 성공"
        show.Add "LGD_RESPMSG", "응답메시지"
        show.Add "LGD_OID", "주문번호"
        show.Add "LGD_TID", "토스페이먼츠 거래번호"
        show.Add "LGD_CASHRECEIPTNUM", "현금영수증 승인번호"
        show.Add "LGD_RESPDATE", "처리일시. YYYYMMDDhhmmss"
%>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>현금영수증 발급·취소 요청 페이지 결과</title>
<style>
  body { font-family: sans-serif; font-size: 14px; max-width: 860px; margin: 20px; }
  table { border-collapse: collapse; }
  th, td { border: 1px solid #ccc; padding: 4px 8px; text-align: left; vertical-align: top; }
</style>
</head>
<body>

<h1>현금영수증 발급·취소 요청 페이지 결과</h1>

<% If Not txOk Then %>
  <p>통신 실패 — 요청을 완료하지 못했습니다. (<%= respCode %> <%= respMsg %>)</p>
<% ElseIf success Then %>
  <p>처리 성공</p>
<% Else %>
  <p>처리 실패 (<%= respCode %> <%= respMsg %>)</p>
<% End If %>

<table>
  <tr><th>변수명</th><th>설명</th><th>값</th></tr>
<% For Each k In show.Keys
       v = ""
       If fields.Exists(k) Then v = fields(k)
%>
  <tr>
    <th><%= k %></th>
    <td><%= show(k) %></td>
    <td><%= v %></td>
  </tr>
<% Next %>
</table>

<%
' 명세에 없는 값까지 전부 확인하려면 아래 주석을 푸세요.
' 
' Response.Write("<h2>수신된 전체 응답</h2><table>");
' foreach (KeyValuePair<string, string> e in fields) {
' Response.Write("<tr><th>" + e.Key + "</th><td>" + e.Value + "</td></tr>");
' }
' Response.Write("</table>");
' 
%>

<p>이 페이지는 샘플입니다. 실제 연동에서는 결과를 화면에 노출하지 말고 DB에 기록하세요.</p>

</body>
</html>
