<%@ CodePage=65001 Language="VBScript" %>
<%
Response.CharSet = "UTF-8"
%>
<%
' [가상계좌 발급·변경 요청 페이지]  토스페이먼츠 XPay — UTF-8
'
' 가상계좌를 발급(ASSIGN)하거나 변경(CHANGE)한다. 입금 결과는 cas_noteurl.asp 로 받는다.
%>
<%

    ' ---- 상점 설정 ★ 이 줄만 수정하세요 ----------------------------------

    ' 토스페이먼츠에서 제공한 환경파일(conf/lgdacom.conf, conf/mall.conf) 디렉터리
    configPath = "C:/lgdacom"

    ' ---- 요청 파라미터 ---------------------------------------------------

    CST_PLATFORM = Request.Form("CST_PLATFORM")   ' test 또는 service
    If CST_PLATFORM = "test" Then   ' 테스트는 앞에 't'
        LGD_MID = "t" & Request.Form("CST_MID")
    Else
        LGD_MID = Request.Form("CST_MID")
    End If
    LGD_METHOD = Request.Form("LGD_METHOD")
    LGD_OID = Request.Form("LGD_OID")
    LGD_AMOUNT = Request.Form("LGD_AMOUNT")
    LGD_PRODUCTINFO = Request.Form("LGD_PRODUCTINFO")
    LGD_BUYER = Request.Form("LGD_BUYER")
    LGD_BANKCODE = Request.Form("LGD_BANKCODE")
    LGD_ACCOUNTOWNER = Request.Form("LGD_ACCOUNTOWNER")
    LGD_ACCOUNTPID = Request.Form("LGD_ACCOUNTPID")

    ' ---- 요청 -----------------------------------------------------------

    ' CST_PLATFORM 값에 따라 lgdacom.conf 의 test_url / url 이 선택된다.
    Set xpay = Server.CreateObject("XPayClientCOM.XPayClient")
    ' Init, Init_TX 는 성공하면 1, 실패하면 0 을 돌려준다. (VBScript 의 Not 은 비트 연산이므로 값으로 비교한다.)
    If xpay.Init(configPath, CST_PLATFORM) = 0 Or xpay.Init_TX(LGD_MID) = 0 Then
        Response.ContentType = "text/plain"
        Response.Write "환경파일 또는 상점아이디 설정을 확인하세요: " & xpay.resMsg
        Response.End
    End If

    ' 가상계좌 결과수신 페이지(LGD_CASNOTEURL). 실제 주소로 바꾸세요. 표준포트(80, 443)만 사용할 수 있습니다.
    LGD_CASNOTEURL = "https://상점도메인/xpay/virtual-account/cas_noteurl.asp"

    xpay.Set "LGD_TXNAME", "CyberAccount"   ' 가상계좌
    xpay.Set "LGD_METHOD", LGD_METHOD   ' ASSIGN 발급 / CHANGE 변경
    xpay.Set "LGD_OID", LGD_OID   ' 주문번호. 최대 64자
    xpay.Set "LGD_AMOUNT", LGD_AMOUNT   ' 결제금액. 숫자만
    xpay.Set "LGD_PRODUCTINFO", LGD_PRODUCTINFO   ' 상품명
    xpay.Set "LGD_BUYER", LGD_BUYER   ' 구매자명
    xpay.Set "LGD_BANKCODE", LGD_BANKCODE   ' 은행코드. 발급 시 필수
    xpay.Set "LGD_ACCOUNTOWNER", LGD_ACCOUNTOWNER   ' 입금자명
    xpay.Set "LGD_ACCOUNTPID", LGD_ACCOUNTPID   ' 구매자 생년월일 또는 사업자번호
    xpay.Set "LGD_CASNOTEURL", LGD_CASNOTEURL   ' 입금·취소 결과수신 페이지
    xpay.Set "LGD_BUYERIP", Request.ServerVariables("REMOTE_ADDR")   ' 요청한 구매자 IP

    ' ---- 선택 파라미터 : 필요한 줄의 주석만 푸세요 (입력 화면에도 같은 이름의 입력란을 추가) ----
    ' xpay.Set "LGD_BUYERPHONE", Request.Form("LGD_BUYERPHONE")   ' 구매자 휴대폰번호
    ' xpay.Set "LGD_BUYEREMAIL", Request.Form("LGD_BUYEREMAIL")   ' 구매자 이메일
    ' xpay.Set "LGD_CLOSEDATE", Request.Form("LGD_CLOSEDATE")   ' 입금 마감일시. yyyyMMddHHmmss
    ' xpay.Set "LGD_CASHRECEIPTUSE", Request.Form("LGD_CASHRECEIPTUSE")   ' 현금영수증 용도. 1 소득공제 / 2 지출증빙
    ' xpay.Set "LGD_CASHCARDNUM", Request.Form("LGD_CASHCARDNUM")   ' 현금영수증 발급번호
    ' xpay.Set "LGD_TAXFREEAMOUNT", Request.Form("LGD_TAXFREEAMOUNT")   ' 면세금액
    ' xpay.Set "LGD_ESCROW_USEYN", Request.Form("LGD_ESCROW_USEYN")   ' 에스크로 적용. Y / N

    txOk     = (xpay.TX() = 1)   ' lgdacom.conf 의 URL 로 통신
    respCode = xpay.resCode
    respMsg = xpay.resMsg

    ' 응답 상세
    Set fields = Server.CreateObject("Scripting.Dictionary")
    For i = 0 To xpay.resNameCount - 1
        name = xpay.ResponseName(i)
        fields.Add name, xpay.Response(name, 0)
    Next

    ' 통신 성공이고 응답코드 "0000" 일 때만 성공. 그 외는 모두 실패로 처리한다.
    success = txOk And respCode = "0000"

    If success Then
        ' 성공 결과를 DB 에 반영하세요.
    Else
        ' 실패 결과를 DB 에 기록하세요.
    End If

' ==================================================================
' 응답 파라미터
' ==================================================================
' 주요 값은 활성, 나머지는 주석 처리해 두었습니다.
' 필요한 줄의 ' 만 지우면 화면에 함께 출력됩니다.
    Set show = Server.CreateObject("Scripting.Dictionary")

        show.Add "LGD_RESPCODE", "응답코드. 0000 이면 성공"
        show.Add "LGD_RESPMSG", "응답메시지"
        show.Add "LGD_OID", "주문번호"
        show.Add "LGD_TID", "토스페이먼츠 거래번호"
        show.Add "LGD_AMOUNT", "결제금액"
        show.Add "LGD_FINANCECODE", "은행코드"
        show.Add "LGD_FINANCENAME", "은행명"
        show.Add "LGD_ACCOUNTNUM", "발급된 가상계좌 번호"
        show.Add "LGD_SAOWNER", "입금할 때 표시되는 계좌주명"
        show.Add "LGD_CLOSEDATE", "입금 마감일시"

        ' ===== 현금영수증 =====
        ' show.Add "LGD_CASHRECEIPTNUM", "현금영수증 승인번호"
        ' show.Add "LGD_CASHRECEIPTKIND", "0 소득공제 / 1 지출증빙"

        ' ===== 기타 =====
        ' show.Add "LGD_PAYTYPE", "결제수단코드"
        ' show.Add "LGD_PAYDATE", "처리일시"
        ' show.Add "LGD_ESCROWYN", "에스크로 적용"
%>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>가상계좌 발급·변경 결과</title>
<style>
  body { font-family: sans-serif; font-size: 14px; max-width: 860px; margin: 20px; }
  table { border-collapse: collapse; }
  th, td { border: 1px solid #ccc; padding: 4px 8px; text-align: left; vertical-align: top; }
</style>
</head>
<body>

<h1>가상계좌 발급·변경 결과</h1>

<% If Not txOk Then %>
  <p>통신 실패 — 요청을 완료하지 못했습니다. (<%= respCode %> <%= respMsg %>)</p>
<% ElseIf success Then %>
  <p>처리 성공</p>
<% Else %>
  <p>처리 실패 (<%= respCode %> <%= respMsg %>)</p>
<% End If %>

<table>
  <tr><th>변수명</th><th>설명</th><th>값</th></tr>
<% For Each k In show.Keys
       v = ""
       If fields.Exists(k) Then v = fields(k)
%>
  <tr>
    <th><%= k %></th>
    <td><%= show(k) %></td>
    <td><%= v %></td>
  </tr>
<% Next %>
</table>

<%
' 명세에 없는 값까지 전부 확인하려면 아래 주석을 푸세요.
' 
' Response.Write("<h2>수신된 전체 응답</h2><table>");
' foreach (KeyValuePair<string, string> e in fields) {
' Response.Write("<tr><th>" + e.Key + "</th><td>" + e.Value + "</td></tr>");
' }
' Response.Write("</table>");
' 
%>

<p>이 페이지는 샘플입니다. 실제 연동에서는 결과를 화면에 노출하지 말고 DB에 기록하세요.</p>

</body>
</html>
