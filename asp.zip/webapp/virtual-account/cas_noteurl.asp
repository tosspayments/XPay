<%@ CodePage=65001 Language="VBScript" %>
<%
Response.CharSet = "UTF-8"
Response.ContentType = "text/plain"
%>
<%
' [가상계좌 결과수신 페이지 (LGD_CASNOTEURL)]  토스페이먼츠 XPay — UTF-8
'
' 토스페이먼츠가 가상계좌 할당(R)·입금(I)·입금취소(C) 결과를 이 페이지로 보낸다. (서버 간 호출)
' 결제 요청 시 LGD_CASNOTEURL 에 이 페이지 주소를, LGD_ENCODING_NOTEURL 에 UTF-8 을 지정한다.
'
' 응답 규칙
' - DB 처리를 마쳤으면 "OK" 만 출력한다. 다른 문자나 HTML 이 섞이면 실패로 처리된다.
' - "OK" 이외를 출력하면 토스페이먼츠가 같은 결과를 다시 보낸다.
' - 같은 결과가 여러 번 올 수 있으므로 LGD_TID, LGD_CASFLAG, LGD_CASSEQNO 로 중복을 확인한다.
' 표준포트(HTTP 80, HTTPS 443)로만 받을 수 있으며, 토스페이먼츠 입금통보 IP 를 방화벽에 허용해야 한다.
%>
<%

    ' ---- 상점 설정 ★ 이 줄만 수정하세요 ----------------------------------

    ' 토스페이먼츠에서 제공한 환경파일(conf/lgdacom.conf, conf/mall.conf) 디렉터리
    configPath = "C:/lgdacom"

' ==================================================================
' 수신 파라미터
' ==================================================================
' 처리에 필요한 값은 활성, 나머지는 주석 처리해 두었습니다.
' 필요한 줄의 ' 만 지우면 recv 에 함께 담깁니다.
    Set names = Server.CreateObject("Scripting.Dictionary")
        names.Add "LGD_RESPCODE", "응답코드. 0000 이면 성공"
        names.Add "LGD_RESPMSG", "응답메시지"
        names.Add "LGD_MID", "상점아이디"
        names.Add "LGD_OID", "주문번호"
        names.Add "LGD_AMOUNT", "거래금액"
        names.Add "LGD_TID", "토스페이먼츠 거래번호"
        names.Add "LGD_PAYTYPE", "결제수단코드. 가상계좌는 SC0040"
        names.Add "LGD_PAYDATE", "거래일시. yyyyMMddHHmmss"
        names.Add "LGD_HASHDATA", "해쉬값"
        names.Add "LGD_TIMESTAMP", "타임스탬프"
        names.Add "LGD_FINANCECODE", "결제기관코드(은행코드)"
        names.Add "LGD_FINANCENAME", "결제기관명(은행명)"
        names.Add "LGD_ACCOUNTNUM", "가상계좌 번호"
        names.Add "LGD_CASFLAG", "거래종류. R 할당 / I 입금 / C 입금취소"
        names.Add "LGD_CASTAMOUNT", "입금누적금액"
        names.Add "LGD_CASCAMOUNT", "현입금금액"
        names.Add "LGD_CASSEQNO", "입금순서"
        names.Add "LGD_PAYER", "입금자명"

        ' ===== 에스크로 =====
        ' names.Add "LGD_ESCROWYN", "에스크로 적용여부. Y 적용 / N 미적용"

        ' ===== 현금영수증 =====
        ' names.Add "LGD_CASHRECEIPTNUM", "현금영수증 승인번호"
        ' names.Add "LGD_CASHRECEIPTSELFYN", "현금영수증 자진발급제 유무. Y 자진발급"
        ' names.Add "LGD_CASHRECEIPTKIND", "현금영수증 종류. 0 소득공제 / 1 지출증빙"

        ' ===== 구매자·상품·배송 =====
        ' names.Add "LGD_BUYER", "구매자명"
        ' names.Add "LGD_PRODUCTINFO", "상품명"
        ' names.Add "LGD_BUYERID", "구매자 아이디"
        ' names.Add "LGD_BUYERADDRESS", "구매자 주소"
        ' names.Add "LGD_BUYERPHONE", "구매자 휴대폰번호"
        ' names.Add "LGD_BUYEREMAIL", "구매자 이메일"
        ' names.Add "LGD_BUYERSSN", "구매자 생년월일"
        ' names.Add "LGD_PRODUCTCODE", "상품코드"
        ' names.Add "LGD_RECEIVER", "수취인"
        ' names.Add "LGD_RECEIVERPHONE", "수취인 전화번호"
        ' names.Add "LGD_DELIVERYINFO", "배송지"

    Set recv = Server.CreateObject("Scripting.Dictionary")
    For Each k In names.Keys
        recv.Add k, Request.Form(k)
    Next

    ' ---- 해시 검증 ----------------------------------------------------
    ' MD5(LGD_MID + LGD_OID + LGD_AMOUNT + LGD_RESPCODE + LGD_TIMESTAMP + mertkey)
    ' mall.conf 에 등록한 mertkey 로 계산한다. 코드에 mertkey 를 쓰지 않는다.
    Set xpay = Server.CreateObject("XPayClientCOM.XPayClient")
    ' 해시 계산에 쓸 mall.conf 를 읽는다. 연동 환경(test/service)은 해시 계산에 영향을 주지 않는다.
    If xpay.Init(configPath, "service") = 0 Then
        Response.Write "환경파일을 읽지 못했습니다. configPath 를 확인하세요."
        Response.End
    End If
    hash = xpay.GetHashDataCas(recv("LGD_MID"), recv("LGD_OID"), recv("LGD_AMOUNT"), recv("LGD_RESPCODE"), recv("LGD_TIMESTAMP"))

    Dim result
    If hash <> recv("LGD_HASHDATA") Then
        ' 해시 불일치. DB 에 반영하지 않고 로그를 남긴 뒤 원인을 확인하세요.
        result = "해시 검증 실패"
    ElseIf recv("LGD_RESPCODE") = "0000" Then
        flag = recv("LGD_CASFLAG")
        If flag = "R" Then
            ' 가상계좌 할당 성공. 계좌번호(LGD_ACCOUNTNUM)를 주문에 기록하세요.
        ElseIf flag = "I" Then
            ' 입금 성공. 입금금액(LGD_CASCAMOUNT)을 확인하고 주문을 결제완료로 바꾸세요.
        ElseIf flag = "C" Then
            ' 입금취소. 은행 사정으로 입금이 취소된 경우입니다. 주문 상태를 되돌리세요.
        End If
        isDBOK = true   ' DB 처리에 실패하면 false
        If isDBOK Then result = "OK" Else result = "상점 DB 처리 실패"
    Else
        ' 결제 실패 결과. 실패 내용을 DB 에 기록하세요.
        isDBOK = true
        If isDBOK Then result = "OK" Else result = "상점 DB 처리 실패"
    End If

    ' 지시문 사이의 줄바꿈이 응답에 섞이지 않도록 지금까지의 출력을 비운 뒤 결과만 쓴다.
    Response.Clear
    Response.Write result
%>