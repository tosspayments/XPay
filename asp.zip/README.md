# ASP(Classic) 샘플

ASP(VBScript)로 작성된 XPayClient 연동 샘플입니다. `webapp`은 그대로 배포할 수 있는 웹 애플리케이션이며, 기능별 샘플을 폴더로 나누었습니다. 구성은 Java·PHP·ASP.NET 샘플과 같습니다.

## 요구 사항

- IIS 의 ASP 기능
- **한국어 시스템 로캘**(ANSI 코드 페이지 949)인 Windows 서버. COM 라이브러리는 요청 값을 시스템 코드 페이지(EUC-KR)로 변환해 보내므로, 다른 로캘에서는 한글 요청 값이 깨집니다.
- Windows Server 에서 TLS 1.2 가 활성화되어 있어야 합니다. (연동 가이드의 설치 및 환경 구성 참고)
- 상점 서버에서 XPay 게이트웨이로 나가는 443 포트 허용 (연동 가이드의 방화벽 및 IP 정보 참고)

## 설치

### 1. COM 라이브러리 등록

`install/XPayClientForCOM`에서 IIS 애플리케이션 풀에 맞는 DLL 을 골라 등록합니다.

| 폴더 | 대상 | 비고 |
| --- | --- | --- |
| `X64/MT` | 64비트 애플리케이션 풀 | **권장.** 런타임이 포함되어 있어 따로 설치할 것이 없습니다. |
| `X86/MT` | 32비트 애플리케이션 풀 (`32비트 응용 프로그램 사용` = True) | 권장. |
| `X64/MD`, `X86/MD` | 위와 같음 | Visual C++ 2008 재배포 패키지(`msvcr90.dll`, `mfc90u.dll`)가 필요합니다. |

```text
regsvr32 C:\lgdacom\XPayClientCom.dll
```

DLL 은 웹에서 접근할 수 없는 경로에 두고 등록합니다. COM+ 응용 프로그램으로 등록하는 방법은 연동 가이드의 설치 및 환경 구성(COM+ 등록)을 참고합니다.

### 2. 설정 폴더 배치

`lgdacom` 폴더를 **웹에서 접근할 수 없는 경로**(예: `C:\lgdacom`)에 복사합니다.

```text
C:\lgdacom\
├── conf\
│   ├── lgdacom.conf
│   └── mall.conf      ← mall.conf.example을 복사해서 만듭니다.
└── log\
```

다른 경로를 쓰는 경우 API 를 호출하는 페이지(`.asp`) 맨 위 "상점 설정"의 `configPath` 값을 바꿉니다.

### 3. mall.conf 작성

1. `mall.conf.example`을 같은 폴더에 `mall.conf`로 복사합니다.
2. 맨 아래에 `MID = mertkey`를 입력합니다. 테스트 MID 는 앞에 `t`를 붙입니다.
3. `default_secure_protocols = 2048`(TLS 1.2)은 그대로 둡니다.

> **주의**
> `mall.conf`는 mertkey 가 들어 있으므로 저장소에 커밋하지 않습니다. (`.gitignore`에 등록되어 있습니다.)

### 4. 웹 애플리케이션 배포

`webapp` 폴더를 IIS 사이트(또는 가상 디렉터리)로 등록하고 `index.html`을 엽니다. 결제 결과를 받는 페이지(`returnurl`, `cas_noteurl` 등)는 각 요청 페이지 "상점 설정"의 주소(`https://상점도메인/...`)를 실제 주소로 바꿉니다.

## 인코딩

- 모든 파일은 UTF-8 이며, 각 페이지 첫 줄의 `<%@ CodePage=65001 %>`와 `Response.CharSet = "UTF-8"`로 UTF-8 로 처리합니다. 편집할 때 UTF-8 을 유지합니다.
- COM 라이브러리는 응답의 한글을 그대로 돌려주므로 `output_UTF8` 값과 관계없이 화면에 바르게 표시됩니다. 샘플 `mall.conf`는 다른 언어와 같이 `1`로 둡니다.
- 요청은 COM 라이브러리가 EUC-KR 로 변환해 보냅니다. 그래서 API 요청에는 `LGD_ENCODING`을 보내지 않습니다.

## 샘플 작성 규칙

다른 언어 샘플과 같습니다.

- 외부 CSS 없이 한 파일 안에서 동작합니다.
- 요청 파라미터는 필수 값과 샘플 실행에 필요한 고정값만 활성되어 있고, 선택 파라미터는 모두 주석입니다.
- 결과 페이지의 `show` 목록에는 주요 응답값만 활성되어 있습니다. 필요한 줄의 `'`만 지우면 화면에 함께 출력됩니다.
- 해시는 COM 라이브러리의 `GetHashData()`, `GetHashDataCas()`로 만들기 때문에 코드에 mertkey 를 쓰지 않습니다.
- 입력값 검증, 화면 출력 시 이스케이프 같은 문자열 처리는 넣지 않았습니다. 가맹점 환경에 맞게 구현합니다.

> **주의**
> COM 라이브러리의 `Init`, `Init_TX`, `TX`는 성공하면 `1`, 실패하면 `0`을 돌려줍니다. VBScript 의 `Not`은 비트 연산이라 `Not 1`도 참이 되므로, 샘플처럼 `If xpay.Init_TX(LGD_MID) = 0 Then`으로 값을 비교합니다.

## 라이브러리

| 파일 | 버전 | 비고 |
| --- | --- | --- |
| `install/XPayClientForCOM/{X86,X64}/{MD,MT}/XPayClientCom.dll` | 4.0.0.0 | ProgID `XPayClientCOM.XPayClient` |

라이브러리는 원본 그대로입니다. 소스가 없어 수정하지 않았습니다. 통신은 Windows 의 WinHTTP 를 사용하므로 서버 인증서는 Windows 인증서 저장소로 검증합니다.

## 폴더 구성

```text
asp/
├── install/XPayClientForCOM/  # COM 라이브러리 (X86/X64 × MD/MT)
├── lgdacom/conf/              # lgdacom.conf, mall.conf.example
└── webapp/
    ├── index.html             # 기능 목록
    ├── unified-checkout/pc/   # 통합결제창 (PC)
    ├── unified-checkout/mobile/
    ├── virtual-account/       # 가상계좌 발급·변경(CyberAccount), 결과수신(cas_noteurl)
    ├── cancel/                # 결제취소 (부분취소·환불 파라미터 포함)
    ├── cash-receipt/          # 현금영수증
    ├── card-keyin/            # 카드 비인증 결제
    ├── card-billing/          # 카드 빌링 결제
    ├── card-billing-window/   # 결제창 빌링키 발급 (PC), mobile/ (모바일)
    ├── mobile-billing/        # 휴대폰 빌링 결제
    ├── split-settlement/      # 분할정산
    ├── acc-cert/              # 계좌 유효성 확인
    ├── search/                # 거래 조회
    └── settlement/            # 수동정산
```

안심키인 결제창 샘플은 `no-xpayclient/ansim-keyin/asp`, 에스크로 샘플은 `https-api/escrow/asp`에 있습니다.

## 원본 샘플 패키지에서 제외한 것

- `patch.asp`, `ping.asp`
- 이전 버전 라이브러리 `XPayClientCom.dll` 1.0.1.0 과 설치 파일(`.MSI`, `.cab`) (`Tosspayments_Xpay_cardAPI_Crossplatform_ASP`에 포함)
- 페이나우 전용 간편결제 샘플 (`TossPayments_Easypay_ASP`, `TossPayments_MobileXPay_Easypay_ASP`)
- 현금영수증 가맹등록 (`TossPayments_CashReceiptRegisterMert_ASP`, 비공개 기능)
- 부분취소 가능 여부 조회 (`GetPartCancelable`). 부분취소·환불 파라미터는 `cancel/Cancel.asp`의 주석에 들어 있습니다.
- 원본에 들어 있던 mertkey (`mall.conf` 18곳, 안심키인·에스크로 예제 3곳)
