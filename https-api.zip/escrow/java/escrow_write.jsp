<%@ page pageEncoding="UTF-8" import="java.io.*, java.text.SimpleDateFormat, java.util.Date" %>
<%--
 * [에스크로 처리결과 로그]  result_receive.jsp 가 포함(include)하는 파일 — UTF-8
 *
 * 처리결과를 로그 파일에 남긴다. 로그 경로를 상점 환경에 맞게 바꾸고, DB 처리 루틴을 추가하세요.
--%>
<%!
    // ★ 로그를 남길 폴더. 웹에서 접근할 수 없는 경로를 사용하세요.
    static final String ESCROW_LOG_DIR = "C:/lgdacom/log";

    boolean writeSuccess(String[] noti) throws IOException { writeLog("escrow_success.log", noti); return true; }
    boolean writeFailure(String[] noti) throws IOException { writeLog("escrow_failure.log", noti); return true; }
    boolean writeHashErr(String[] noti) throws IOException { writeLog("escrow_hasherr.log", noti); return true; }

    void writeLog(String fileName, String[] noti) throws IOException {
        String[] labels = { "결과구분", "상점ID", "토스페이먼츠 거래번호", "상점주문번호", "작업자 주민번호",
                            "작업자 PC IP", "작업자 PC MAC", "처리일시", "토스페이먼츠 인증키", "상품ID", "자체 인증키" };
        StringBuilder sb = new StringBuilder();
        sb.append("작성일시 : ").append(new SimpleDateFormat("yyyyMMddHHmmss").format(new Date())).append("\r\n");
        for (int i = 0; i < labels.length && i < noti.length; i++) {
            sb.append(labels[i]).append(" : ").append(noti[i]).append("\r\n");
        }
        File dir = new File(ESCROW_LOG_DIR);
        if (!dir.exists()) dir.mkdirs();
        OutputStream os = new FileOutputStream(new File(dir, fileName), true);
        os.write(sb.toString().getBytes("UTF-8"));
        os.close();
    }
%>
