<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.net.HttpURLConnection, java.net.URL, java.net.URLEncoder, java.io.*, java.security.MessageDigest, java.util.LinkedHashMap, java.util.Map" %>
<%--
 * [에스크로 배송등록 송신 페이지]  토스페이먼츠 XPay — UTF-8
 *
 * 배송정보 등록(dlvtype=03) 또는 배송완료 등록(dlvtype=01)을 토스페이먼츠에 보낸다.
 * XPayClient 를 쓰지 않고 HTTPS 로 직접 호출한다. 응답 본문이 OK 이면 성공이다.
 * 에스크로 결제는 배송정보 등록이나 배송완료 등록을 하지 않으면 정산되지 않는다.
 *
 * 토스페이먼츠 배송등록 서버는 EUC-KR 이다.
 * 이 페이지는 UTF-8 이므로 보내는 값은 EUC-KR 로 인코딩하고, 받은 응답은 EUC-KR 로 읽는다.
--%>
<%
    request.setCharacterEncoding("UTF-8");

    /* ---- 상점 설정 ★ 이 줄만 수정하세요 ---------------------------------- */

    // 테스트
    String serviceUrl = "https://pgweb.tosspayments.com:9091/pg/wmp/testadmin/jsp/escrow/rcvdlvinfo.jsp";
    // 서비스
    // String serviceUrl = "https://pgweb.tosspayments.com/pg/wmp/mertadmin/jsp/escrow/rcvdlvinfo.jsp";

    // 상점 mertkey. 외부에 노출되지 않는 설정에서 읽도록 바꾸는 것을 권장합니다.
    // ★ 실제 mertkey 를 입력한 채로 저장소에 커밋하지 마세요.
    String mertkey = "";

    /* ---- 요청 파라미터 --------------------------------------------------- */

    String mid     = request.getParameter("mid");
    String oid     = request.getParameter("oid");
    String dlvtype = request.getParameter("dlvtype");    // 03 배송정보 등록 / 01 배송완료 등록

    Map<String, String> params = new LinkedHashMap<String, String>();
    params.put("mid", mid);
    params.put("oid", oid);
    params.put("dlvtype", dlvtype);

    String hashSrc;
    if ("03".equals(dlvtype)) {
        // 배송정보 등록 필수
        String dlvdate     = request.getParameter("dlvdate");       // 발송일시. yyyyMMddHHmm
        String dlvcompcode = request.getParameter("dlvcompcode");   // 택배사 코드
        String dlvno       = request.getParameter("dlvno");         // 운송장번호
        params.put("dlvdate", dlvdate);
        params.put("dlvcompcode", dlvcompcode);
        params.put("dlvno", dlvno);

        // 선택 : 필요한 줄의 주석만 푸세요 (입력 화면에도 같은 이름의 입력란을 추가)
        // params.put("dlvworker",    request.getParameter("dlvworker"));      // 배송자 성명
        // params.put("dlvworkertel", request.getParameter("dlvworkertel"));   // 배송자 연락처

        // hashdata = MD5(mid + oid + dlvdate + dlvcompcode + dlvno + mertkey)   ※ dlvtype 은 넣지 않는다
        hashSrc = mid + oid + dlvdate + dlvcompcode + dlvno + mertkey;
    } else {
        // 배송완료 등록 필수
        String rcvdate     = request.getParameter("rcvdate");       // 실수령일시. yyyyMMddHHmm
        String rcvname     = request.getParameter("rcvname");       // 실수령인
        String rcvrelation = request.getParameter("rcvrelation");   // 수령인과의 관계
        params.put("rcvdate", rcvdate);
        params.put("rcvname", rcvname);
        params.put("rcvrelation", rcvrelation);

        // hashdata = MD5(mid + oid + dlvtype + rcvdate + mertkey)   ※ dlvtype(01)을 넣는다
        hashSrc = mid + oid + dlvtype + rcvdate + mertkey;
    }

    // 선택 : 상품이 여러 개이고 상품별로 등록할 때만 사용
    // params.put("productid", request.getParameter("productid"));   // 결제 때 보낸 에스크로 상품번호

    MessageDigest md = MessageDigest.getInstance("MD5");
    byte[] digest = md.digest((hashSrc).getBytes("UTF-8"));
    StringBuffer strBuf = new StringBuffer();
    for (int i = 0; i < digest.length; i++) {
        int c = digest[i] & 0xff;
        if (c <= 15) strBuf.append("0");
        strBuf.append(Integer.toHexString(c));
    }
    String hashdata = strBuf.toString();
    params.put("hashdata", hashdata);

    /* ---- 전송 (application/x-www-form-urlencoded, EUC-KR) --------------- */

    StringBuilder body = new StringBuilder();
    for (Map.Entry<String, String> e : params.entrySet()) {
        if (body.length() > 0) body.append('&');
        body.append(e.getKey()).append('=').append(URLEncoder.encode(e.getValue(), "EUC-KR"));
    }

    String result;
    try {
        HttpURLConnection conn = (HttpURLConnection) new URL(serviceUrl).openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(30000);
        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=EUC-KR");
        OutputStream os = conn.getOutputStream();
        os.write(body.toString().getBytes("US-ASCII"));   // URL 인코딩된 본문은 ASCII 이다
        os.close();

        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "EUC-KR"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        result = sb.toString();
    } catch (Exception ex) {
        result = "통신 실패: " + ex.getMessage();
    }

    // 응답 본문이 정확히 OK 이면 성공, 실패하면 "FAIL : 실패메시지"
    boolean success = "OK".equals(result);
%>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>XPay 에스크로 배송등록 결과</title>
<style>
  body { font-family: sans-serif; font-size: 14px; max-width: 640px; margin: 20px; }
</style>
</head>
<body>

<h1>에스크로 배송등록 결과</h1>
<p><%= success ? "등록 성공" : "등록 실패" %></p>
<p>응답: <code><%= result %></code></p>

</body>
</html>
