# 에스크로

에스크로 결제의 배송정보 등록과 처리결과 수신 샘플입니다. HTTPS로 직접 호출하며 **XPayClient 라이브러리를 사용하지 않습니다.**

| 파일 | 내용 |
| --- | --- |
| `delivery.html` | 배송등록 입력 화면 |
| `delivery_send.jsp` | 배송정보 등록(`dlvtype=03`) 또는 배송완료 등록(`dlvtype=01`)을 요청합니다. 응답 본문이 `OK`이면 성공입니다. |
| `result_receive.jsp` | 토스페이먼츠가 보내는 처리결과(수령확인, 구매취소요청 등)를 받아 hashdata를 검증하고 `OK`를 응답합니다. |
| `escrow_write.jsp` | `result_receive.jsp`가 포함(include)하는 로그 기록 파일입니다. |

## 수정할 곳

- `delivery_send.jsp`, `result_receive.jsp`의 `mertkey`에 상점 mertkey를 입력합니다. 테스트 후 커밋하기 전에 반드시 지웁니다.
- `delivery_send.jsp`의 `serviceUrl`은 테스트 주소로 되어 있습니다. 서비스로 전환할 때 주석으로 넣어 둔 서비스 주소로 바꿉니다.
- `escrow_write.jsp`의 `ESCROW_LOG_DIR`을 웹에서 접근할 수 없는 로그 경로로 바꿉니다.
- 처리결과 수신 URL은 `techsupport@tosspayments.com`으로 요청해 등록합니다. URL은 하나만 설정할 수 있습니다.
- 처리결과는 응답을 받지 못하면 30분 간격으로 최대 10번 다시 전송됩니다. 같은 결과를 중복 반영하지 않도록 처리합니다.

> **참고**
> 토스페이먼츠 배송등록 서버는 EUC-KR 입니다. 샘플 파일은 UTF-8 이지만, 보내는 값은 EUC-KR 로 바꿔서 보내고 응답은 UTF-8 로 바꿔 표시합니다. EUC-KR 에 없는 글자(예: 똠, 햏 등 일부 한글)의 처리는 가맹점에서 구현합니다.

## 연동 가이드

에스크로
