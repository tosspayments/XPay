<%@ page contentType="text/plain; charset=UTF-8" pageEncoding="UTF-8" trimDirectiveWhitespaces="true" %>
<%@ page import="java.security.MessageDigest" %>
<%@ include file="escrow_write.jsp" %>
<%--
 * [에스크로 처리결과 수신 페이지]  토스페이먼츠 XPay — UTF-8
 *
 * 구매자의 수령확인·구매취소요청, 택배사 배송완료 결과를 토스페이먼츠가 이 페이지로 보낸다. (서버 간 호출)
 * 수신 URL 은 techsupport@tosspayments.com 으로 요청해 등록한다. URL 은 하나만 설정할 수 있다.
 *
 *   - 이 페이지에는 HTML 태그나 스크립트를 출력하지 않는다. 결과를 반영했으면 "OK" 만 출력한다.
 *   - 응답을 받지 못하면 30분 간격으로 최대 10번 다시 보낸다.
 *     같은 결과가 다시 올 수 있으므로 oid, tid, txtype 으로 이미 반영한 결과인지 확인한다.
 *   - hash 오류가 나면 원인을 확인해 바로 대처한다.
--%>
<%
    request.setCharacterEncoding("UTF-8");

    /* ---- 상점 설정 ★ 이 줄만 수정하세요 ---------------------------------- */

    // 상점 mertkey. 외부에 노출되지 않는 설정에서 읽도록 바꾸는 것을 권장합니다.
    // ★ 실제 mertkey 를 입력한 채로 저장소에 커밋하지 마세요.
    String mertkey = "";

    /* ---- 수신 파라미터 --------------------------------------------------- */

    String txtype    = request.getParameter("txtype");     // C 수령확인결과 / R 구매취소요청 / S 택배사 배송완료 / N N/C 처리완료
    String mid       = request.getParameter("mid");        // 상점아이디
    String oid       = request.getParameter("oid");        // 주문번호
    String tid       = request.getParameter("tid");        // 토스페이먼츠 거래번호
    String productid = request.getParameter("productid");  // 상품 ID. 기본값 1
    String ssn       = request.getParameter("ssn");        // 작업자 주민번호. 개인정보보호법에 따라 "." 으로 전송
    String ip        = request.getParameter("ip");         // 작업자 PC IP. "." 으로 전송
    String mac       = request.getParameter("mac");        // 작업자 PC MAC. "." 으로 전송
    String resdate   = request.getParameter("resdate");    // 처리일시. yyyyMMddHHmmss
    String hashdata  = request.getParameter("hashdata");   // 위변조 검증용 인증키

    // hashdata = MD5(mid + oid + tid + txtype + productid + ssn + ip + mac + resdate + mertkey)
    MessageDigest md = MessageDigest.getInstance("MD5");
    byte[] digest = md.digest((mid + oid + tid + txtype + productid + ssn + ip + mac + resdate + mertkey).getBytes("UTF-8"));
    StringBuffer strBuf = new StringBuffer();
    for (int i = 0; i < digest.length; i++) {
        int c = digest[i] & 0xff;
        if (c <= 15) strBuf.append("0");
        strBuf.append(Integer.toHexString(c));
    }
    String myHash = strBuf.toString();

    String[] noti = { txtype, mid, tid, oid, ssn, ip, mac, resdate, hashdata, productid, myHash };

    boolean resp = false;
    if (myHash.equals(hashdata)) {
        // 해시 검증 성공. 결과를 상점 시스템(DB)에 반영하세요.
        resp = writeSuccess(noti);
    } else {
        // 해시 검증 실패. 로그를 남기고 원인을 확인하세요.
        writeHashErr(noti);
    }

    out.print(resp ? "OK" : "FAIL");
%>
