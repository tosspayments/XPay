﻿<script runat="server">
    // [에스크로 처리결과 로그]  result_receive.aspx 가 포함(include)하는 파일 — UTF-8
    //
    // 처리결과를 로그 파일에 남긴다. 로그 경로를 상점 환경에 맞게 바꾸고, DB 처리 루틴을 추가하세요.

    // ★ 로그를 남길 폴더. 웹에서 접근할 수 없는 경로를 사용하세요.
    const string ESCROW_LOG_DIR = "C:\\lgdacom\\log";

    bool escrow_write_success(string[] noti) { escrow_write_log("escrow_success.log", noti); return true; }
    bool escrow_write_failure(string[] noti) { escrow_write_log("escrow_failure.log", noti); return true; }
    bool escrow_write_hasherr(string[] noti) { escrow_write_log("escrow_hasherr.log", noti); return true; }

    void escrow_write_log(string fileName, string[] noti)
    {
        string[] labels = { "결과구분", "상점ID", "토스페이먼츠 거래번호", "상점주문번호", "작업자 주민번호",
                            "작업자 PC IP", "작업자 PC MAC", "처리일시", "토스페이먼츠 인증키", "상품ID", "자체 인증키" };
        System.Text.StringBuilder text = new System.Text.StringBuilder();
        text.Append("작성일시 : ").Append(DateTime.Now.ToString("yyyyMMddHHmmss")).Append("\r\n");
        for (int idx = 0; idx < labels.Length; idx++) {
            text.Append(labels[idx]).Append(" : ").Append(idx < noti.Length ? noti[idx] : "").Append("\r\n");
        }
        System.IO.File.AppendAllText(System.IO.Path.Combine(ESCROW_LOG_DIR, fileName), text.ToString(), System.Text.Encoding.UTF8);
    }
</script>
