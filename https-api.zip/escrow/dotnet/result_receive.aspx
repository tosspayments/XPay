﻿<%@ Page Language="C#" ContentType="text/plain" ResponseEncoding="utf-8" %>
<%@ Import Namespace="System.Security.Cryptography" %>
<%@ Import Namespace="System.Text" %>
<!-- #include file="escrow_write.inc" -->
<%--
 * [에스크로 처리결과 수신 페이지]  토스페이먼츠 XPay — UTF-8
 *
 * 구매자의 수령확인·구매취소요청, 택배사 배송완료 결과를 토스페이먼츠가 이 페이지로 보낸다. (서버 간 호출)
 * 수신 URL 은 techsupport@tosspayments.com 으로 요청해 등록한다. URL 은 하나만 설정할 수 있다.
 *
 *   - 이 페이지에는 HTML 태그나 스크립트를 출력하지 않는다. 결과를 반영했으면 "OK" 만 출력한다.
 *   - 응답을 받지 못하면 30분 간격으로 최대 10번 다시 보낸다.
 *     같은 결과가 다시 올 수 있으므로 oid, tid, txtype 으로 이미 반영한 결과인지 확인한다.
 *   - hash 오류가 나면 원인을 확인해 바로 대처한다.
--%>
<%
    /* ---- 상점 설정 ★ 이 줄만 수정하세요 ---------------------------------- */

    // 상점 mertkey. 외부에 노출되지 않는 설정에서 읽도록 바꾸는 것을 권장합니다.
    // ★ 실제 mertkey 를 입력한 채로 저장소에 커밋하지 마세요.
    string mertkey = "";

    /* ---- 수신 파라미터 --------------------------------------------------- */

    string txtype    = Request.Form["txtype"];     // C 수령확인결과 / R 구매취소요청 / S 택배사 배송완료 / N N/C 처리완료
    string mid       = Request.Form["mid"];        // 상점아이디
    string oid       = Request.Form["oid"];        // 주문번호
    string tid       = Request.Form["tid"];        // 토스페이먼츠 거래번호
    string productid = Request.Form["productid"];  // 상품 ID. 기본값 1
    string ssn       = Request.Form["ssn"];        // 작업자 주민번호. 개인정보보호법에 따라 "." 으로 전송
    string ip        = Request.Form["ip"];         // 작업자 PC IP. "." 으로 전송
    string mac       = Request.Form["mac"];        // 작업자 PC MAC. "." 으로 전송
    string resdate   = Request.Form["resdate"];    // 처리일시. yyyyMMddHHmmss
    string hashdata  = Request.Form["hashdata"];   // 위변조 검증용 인증키

    // hashdata = MD5(mid + oid + tid + txtype + productid + ssn + ip + mac + resdate + mertkey)
    MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
    byte[] digest = md5.ComputeHash(Encoding.UTF8.GetBytes(mid + oid + tid + txtype + productid + ssn + ip + mac + resdate + mertkey));
    StringBuilder strBuf = new StringBuilder();
    for (int i = 0; i < digest.Length; i++) {
        strBuf.Append(digest[i].ToString("x2"));
    }
    string myHash = strBuf.ToString();

    string[] noti = { txtype, mid, tid, oid, ssn, ip, mac, resdate, hashdata, productid, myHash };

    bool resp = false;
    if (myHash.Equals(hashdata)) {
        // 해시 검증 성공. 결과를 상점 시스템(DB)에 반영하세요.
        resp = escrow_write_success(noti);
    } else {
        // 해시 검증 실패. 로그를 남기고 원인을 확인하세요.
        escrow_write_hasherr(noti);
    }

    // 지시문 사이의 줄바꿈이 응답에 섞이지 않도록 지금까지의 출력을 비운 뒤 결과만 쓴다.
    Response.Clear();
    Response.Write(resp ? "OK" : "FAIL");
%>