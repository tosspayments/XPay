﻿<%@ Page Language="C#" ContentType="text/html" ResponseEncoding="utf-8" %>
<%@ Import Namespace="System.Collections.Generic" %>
<%@ Import Namespace="System.IO" %>
<%@ Import Namespace="System.Net" %>
<%@ Import Namespace="System.Security.Cryptography" %>
<%@ Import Namespace="System.Text" %>
<%--
 * [에스크로 배송등록 송신 페이지]  토스페이먼츠 XPay — UTF-8
 *
 * 배송정보 등록(dlvtype=03) 또는 배송완료 등록(dlvtype=01)을 토스페이먼츠에 보낸다.
 * XPayClient 를 쓰지 않고 HTTPS 로 직접 호출한다. 응답 본문이 OK 이면 성공이다.
 * 에스크로 결제는 배송정보 등록이나 배송완료 등록을 하지 않으면 정산되지 않는다.
 *
 * 토스페이먼츠 배송등록 서버는 EUC-KR 이다.
 * 이 페이지는 UTF-8 이므로 보내는 값은 EUC-KR 로 인코딩하고, 받은 응답은 EUC-KR 로 읽는다.
--%>
<%
    /* ---- 상점 설정 ★ 이 줄만 수정하세요 ---------------------------------- */

    // 테스트
    string serviceUrl = "https://pgweb.tosspayments.com:9091/pg/wmp/testadmin/jsp/escrow/rcvdlvinfo.jsp";
    // 서비스
    // string serviceUrl = "https://pgweb.tosspayments.com/pg/wmp/mertadmin/jsp/escrow/rcvdlvinfo.jsp";

    // 상점 mertkey. 외부에 노출되지 않는 설정에서 읽도록 바꾸는 것을 권장합니다.
    // ★ 실제 mertkey 를 입력한 채로 저장소에 커밋하지 마세요.
    string mertkey = "";

    /* ---- 요청 파라미터 --------------------------------------------------- */

    string mid     = Request.Form["mid"];
    string oid     = Request.Form["oid"];
    string dlvtype = Request.Form["dlvtype"];    // 03 배송정보 등록 / 01 배송완료 등록

    Dictionary<string, string> sendParams = new Dictionary<string, string>();
    sendParams["mid"] = mid;
    sendParams["oid"] = oid;
    sendParams["dlvtype"] = dlvtype;

    string hashSrc;
    if ("03".Equals(dlvtype)) {
        // 배송정보 등록 필수
        sendParams["dlvdate"]     = Request.Form["dlvdate"];       // 발송일시. yyyyMMddHHmm
        sendParams["dlvcompcode"] = Request.Form["dlvcompcode"];   // 택배사 코드
        sendParams["dlvno"]       = Request.Form["dlvno"];         // 운송장번호

        // 선택 : 필요한 줄의 주석만 푸세요 (입력 화면에도 같은 이름의 입력란을 추가)
        // sendParams["dlvworker"]    = Request.Form["dlvworker"];      // 배송자 성명
        // sendParams["dlvworkertel"] = Request.Form["dlvworkertel"];   // 배송자 연락처

        // hashdata = MD5(mid + oid + dlvdate + dlvcompcode + dlvno + mertkey)   ※ dlvtype 은 넣지 않는다
        hashSrc = mid + oid + sendParams["dlvdate"] + sendParams["dlvcompcode"] + sendParams["dlvno"] + mertkey;
    } else {
        // 배송완료 등록 필수
        sendParams["rcvdate"]     = Request.Form["rcvdate"];       // 실수령일시. yyyyMMddHHmm
        sendParams["rcvname"]     = Request.Form["rcvname"];       // 실수령인
        sendParams["rcvrelation"] = Request.Form["rcvrelation"];   // 수령인과의 관계

        // hashdata = MD5(mid + oid + dlvtype + rcvdate + mertkey)   ※ dlvtype(01)을 넣는다
        hashSrc = mid + oid + dlvtype + sendParams["rcvdate"] + mertkey;
    }

    // 선택 : 상품이 여러 개이고 상품별로 등록할 때만 사용
    // sendParams["productid"] = Request.Form["productid"];   // 결제 때 보낸 에스크로 상품번호

    MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
    byte[] digest = md5.ComputeHash(Encoding.UTF8.GetBytes(hashSrc));
    StringBuilder strBuf = new StringBuilder();
    for (int i = 0; i < digest.Length; i++) {
        strBuf.Append(digest[i].ToString("x2"));
    }
    sendParams["hashdata"] = strBuf.ToString();

    /* ---- 전송 (application/x-www-form-urlencoded, EUC-KR) --------------- */

    Encoding euckr = Encoding.GetEncoding("euc-kr");
    StringBuilder body = new StringBuilder();
    foreach (KeyValuePair<string, string> e in sendParams) {
        if (body.Length > 0) body.Append('&');
        body.Append(e.Key).Append('=').Append(HttpUtility.UrlEncode(e.Value, euckr));
    }

    string result;
    try {
        HttpWebRequest req = (HttpWebRequest) WebRequest.Create(serviceUrl);
        req.Method = "POST";
        req.Timeout = 30000;
        req.ContentType = "application/x-www-form-urlencoded; charset=EUC-KR";
        byte[] data = Encoding.ASCII.GetBytes(body.ToString());   // URL 인코딩된 본문은 ASCII 이다
        req.ContentLength = data.Length;
        using (Stream os = req.GetRequestStream()) {
            os.Write(data, 0, data.Length);
        }
        using (HttpWebResponse res = (HttpWebResponse) req.GetResponse())
        using (StreamReader rd = new StreamReader(res.GetResponseStream(), euckr)) {
            result = rd.ReadToEnd();
        }
    } catch (Exception ex) {
        result = "통신 실패: " + ex.Message;
    }

    // 응답 본문이 정확히 OK 이면 성공, 실패하면 "FAIL : 실패메시지"
    bool success = "OK".Equals(result);
%>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>XPay 에스크로 배송등록 결과</title>
<style>
  body { font-family: sans-serif; font-size: 14px; max-width: 640px; margin: 20px; }
</style>
</head>
<body>

<h1>에스크로 배송등록 결과</h1>
<p><%= success ? "등록 성공" : "등록 실패" %></p>
<p>응답: <code><%= result %></code></p>

</body>
</html>
