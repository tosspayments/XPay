<?php
/*
 * [에스크로 배송등록 송신 페이지]  토스페이먼츠 XPay — UTF-8
 *
 * 배송정보 등록(dlvtype=03) 또는 배송완료 등록(dlvtype=01)을 토스페이먼츠에 보낸다.
 * XPayClient 를 쓰지 않고 HTTPS 로 직접 호출한다. 응답 본문이 OK 이면 성공이다.
 * 에스크로 결제는 배송정보 등록이나 배송완료 등록을 하지 않으면 정산되지 않는다.
 *
 * 토스페이먼츠 배송등록 서버는 EUC-KR 이다.
 * 이 페이지는 UTF-8 이므로 보내는 값은 iconv 로 EUC-KR 로 바꾸고, 받은 응답은 UTF-8 로 되돌린다.
 */

/* ---- 상점 설정 ★ 이 줄만 수정하세요 ---------------------------------- */

// 테스트
$serviceUrl = 'https://pgweb.tosspayments.com:9091/pg/wmp/testadmin/jsp/escrow/rcvdlvinfo.jsp';
// 서비스
// $serviceUrl = 'https://pgweb.tosspayments.com/pg/wmp/mertadmin/jsp/escrow/rcvdlvinfo.jsp';

// 상점 mertkey. 외부에 노출되지 않는 설정에서 읽도록 바꾸는 것을 권장합니다.
// ★ 실제 mertkey 를 입력한 채로 저장소에 커밋하지 마세요.
$mertkey = '';


/* ---- 요청 파라미터 --------------------------------------------------- */

$mid     = $_POST['mid'];
$oid     = $_POST['oid'];
$dlvtype = $_POST['dlvtype'];    // 03 배송정보 등록 / 01 배송완료 등록

$params = array('mid' => $mid, 'oid' => $oid, 'dlvtype' => $dlvtype);

if ($dlvtype === '03') {
    // 배송정보 등록 필수
    $params['dlvdate']     = $_POST['dlvdate'];       // 발송일시. yyyyMMddHHmm
    $params['dlvcompcode'] = $_POST['dlvcompcode'];   // 택배사 코드
    $params['dlvno']       = $_POST['dlvno'];         // 운송장번호

    // 선택 : 필요한 줄의 주석만 푸세요 (입력 화면에도 같은 이름의 입력란을 추가)
    // $params['dlvworker']    = $_POST['dlvworker'];      // 배송자 성명
    // $params['dlvworkertel'] = $_POST['dlvworkertel'];   // 배송자 연락처

    // hashdata = MD5(mid + oid + dlvdate + dlvcompcode + dlvno + mertkey)   ※ dlvtype 은 넣지 않는다
    $hashdata = md5($mid . $oid . $params['dlvdate'] . $params['dlvcompcode'] . $params['dlvno'] . $mertkey);
} else {
    // 배송완료 등록 필수
    $params['rcvdate']     = $_POST['rcvdate'];       // 실수령일시. yyyyMMddHHmm
    $params['rcvname']     = $_POST['rcvname'];       // 실수령인
    $params['rcvrelation'] = $_POST['rcvrelation'];   // 수령인과의 관계

    // hashdata = MD5(mid + oid + dlvtype + rcvdate + mertkey)   ※ dlvtype(01)을 넣는다
    $hashdata = md5($mid . $oid . $dlvtype . $params['rcvdate'] . $mertkey);
}

// 선택 : 상품이 여러 개이고 상품별로 등록할 때만 사용
// $params['productid'] = $_POST['productid'];   // 결제 때 보낸 에스크로 상품번호

$params['hashdata'] = $hashdata;

/* ---- EUC-KR 변환 (토스페이먼츠 배송등록 서버는 EUC-KR) ----------------- */

foreach ($params as $name => $value) {
    $params[$name] = iconv('UTF-8', 'EUC-KR', $value);
}

/* ---- 전송 (application/x-www-form-urlencoded, EUC-KR) --------------- */

$body = http_build_query($params);

$ch = curl_init($serviceUrl);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded; charset=EUC-KR'));
$response = curl_exec($ch);
if ($response === false) {
    $result = '통신 실패: ' . curl_error($ch);
} else {
    $result = iconv('EUC-KR', 'UTF-8', $response);   // 응답(EUC-KR)을 화면 출력용 UTF-8 로
}
curl_close($ch);

// 응답 본문이 정확히 OK 이면 성공, 실패하면 "FAIL : 실패메시지"
$success = ($result === 'OK');
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>XPay 에스크로 배송등록 결과</title>
<style>
  body { font-family: sans-serif; font-size: 14px; max-width: 640px; margin: 20px; }
</style>
</head>
<body>

<h1>에스크로 배송등록 결과</h1>
<p><?php echo $success ? '등록 성공' : '등록 실패'; ?></p>
<p>응답: <code><?php echo $result; ?></code></p>

</body>
</html>
