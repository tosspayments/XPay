<?php
/*
 * [에스크로 처리결과 로그]  result_receive.php 가 포함(require)하는 파일 — UTF-8
 *
 * 처리결과를 로그 파일에 남긴다. 로그 경로를 상점 환경에 맞게 바꾸고, DB 처리 루틴을 추가하세요.
 * 이 파일은 출력이 없어야 하므로 PHP 닫는 태그를 쓰지 않는다.
 */

// ★ 로그를 남길 폴더. 웹에서 접근할 수 없는 경로를 사용하세요.
define('ESCROW_LOG_DIR', 'C:/lgdacom/log');

function escrow_write_success($noti) { escrow_write_log('escrow_success.log', $noti); return true; }
function escrow_write_failure($noti) { escrow_write_log('escrow_failure.log', $noti); return true; }
function escrow_write_hasherr($noti) { escrow_write_log('escrow_hasherr.log', $noti); return true; }

function escrow_write_log($fileName, $noti)
{
    $labels = array('결과구분', '상점ID', '토스페이먼츠 거래번호', '상점주문번호', '작업자 주민번호',
                    '작업자 PC IP', '작업자 PC MAC', '처리일시', '토스페이먼츠 인증키', '상품ID', '자체 인증키');
    $text = '작성일시 : ' . date('YmdHis') . "\r\n";
    foreach ($labels as $i => $label) {
        $text .= $label . ' : ' . (isset($noti[$i]) ? $noti[$i] : '') . "\r\n";
    }
    file_put_contents(ESCROW_LOG_DIR . '/' . $fileName, $text, FILE_APPEND);
}
