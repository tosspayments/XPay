<%
' [에스크로 처리결과 로그]  result_receive.asp 가 포함(include)하는 파일 — UTF-8
'
' 처리결과를 로그 파일에 남긴다. 로그 경로를 상점 환경에 맞게 바꾸고, DB 처리 루틴을 추가하세요.

' ★ 로그를 남길 폴더. 웹에서 접근할 수 없는 경로를 사용하세요.
Const ESCROW_LOG_DIR = "C:\lgdacom\log"

Function escrow_write_success(noti)
    escrow_write_log "escrow_success.log", noti
    escrow_write_success = True
End Function

Function escrow_write_failure(noti)
    escrow_write_log "escrow_failure.log", noti
    escrow_write_failure = True
End Function

Function escrow_write_hasherr(noti)
    escrow_write_log "escrow_hasherr.log", noti
    escrow_write_hasherr = True
End Function

Sub escrow_write_log(fileName, noti)
    labels = Array("결과구분", "상점ID", "토스페이먼츠 거래번호", "상점주문번호", "작업자 주민번호", _
                   "작업자 PC IP", "작업자 PC MAC", "처리일시", "토스페이먼츠 인증키", "상품ID", "자체 인증키")
    text = "작성일시 : " & Now() & vbCrLf
    For idx = 0 To UBound(labels)
        text = text & labels(idx) & " : " & noti(idx) & vbCrLf
    Next
    Set fso = Server.CreateObject("Scripting.FileSystemObject")
    Set logFile = fso.OpenTextFile(ESCROW_LOG_DIR & "\" & fileName, 8, True, -1)   ' 8 = 이어쓰기, -1 = 유니코드
    logFile.Write text
    logFile.Close
End Sub
%>
