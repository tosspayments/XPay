<%@ CodePage=65001 Language="VBScript" %>
<!-- #include file="md5.asp" -->
<%
' [에스크로 배송등록 송신 페이지]  토스페이먼츠 XPay — UTF-8
'
' 배송정보 등록(dlvtype=03) 또는 배송완료 등록(dlvtype=01)을 토스페이먼츠에 보낸다.
' XPayClient 를 쓰지 않고 HTTPS 로 직접 호출한다. 응답 본문이 OK 이면 성공이다.
' 에스크로 결제는 배송정보 등록이나 배송완료 등록을 하지 않으면 정산되지 않는다.
'
' 토스페이먼츠 배송등록 서버는 EUC-KR 이다.
' 이 페이지는 UTF-8 이므로 보내는 값은 EUC-KR 로 인코딩하고, 받은 응답은 EUC-KR 로 읽는다.
Response.CharSet = "UTF-8"

' ---- 상점 설정 ★ 이 줄만 수정하세요 ----------------------------------

' 테스트
serviceUrl = "https://pgweb.tosspayments.com:9091/pg/wmp/testadmin/jsp/escrow/rcvdlvinfo.jsp"
' 서비스
' serviceUrl = "https://pgweb.tosspayments.com/pg/wmp/mertadmin/jsp/escrow/rcvdlvinfo.jsp"

' 상점 mertkey. 외부에 노출되지 않는 설정에서 읽도록 바꾸는 것을 권장합니다.
' ★ 실제 mertkey 를 입력한 채로 저장소에 커밋하지 마세요.
mertkey = ""

' ---- 요청 파라미터 ---------------------------------------------------

mertid     = Request.Form("mid")   ' 상점아이디. (VBScript 는 대소문자를 구분하지 않아 mid 라는 변수명은 Mid 함수와 충돌하므로 mertid 를 쓴다.)
oid     = Request.Form("oid")
dlvtype = Request.Form("dlvtype")    ' 03 배송정보 등록 / 01 배송완료 등록

Set params = Server.CreateObject("Scripting.Dictionary")
params.Add "mid", mertid
params.Add "oid", oid
params.Add "dlvtype", dlvtype

If dlvtype = "03" Then
    ' 배송정보 등록 필수
    params.Add "dlvdate", Request.Form("dlvdate")           ' 발송일시. yyyyMMddHHmm
    params.Add "dlvcompcode", Request.Form("dlvcompcode")   ' 택배사 코드
    params.Add "dlvno", Request.Form("dlvno")               ' 운송장번호

    ' 선택 : 필요한 줄의 주석만 푸세요 (입력 화면에도 같은 이름의 입력란을 추가)
    ' params.Add "dlvworker", Request.Form("dlvworker")         ' 배송자 성명
    ' params.Add "dlvworkertel", Request.Form("dlvworkertel")   ' 배송자 연락처

    ' hashdata = MD5(mid + oid + dlvdate + dlvcompcode + dlvno + mertkey)   ※ dlvtype 은 넣지 않는다
    hashdata = md5(mertid & oid & params("dlvdate") & params("dlvcompcode") & params("dlvno") & mertkey)
Else
    ' 배송완료 등록 필수
    params.Add "rcvdate", Request.Form("rcvdate")           ' 실수령일시. yyyyMMddHHmm
    params.Add "rcvname", Request.Form("rcvname")           ' 실수령인
    params.Add "rcvrelation", Request.Form("rcvrelation")   ' 수령인과의 관계

    ' hashdata = MD5(mid + oid + dlvtype + rcvdate + mertkey)   ※ dlvtype(01)을 넣는다
    hashdata = md5(mertid & oid & dlvtype & params("rcvdate") & mertkey)
End If

' 선택 : 상품이 여러 개이고 상품별로 등록할 때만 사용
' params.Add "productid", Request.Form("productid")   ' 결제 때 보낸 에스크로 상품번호

params.Add "hashdata", hashdata

' ---- 전송 (application/x-www-form-urlencoded, EUC-KR) ---------------
' Server.URLEncode 는 현재 Response.CodePage 로 인코딩한다. 잠시 949(EUC-KR)로 바꿔 인코딩한 뒤 되돌린다.

body = ""
Response.CodePage = 949
For Each k In params.Keys
    If body <> "" Then body = body & "&"
    body = body & k & "=" & Server.URLEncode(params(k))
Next
Response.CodePage = 65001

On Error Resume Next
Set http = Server.CreateObject("MSXML2.ServerXMLHTTP")
http.Open "POST", serviceUrl, False
http.setRequestHeader "Content-Type", "application/x-www-form-urlencoded; charset=EUC-KR"
http.Send body
If Err.Number <> 0 Then
    result = "통신 실패: " & Err.Description
Else
    ' 응답(EUC-KR)을 화면 출력용으로 읽는다.
    result = ""
    Set stream = Server.CreateObject("ADODB.Stream")
    stream.Type = 1
    stream.Open
    stream.Write http.responseBody
    stream.Position = 0
    stream.Type = 2
    stream.Charset = "euc-kr"
    result = stream.ReadText
    stream.Close
    If Err.Number <> 0 Or result = "" Then
        ' ADODB.Stream 을 쓸 수 없는 환경이면 MSXML 이 해석한 본문을 쓴다. (OK 판정에는 영향 없음)
        Err.Clear
        result = http.responseText
    End If
End If
On Error GoTo 0

' 응답 본문이 정확히 OK 이면 성공, 실패하면 "FAIL : 실패메시지"
success = (result = "OK")
%>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>XPay 에스크로 배송등록 결과</title>
<style>
  body { font-family: sans-serif; font-size: 14px; max-width: 640px; margin: 20px; }
</style>
</head>
<body>

<h1>에스크로 배송등록 결과</h1>
<p><% If success Then Response.Write "등록 성공" Else Response.Write "등록 실패" %></p>
<p>응답: <code><%= result %></code></p>

</body>
</html>
