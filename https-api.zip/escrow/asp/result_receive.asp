<%@ CodePage=65001 Language="VBScript" %>
<!-- #include file="md5.asp" -->
<!-- #include file="escrow_write.asp" -->
<%
' [에스크로 처리결과 수신 페이지]  토스페이먼츠 XPay — UTF-8
'
' 구매자의 수령확인·구매취소요청, 택배사 배송완료 결과를 토스페이먼츠가 이 페이지로 보낸다. (서버 간 호출)
' 수신 URL 은 techsupport@tosspayments.com 으로 요청해 등록한다. URL 은 하나만 설정할 수 있다.
'
'   - 이 페이지에는 HTML 태그나 스크립트를 출력하지 않는다. 결과를 반영했으면 "OK" 만 출력한다.
'   - 응답을 받지 못하면 30분 간격으로 최대 10번 다시 보낸다.
'     같은 결과가 다시 올 수 있으므로 oid, tid, txtype 으로 이미 반영한 결과인지 확인한다.
'   - hash 오류가 나면 원인을 확인해 바로 대처한다.
Response.CharSet = "UTF-8"
Response.ContentType = "text/plain"

' ---- 상점 설정 ★ 이 줄만 수정하세요 ----------------------------------

' 상점 mertkey. 외부에 노출되지 않는 설정에서 읽도록 바꾸는 것을 권장합니다.
' ★ 실제 mertkey 를 입력한 채로 저장소에 커밋하지 마세요.
mertkey = ""

' ---- 수신 파라미터 ---------------------------------------------------

txtype    = Request.Form("txtype")     ' C 수령확인결과 / R 구매취소요청 / S 택배사 배송완료 / N N/C 처리완료
mertid       = Request.Form("mid")   ' 상점아이디. (VBScript 는 대소문자를 구분하지 않아 mid 라는 변수명은 Mid 함수와 충돌하므로 mertid 를 쓴다.)
oid       = Request.Form("oid")        ' 주문번호
tid       = Request.Form("tid")        ' 토스페이먼츠 거래번호
productid = Request.Form("productid")  ' 상품 ID. 기본값 1
ssn       = Request.Form("ssn")        ' 작업자 주민번호. 개인정보보호법에 따라 "." 으로 전송
ip        = Request.Form("ip")         ' 작업자 PC IP. "." 으로 전송
mac       = Request.Form("mac")        ' 작업자 PC MAC. "." 으로 전송
resdate   = Request.Form("resdate")    ' 처리일시. yyyyMMddHHmmss
hashdata  = Request.Form("hashdata")   ' 위변조 검증용 인증키

' hashdata = MD5(mid + oid + tid + txtype + productid + ssn + ip + mac + resdate + mertkey)
myHash = md5(mertid & oid & tid & txtype & productid & ssn & ip & mac & resdate & mertkey)

noti = Array(txtype, mertid, tid, oid, ssn, ip, mac, resdate, hashdata, productid, myHash)

resp = False
If myHash = hashdata Then
    ' 해시 검증 성공. 결과를 상점 시스템(DB)에 반영하세요.
    resp = escrow_write_success(noti)
Else
    ' 해시 검증 실패. 로그를 남기고 원인을 확인하세요.
    escrow_write_hasherr noti
End If

' 지금까지의 출력을 비운 뒤 결과만 쓴다.
Response.Clear
If resp Then
    Response.Write "OK"
Else
    Response.Write "FAIL"
End If
%>