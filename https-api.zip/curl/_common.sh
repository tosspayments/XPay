#!/usr/bin/env bash
# 공통 설정. 실행 전에 값을 입력합니다. mertkey가 들어 있으므로 이 파일을 수정한 채로 커밋하지 않습니다.
MID="상점아이디"
MERTKEY="상점 mertkey"

md5hex()    { printf '%s' "$1" | (md5sum 2>/dev/null || md5 -q) | awk '{print $1}'; }
sha512hex() { printf '%s' "$1" | (sha512sum 2>/dev/null || shasum -a 512) | awk '{print $1}'; }
