#!/usr/bin/env bash
# 일자별 거래조회. 사용법: ./trx-daily.sh 20260914 [TRX|REV] [service]
#   세 번째 인자를 생략하면 테스트 환경으로 호출합니다. 테스트는 테스트 상점아이디(앞에 t)와 그 mertkey 를 _common.sh 에 넣습니다.
set -eu
cd "$(dirname "$0")" && . ./_common.sh
TRXDATE="${1:?조회 일자(yyyyMMdd)를 입력하세요}"
SERVICECODE="${2:-TRX}"     # TRX: 승인 내역, REV: 취소 내역
if [ "${3:-test}" = "service" ]; then
  URL="https://pgweb.tosspayments.com/pg/wmp/outerpage/trxdown.jsp"
else
  URL="https://pgweb.tosspayments.com/pg/wmp/testadmin/outerpage/trxdown.jsp"
fi
KEY=$(md5hex "${MID}${MERTKEY}")

curl -sS -G "$URL" \
  --data-urlencode "mertid=${MID}" \
  --data-urlencode "servicecode=${SERVICECODE}" \
  --data-urlencode "trxdate=${TRXDATE}" \
  --data-urlencode "key=${KEY}" \
  -o "${MID}_${SERVICECODE}_${TRXDATE}.dat"
echo "저장: ${MID}_${SERVICECODE}_${TRXDATE}.dat"
