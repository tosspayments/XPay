#!/usr/bin/env bash
# 일자별 현금영수증조회. 사용법: ./cashreceipt-daily.sh 20260914
set -eu
cd "$(dirname "$0")" && . ./_common.sh
TRXDATE="${1:?거래일(yyyyMMdd)을 입력하세요}"
KEY=$(md5hex "${MID}${MERTKEY}")

curl -sS -G "https://pgweb.tosspayments.com/pg/wmp/outerpage/trxdown.jsp" \
  --data-urlencode "mertid=${MID}" \
  --data-urlencode "servicecode=CASH" \
  --data-urlencode "trxdate=${TRXDATE}" \
  --data-urlencode "key=${KEY}" \
  -o "${MID}_CASH_${TRXDATE}.dat"
echo "저장: ${MID}_CASH_${TRXDATE}.dat"
