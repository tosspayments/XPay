# HTTPS 직접 호출 (curl)

XPayClient 없이 HTTPS로 호출하는 기능의 curl 예제입니다. 먼저 `_common.sh`에 상점아이디와 mertkey를 입력합니다.

| 스크립트 | 기능 | 예시 |
| --- | --- | --- |
| `trx-daily.sh` | 일자별 거래조회 (승인 `TRX`, 취소 `REV`). 기본 테스트 환경, `service`를 붙이면 서비스 환경 | `./trx-daily.sh 20260914 TRX` |
| `settlement-daily.sh` | 일자별 정산조회 (`ADJ`) | `./settlement-daily.sh 20260914` |
| `cashreceipt-daily.sh` | 일자별 현금영수증조회 (`CASH`) | `./cashreceipt-daily.sh 20260914` |
| `installment.sh` | 무이자할부 조회 (SHA-512 해쉬) | `./installment.sh 20260914` |
| `escrow-delivery.sh` | 에스크로 배송정보 등록 (기본 테스트 환경) | `./escrow-delivery.sh ORDER001 202609141525 CJ 123456789012` |

> **참고**
> `trx-daily.sh`는 테스트 조회 URL이 추가되어 기본이 테스트 환경입니다. 이전처럼 서비스(라이브) 내역을 받으려면 `./trx-daily.sh 20260914 TRX service`로 실행합니다.

> **주의**
> 조회용 key와 해쉬는 mertkey로 만듭니다. 반드시 상점 서버에서 호출하고, `_common.sh`에 mertkey를 입력한 채로 커밋하지 않습니다.

응답 파일의 형식은 연동 가이드의 각 페이지(일자별 거래조회, 일자별 정산조회, 일자별 현금영수증조회, 무이자할부 조회, 에스크로)를 참고합니다.
