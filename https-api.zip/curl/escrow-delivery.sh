#!/usr/bin/env bash
# 에스크로 배송정보 등록(dlvtype=03). 사용법: ./escrow-delivery.sh 주문번호 202609141525 CJ 운송장번호 [service]
set -eu
cd "$(dirname "$0")" && . ./_common.sh
OID="${1:?주문번호}"; DLVDATE="${2:?발송일시(yyyyMMddHHmm)}"; DLVCOMPCODE="${3:?택배사 코드}"; DLVNO="${4:?운송장번호}"
if [ "${5:-test}" = "service" ]; then
  URL="https://pgweb.tosspayments.com/pg/wmp/mertadmin/jsp/escrow/rcvdlvinfo.jsp"
else
  URL="https://pgweb.tosspayments.com:9091/pg/wmp/testadmin/jsp/escrow/rcvdlvinfo.jsp"
fi
HASHDATA=$(md5hex "${MID}${OID}${DLVDATE}${DLVCOMPCODE}${DLVNO}${MERTKEY}")

curl -sS -X POST "$URL" \
  --data-urlencode "mid=${MID}" \
  --data-urlencode "oid=${OID}" \
  --data-urlencode "dlvtype=03" \
  --data-urlencode "dlvdate=${DLVDATE}" \
  --data-urlencode "dlvcompcode=${DLVCOMPCODE}" \
  --data-urlencode "dlvno=${DLVNO}" \
  --data-urlencode "hashdata=${HASHDATA}"
echo
