#!/usr/bin/env bash
# 무이자할부 조회. 사용법: ./installment.sh 20260914
set -eu
cd "$(dirname "$0")" && . ./_common.sh
LGD_DATE="${1:?조회 일자(yyyyMMdd)를 입력하세요}"
HASH=$(sha512hex "${MID}${MERTKEY}")   # 거래·정산 조회와 달리 SHA-512

curl -sS -G "https://pgweb.tosspayments.com/MpFlowCtrl" \
  --data-urlencode "eventDiv1=nointerestapi" \
  --data-urlencode "eventDiv2=getNoInterest" \
  --data-urlencode "LGD_MERTID=${MID}" \
  --data-urlencode "LGD_DATE=${LGD_DATE}" \
  --data-urlencode "LGD_HASH_DATA=${HASH}" \
  -o "nointerest_${LGD_DATE}.xml"
echo "저장: nointerest_${LGD_DATE}.xml (EUC-KR)"
