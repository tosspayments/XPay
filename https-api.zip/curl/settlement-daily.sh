#!/usr/bin/env bash
# 일자별 정산조회. 사용법: ./settlement-daily.sh 20260914   (매출일. 전일 매출분까지 조회 가능)
set -eu
cd "$(dirname "$0")" && . ./_common.sh
TRXDATE="${1:?매출일(yyyyMMdd)을 입력하세요}"
KEY=$(md5hex "${MID}${MERTKEY}")

curl -sS -G "https://pgweb.tosspayments.com/pg/wmp/outerpage/trxdown.jsp" \
  --data-urlencode "mertid=${MID}" \
  --data-urlencode "servicecode=ADJ" \
  --data-urlencode "trxdate=${TRXDATE}" \
  --data-urlencode "key=${KEY}" \
  -o "${MID}_ADJ_${TRXDATE}.dat"
echo "저장: ${MID}_ADJ_${TRXDATE}.dat"
