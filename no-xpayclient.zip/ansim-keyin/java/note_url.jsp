<%@ page contentType="text/plain; charset=UTF-8" pageEncoding="UTF-8" trimDirectiveWhitespaces="true" %>
<%@ page import="java.security.MessageDigest, java.util.LinkedHashMap, java.util.Map" %>
<%--
 * [안심키인 결과수신 페이지 (LGD_NOTEURL)]  토스페이먼츠 XPay 안심키인 — UTF-8
 *
 * 결제창이 결제 결과를 이 페이지로 보낸다. (서버 간 호출)
 *   1. 응답 해시를 만들어 LGD_HASHDATA 와 비교한다.
 *   2. 해시가 일치하면 LGD_RESPCODE 에 따라 성공·실패를 DB 에 반영한다.
 *   3. DB 처리가 끝났으면 "OK" 만 출력한다. 그 외 값이면 2시간 동안 다시 전송된다.
--%>
<%
    request.setCharacterEncoding("UTF-8");

    /* ---- 상점 설정 ★ 이 줄만 수정하세요 ---------------------------------- */

    // 상점 mertkey. 외부에 노출되지 않는 설정에서 읽도록 바꾸는 것을 권장합니다.
    // ★ 실제 mertkey 를 입력한 채로 저장소에 커밋하지 마세요.
    String LGD_MERTKEY = "";

    /* ==================================================================
     * 결과 파라미터
     * ==================================================================
     * 주요 값은 활성, 나머지는 주석 처리해 두었습니다.
     * 필요한 줄의 // 만 지우면 recv 에 함께 담깁니다.
     */
    String[][] names = {
        { "LGD_RESPCODE",         "응답코드. 0000 이면 성공" },
        { "LGD_RESPMSG",          "응답메시지" },
        { "LGD_MID",              "상점아이디" },
        { "LGD_OID",              "주문번호" },
        { "LGD_AMOUNT",           "결제금액" },
        { "LGD_TID",              "토스페이먼츠 거래번호. 취소에 필요하므로 반드시 저장" },
        { "LGD_PAYTYPE",          "결제수단코드. 신용카드 SC0010" },
        { "LGD_PAYDATE",          "결제일시. yyyyMMddHHmmss" },
        { "LGD_TIMESTAMP",        "타임스탬프" },
        { "LGD_HASHDATA",         "위변조 검증용 해시" },
        { "LGD_FINANCECODE",      "결제기관코드" },
        { "LGD_FINANCENAME",      "결제기관명" },
        { "LGD_FINANCEAUTHNUM",   "결제기관 승인번호" },
        { "LGD_CARDINSTALLMONTH", "할부개월" },

        /* ===== 추가 결과 ===== */
        // { "LGD_TAXFREEAMOUNT",     "면세금액" },
        // { "LGD_ESCROWYN",          "에스크로 적용. Y / N" },
        // { "LGD_BUYER",             "구매자명" },
        // { "LGD_BUYERID",           "구매자 아이디" },
        // { "LGD_BUYERPHONE",        "구매자 휴대폰번호" },
        // { "LGD_BUYEREMAIL",        "구매자 이메일" },
        // { "LGD_BUYERADDRESS",      "구매자 주소" },
        // { "LGD_BUYERSSN",          "구매자 생년월일 또는 사업자번호" },
        // { "LGD_PRODUCTINFO",       "상품명" },
        // { "LGD_PRODUCTCODE",       "상품코드" },
        // { "LGD_RECEIVER",          "수취인" },
        // { "LGD_RECEIVERPHONE",     "수취인 전화번호" },
        // { "LGD_CARDNUM",           "신용카드번호. 일반 가맹점은 * 처리" },
        // { "LGD_CARDACQUIRER",      "카드 매입사 코드" },
        // { "LGD_CARDGUBUN1",        "0 개인 / 1 법인 / 9 미확인" },
        // { "LGD_CARDGUBUN2",        "0 신용 / 1 체크 / 2 기프트 / 9 미확인" },
        // { "LGD_CARDNOINTEREST_YN", "카드사부담 무이자. 1 무이자 / 0 일반" },
        // { "LGD_CARDNOINTYN",       "상점부담 무이자. 1 무이자 / 0 일반" },
        // { "LGD_DCNO",              "즉시할인 적용 거래면 DC" },
        // { "LGD_DISCOUNTUSEYN",     "즉시할인 적용. 1 적용 / 0 미적용" },
        // { "LGD_DISCOUNTUSEAMOUNT", "즉시할인 금액" },
        // { "LGD_PCANCELFLAG",       "부분취소 가능. 1 가능 / 0 불가" },
        // { "LGD_PCANCELSTR",        "부분취소 불가 사유. 가능하면 0" },
    };

    Map<String, String> recv = new LinkedHashMap<String, String>();
    for (String[] n : names) {
        recv.put(n[0], request.getParameter(n[0]));
    }

    // 응답 해시 = MD5(LGD_MID + LGD_OID + LGD_AMOUNT + LGD_RESPCODE + LGD_TIMESTAMP + mertkey)
    MessageDigest md = MessageDigest.getInstance("MD5");
    byte[] digest = md.digest((recv.get("LGD_MID") + recv.get("LGD_OID") + recv.get("LGD_AMOUNT")
                    + recv.get("LGD_RESPCODE") + recv.get("LGD_TIMESTAMP") + LGD_MERTKEY).getBytes("UTF-8"));
    StringBuffer strBuf = new StringBuffer();
    for (int i = 0; i < digest.length; i++) {
        int c = digest[i] & 0xff;
        if (c <= 15) strBuf.append("0");
        strBuf.append(Integer.toHexString(c));
    }
    String hash = strBuf.toString();

    String result;
    if (!hash.equals(recv.get("LGD_HASHDATA"))) {
        // 해시 불일치. DB 에 반영하지 않고 로그를 남긴 뒤 원인을 확인하세요.
        result = "해시 검증 실패";
    } else {
        boolean isDBOK = true;   // DB 처리에 실패하면 false
        if ("0000".equals(recv.get("LGD_RESPCODE"))) {
            // 결제 성공을 DB 에 반영하세요. LGD_TID 는 취소에 필요하므로 반드시 저장합니다.
        } else {
            // 결제 실패를 DB 에 반영하세요.
        }
        result = isDBOK ? "OK" : "상점 DB 처리 실패";
    }

    out.print(result);
%>
