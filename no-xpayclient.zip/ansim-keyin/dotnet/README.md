# 안심키인 결제창

구매자의 신용카드 정보를 안심키인 결제창에 입력해 결제합니다. 결제창이 승인까지 처리하므로 **XPayClient 라이브러리를 사용하지 않습니다.** 결제 결과는 결제창이 `LGD_NOTEURL`로 서버 간 전달합니다.

## 흐름

```text
pay_req_na.aspx → (안심키인 결제창, 승인 처리) → note_url.aspx (서버 간 호출) → "OK" 응답
```

## 수정할 곳

| 파일 | 내용 |
| --- | --- |
| `pay_req_na.aspx` | 맨 위 "상점 설정"의 `CST_PLATFORM`, `CST_MID`. `LGD_NOTEURL`을 실제 주소로 바꿉니다. |
| `note_url.aspx` | `LGD_MERTKEY`를 입력하고, 결제 성공·실패 DB 처리를 구현합니다. |

선택 파라미터(`LGD_RETURNURL`, `LGD_CUSTOM_RESULTTYPE` 등)는 주석으로 들어 있습니다.

> **참고**
> `note_url.aspx`는 XPayClient 없이 mertkey로 응답 해시를 직접 계산합니다. 테스트 후 커밋하기 전에 mertkey를 반드시 지우고, 운영 코드에서는 외부에 노출되지 않는 설정에서 읽도록 바꿉니다.

## 연동 가이드

안심키인 결제창
