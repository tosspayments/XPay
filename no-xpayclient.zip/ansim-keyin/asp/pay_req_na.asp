<%@ CodePage=65001 Language="VBScript" %>
<%
Response.CharSet = "UTF-8"
%>
<%
' [안심키인 결제요청 페이지]  토스페이먼츠 XPay 안심키인 (Non-ActiveX) — UTF-8
'
' 안심키인 결제창이 승인까지 처리하므로 XPayClient 라이브러리를 쓰지 않는다.
' 결제 결과는 결제창이 LGD_NOTEURL(note_url.asp)로 서버 간 전달한다.
' 선택 파라미터는 주석으로 넣어 두었으니 필요한 줄의 주석만 풀면 된다.
%>
<%

    ' ---- 상점 설정 ★ 이 줄만 수정하세요 ----------------------------------

    CST_PLATFORM = "test"   ' test 또는 service
    CST_MID = "상점아이디"   ' 토스페이먼츠에서 발급한 상점아이디 ('t' 제외)

    ' 결제결과 DB 처리 페이지(LGD_NOTEURL). 실제 주소로 바꾸세요. 표준포트(80, 443)만 사용할 수 있습니다.
    LGD_NOTEURL = "https://상점도메인/AnsimKeyin/note_url.asp"

    ' ----------------------------------------------------------------------

    If CST_PLATFORM = "test" Then   ' 테스트는 앞에 't'
        LGD_MID = "t" & CST_MID
    Else
        LGD_MID = CST_MID
    End If
    LGD_OID = "test" & Year(Now) & Right("0" & Month(Now), 2) & Right("0" & Day(Now), 2) & Right("0" & Hour(Now), 2) & Right("0" & Minute(Now), 2) & Right("0" & Second(Now), 2)
%>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>XPay 안심키인 결제요청</title>
<style>
  body { font-family: sans-serif; font-size: 14px; max-width: 640px; margin: 20px; }
</style>
</head>
<body>

<h1>안심키인 결제요청</h1>

<form method="post" id="LGD_PAYINFO">

  <p>주문번호 (LGD_OID)<br><input type="text" name="LGD_OID" value="<%= LGD_OID %>" size="30" maxlength="63" readonly></p>
  <p>결제금액 (LGD_AMOUNT)<br><input type="number" name="LGD_AMOUNT" value="1004" required></p>
  <p>구매자명 (LGD_BUYER)<br><input type="text" name="LGD_BUYER" value="홍길동" size="30" maxlength="10" required></p>
  <p>상품명 (LGD_PRODUCTINFO)<br><input type="text" name="LGD_PRODUCTINFO" value="테스트상품" size="40" maxlength="128" required></p>

  <p><button type="button" onclick="doAnsimKeyin()">결제요청</button></p>

  <!-- ================================================================
       필수 파라미터
       ================================================================ -->

  <input type="hidden" name="LGD_MID"       value="<%= LGD_MID %>">

  <!-- N: Non-ActiveX. N 이외의 값을 보내거나 생략하면 ActiveX 로 동작한다. -->
  <input type="hidden" name="LGD_ACTIVEXYN" value="N">

  <!-- ================================================================
       이 샘플이 켜 둔 파라미터
       ================================================================ -->

  <!-- 결제 결과를 받아 DB 에 반영할 페이지 -->
  <input type="hidden" name="LGD_NOTEURL" value="<%= LGD_NOTEURL %>">

  <!-- 문자 인코딩. 기본값이 EUC-KR 이므로 UTF-8 을 반드시 명시한다. -->
  <input type="hidden" name="LGD_ENCODING"         value="UTF-8">
  <input type="hidden" name="LGD_ENCODING_NOTEURL" value="UTF-8">

  <!-- ================================================================
       선택 파라미터
       필요한 줄의 주석만 풀어 사용하세요. value 는 예시값입니다.
       ================================================================ -->

  <!-- 결제 완료 후 결과 페이지로 이동하려면 아래 두 줄을 함께 사용합니다. -->
  <!-- <input type="hidden" name="LGD_RETURNURL"         value="https://상점도메인/return_url.asp">  결과 페이지. 최대 255자 -->
  <!-- <input type="hidden" name="LGD_CUSTOM_RESULTTYPE" value="SUBMIT">  LGD_RETURNURL 사용 시 SUBMIT. 없으면 결제창이 그대로 남음 -->
  <!-- <input type="hidden" name="LGD_TAXFREEAMOUNT"     value="0">  면세금액. 부분면세 계약 시 -->

</form>

<script>
  function doAnsimKeyin() {
    // CST_PLATFORM: test(테스트) 또는 service(서비스)
    open_paymentwindow(document.getElementById('LGD_PAYINFO'), '<%= CST_PLATFORM %>');
  }
</script>

</body>
<!-- 안심키인 결제창 스크립트는 반드시 </body> 아래에 둔다. -->
<script src="https://xpay.tosspayments.com/ansim-keyin/js/ansim_crossplatform.js"></script>
</html>
