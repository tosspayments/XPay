<%@ CodePage=65001 Language="VBScript" %>
<!-- #include file="md5.asp" -->
<%
Response.CharSet = "UTF-8"
Response.ContentType = "text/plain"
%>
<%
' [안심키인 결과수신 페이지 (LGD_NOTEURL)]  토스페이먼츠 XPay 안심키인 — UTF-8
'
' 결제창이 결제 결과를 이 페이지로 보낸다. (서버 간 호출)
' 1. 응답 해시를 만들어 LGD_HASHDATA 와 비교한다.
' 2. 해시가 일치하면 LGD_RESPCODE 에 따라 성공·실패를 DB 에 반영한다.
' 3. DB 처리가 끝났으면 "OK" 만 출력한다. 그 외 값이면 2시간 동안 다시 전송된다.
%>
<%

    ' ---- 상점 설정 ★ 이 줄만 수정하세요 ----------------------------------

    ' 상점 mertkey. 외부에 노출되지 않는 설정에서 읽도록 바꾸는 것을 권장합니다.
    ' ★ 실제 mertkey 를 입력한 채로 저장소에 커밋하지 마세요.
    LGD_MERTKEY = ""

' ==================================================================
' 결과 파라미터
' ==================================================================
' 주요 값은 활성, 나머지는 주석 처리해 두었습니다.
' 필요한 줄의 ' 만 지우면 recv 에 함께 담깁니다.
    Set names = Server.CreateObject("Scripting.Dictionary")
        names.Add "LGD_RESPCODE", "응답코드. 0000 이면 성공"
        names.Add "LGD_RESPMSG", "응답메시지"
        names.Add "LGD_MID", "상점아이디"
        names.Add "LGD_OID", "주문번호"
        names.Add "LGD_AMOUNT", "결제금액"
        names.Add "LGD_TID", "토스페이먼츠 거래번호. 취소에 필요하므로 반드시 저장"
        names.Add "LGD_PAYTYPE", "결제수단코드. 신용카드 SC0010"
        names.Add "LGD_PAYDATE", "결제일시. yyyyMMddHHmmss"
        names.Add "LGD_TIMESTAMP", "타임스탬프"
        names.Add "LGD_HASHDATA", "위변조 검증용 해시"
        names.Add "LGD_FINANCECODE", "결제기관코드"
        names.Add "LGD_FINANCENAME", "결제기관명"
        names.Add "LGD_FINANCEAUTHNUM", "결제기관 승인번호"
        names.Add "LGD_CARDINSTALLMONTH", "할부개월"

        ' ===== 추가 결과 =====
        ' names.Add "LGD_TAXFREEAMOUNT", "면세금액"
        ' names.Add "LGD_ESCROWYN", "에스크로 적용. Y / N"
        ' names.Add "LGD_BUYER", "구매자명"
        ' names.Add "LGD_BUYERID", "구매자 아이디"
        ' names.Add "LGD_BUYERPHONE", "구매자 휴대폰번호"
        ' names.Add "LGD_BUYEREMAIL", "구매자 이메일"
        ' names.Add "LGD_BUYERADDRESS", "구매자 주소"
        ' names.Add "LGD_BUYERSSN", "구매자 생년월일 또는 사업자번호"
        ' names.Add "LGD_PRODUCTINFO", "상품명"
        ' names.Add "LGD_PRODUCTCODE", "상품코드"
        ' names.Add "LGD_RECEIVER", "수취인"
        ' names.Add "LGD_RECEIVERPHONE", "수취인 전화번호"
        ' names.Add "LGD_CARDNUM", "신용카드번호. 일반 가맹점은 * 처리"
        ' names.Add "LGD_CARDACQUIRER", "카드 매입사 코드"
        ' names.Add "LGD_CARDGUBUN1", "0 개인 / 1 법인 / 9 미확인"
        ' names.Add "LGD_CARDGUBUN2", "0 신용 / 1 체크 / 2 기프트 / 9 미확인"
        ' names.Add "LGD_CARDNOINTEREST_YN", "카드사부담 무이자. 1 무이자 / 0 일반"
        ' names.Add "LGD_CARDNOINTYN", "상점부담 무이자. 1 무이자 / 0 일반"
        ' names.Add "LGD_DCNO", "즉시할인 적용 거래면 DC"
        ' names.Add "LGD_DISCOUNTUSEYN", "즉시할인 적용. 1 적용 / 0 미적용"
        ' names.Add "LGD_DISCOUNTUSEAMOUNT", "즉시할인 금액"
        ' names.Add "LGD_PCANCELFLAG", "부분취소 가능. 1 가능 / 0 불가"
        ' names.Add "LGD_PCANCELSTR", "부분취소 불가 사유. 가능하면 0"

    Set recv = Server.CreateObject("Scripting.Dictionary")
    For Each k In names.Keys
        recv.Add k, Request.Form(k)
    Next

    ' 응답 해시 = MD5(LGD_MID + LGD_OID + LGD_AMOUNT + LGD_RESPCODE + LGD_TIMESTAMP + mertkey)
    hash = md5(recv("LGD_MID") & recv("LGD_OID") & recv("LGD_AMOUNT") & recv("LGD_RESPCODE") & recv("LGD_TIMESTAMP") & LGD_MERTKEY)

    Dim result
    If Not hash = recv("LGD_HASHDATA") Then
        ' 해시 불일치. DB 에 반영하지 않고 로그를 남긴 뒤 원인을 확인하세요.
        result = "해시 검증 실패"
    Else
        isDBOK = true   ' DB 처리에 실패하면 false
        If recv("LGD_RESPCODE") = "0000" Then
            ' 결제 성공을 DB 에 반영하세요. LGD_TID 는 취소에 필요하므로 반드시 저장합니다.
        Else
            ' 결제 실패를 DB 에 반영하세요.
        End If
        If isDBOK Then result = "OK" Else result = "상점 DB 처리 실패"
    End If

    ' 지시문 사이의 줄바꿈이 응답에 섞이지 않도록 지금까지의 출력을 비운 뒤 결과만 쓴다.
    Response.Clear
    Response.Write result
%>