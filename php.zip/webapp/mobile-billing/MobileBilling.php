<?php
/*
 * [휴대폰 빌링 결제 요청 페이지]  토스페이먼츠 XPay — UTF-8
 *
 * 휴대폰 결제를 빌링(LGD_AUTHMODE=BILLING)으로 요청한다.
 * 결제는 성공했지만 상점 DB 처리에 실패하면 Rollback() 으로 자동취소한다.
 */

/* ---- 상점 설정 ★ 이 줄만 수정하세요 ---------------------------------- */

// 토스페이먼츠에서 제공한 환경파일(conf/lgdacom.conf, conf/mall.conf) 디렉터리
$configPath = 'C:/lgdacom';


/* ---- 요청 파라미터 --------------------------------------------------- */

$CST_PLATFORM = $_POST['CST_PLATFORM'];   // test 또는 service
$LGD_MID      = ($CST_PLATFORM === 'test' ? 't' : '') . $_POST['CST_MID'];   // 테스트는 앞에 't'
$LGD_OID            = $_POST['LGD_OID'];
$LGD_AMOUNT         = $_POST['LGD_AMOUNT'];
$LGD_MOBILECOM      = $_POST['LGD_MOBILECOM'];
$LGD_MOBILENUM      = $_POST['LGD_MOBILENUM'];
$LGD_MOBILESSN      = $_POST['LGD_MOBILESSN'];
$LGD_PRODUCTINFO    = $_POST['LGD_PRODUCTINFO'];
$LGD_BUYER          = $_POST['LGD_BUYER'];

/* ---- 요청 ----------------------------------------------------------- */

require_once __DIR__ . '/../lgdacom/XPayClient.php';

// CST_PLATFORM 값에 따라 lgdacom.conf 의 test_url / url 이 선택된다.
$xpay = new XPayClient($configPath, $CST_PLATFORM);
if (!$xpay->Init_TX($LGD_MID)) {
    header('Content-Type: text/plain; charset=UTF-8');
    exit('상점아이디 설정을 확인하세요: ' . $xpay->Response_Msg());
}

$xpay->Set('LGD_TXNAME', 'Mobile');                         // 휴대폰 결제
$xpay->Set('LGD_AUTHMODE', 'BILLING');                      // 빌링 결제
$xpay->Set('LGD_OID', $LGD_OID);                            // 주문번호. 최대 64자
$xpay->Set('LGD_AMOUNT', $LGD_AMOUNT);                      // 결제금액. 숫자만
$xpay->Set('LGD_MOBILECOM', $LGD_MOBILECOM);                // 이동통신사. 1 SKT / 2 KT / 3 LG U+
$xpay->Set('LGD_MOBILENUM', $LGD_MOBILENUM);                // 휴대폰번호
$xpay->Set('LGD_MOBILESSN', $LGD_MOBILESSN);                // 생년월일
$xpay->Set('LGD_PRODUCTINFO', $LGD_PRODUCTINFO);            // 상품명
$xpay->Set('LGD_BUYER', $LGD_BUYER);                        // 구매자명
$xpay->Set('LGD_BUYERIP', $_SERVER['REMOTE_ADDR']);         // 요청한 구매자 IP

/* ---- 선택 파라미터 : 필요한 줄의 주석만 푸세요 (입력 화면에도 같은 이름의 입력란을 추가) ---- */
// $xpay->Set('LGD_BILLKEY', $_POST['LGD_BILLKEY']);           // 빌링키로 결제할 때 주석을 풉니다

$txOk     = $xpay->TX();          // lgdacom.conf 의 URL 로 통신
$respCode = $xpay->Response_Code();
$respMsg  = $xpay->Response_Msg();

// 응답 상세. 응답이 없으면 Response_Names() 가 null 을 반환한다.
$fields = array();
$names  = $xpay->Response_Names();
if (is_array($names)) {
    foreach ($names as $name) {
        $fields[$name] = $xpay->Response($name, 0);
    }
}

// 통신 성공 && 응답코드 "0000" 일 때만 성공. 그 외는 모두 실패로 처리한다.
$success = ($txOk && $respCode === '0000');

if ($success) {
    // 결제 성공 DB 처리를 여기에서 수행하세요.
    $isDBOK = true;
    if (!$isDBOK) {
        // 결제는 성공했지만 상점 DB 처리에 실패했다면 자동취소를 요청합니다.
        $tid = isset($fields['LGD_TID']) ? $fields['LGD_TID'] : '';
        $xpay->Rollback('상점 DB 처리 실패 [TID:' . $tid . ', OID:' . $LGD_OID . ']');
    }
} else {
    // 결제 실패 DB 처리를 여기에서 수행하세요.
}

$xpay->close();

/* ==================================================================
 * 응답 파라미터
 * ==================================================================
 * 주요 값은 활성, 나머지는 주석 처리해 두었습니다.
 * 필요한 줄의 // 만 지우면 화면에 함께 출력됩니다.
 */

$show = array(

    'LGD_RESPCODE'    => '응답코드. 0000 이면 성공',
    'LGD_RESPMSG'     => '응답메시지',
    'LGD_MID'         => '상점아이디',
    'LGD_OID'         => '주문번호',
    'LGD_TID'         => '토스페이먼츠 거래번호',
    'LGD_AMOUNT'      => '결제금액',
    'LGD_PAYDATE'     => '결제일시',
    'LGD_FINANCECODE' => '이동통신사 코드',
    'LGD_FINANCENAME' => '이동통신사명',
    'LGD_BILLKEY'     => '빌링키',

    /* ===== 기타 ===== */
    // 'LGD_PAYTYPE'  => '결제수단코드',

);
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>휴대폰 빌링 결제 결과</title>
<style>
  body { font-family: sans-serif; font-size: 14px; max-width: 860px; margin: 20px; }
  table { border-collapse: collapse; }
  th, td { border: 1px solid #ccc; padding: 4px 8px; text-align: left; vertical-align: top; }
</style>
</head>
<body>

<h1>휴대폰 빌링 결제 결과</h1>

<?php if (!$txOk): ?>
  <p>통신 실패 — 요청을 완료하지 못했습니다. (<?php echo $respCode; ?> <?php echo $respMsg; ?>)</p>
<?php elseif ($success): ?>
  <p>결제 성공</p>
<?php else: ?>
  <p>결제 실패 (<?php echo $respCode; ?> <?php echo $respMsg; ?>)</p>
<?php endif; ?>

<table>
  <tr><th>변수명</th><th>설명</th><th>값</th></tr>
<?php foreach ($show as $name => $desc): ?>
  <tr>
    <th><?php echo $name; ?></th>
    <td><?php echo $desc; ?></td>
    <td><?php echo isset($fields[$name]) ? $fields[$name] : ''; ?></td>
  </tr>
<?php endforeach; ?>
</table>

<?php
/* 명세에 없는 값까지 전부 확인하려면 아래 주석을 푸세요.

echo '<h2>수신된 전체 응답</h2><table>';
foreach ($fields as $name => $value) {
    echo '<tr><th>' . $name . '</th><td>' . $value . '</td></tr>';
}
echo '</table>';

*/
?>

<p>이 페이지는 샘플입니다. 실제 연동에서는 결과를 화면에 노출하지 말고 DB에 기록하세요.</p>

</body>
</html>
