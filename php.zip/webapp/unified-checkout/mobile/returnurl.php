<?php
/*
 * [인증결과 수신 페이지]  토스페이먼츠 XPay (모바일용) — UTF-8
 *
 * 결제창이 인증을 마치면 이 페이지(LGD_RETURNURL)로 이동한다.
 * 인증에 성공하면 받은 LGD_PAYKEY 로 payres.php 에 최종 결제를 요청한다.
 */


$LGD_RESPCODE = $_POST['LGD_RESPCODE'];
$LGD_RESPMSG  = $_POST['LGD_RESPMSG'];
$LGD_PAYKEY   = $_POST['LGD_PAYKEY'];
$LGD_MID      = $_POST['LGD_MID'];
$authOk       = ($LGD_RESPCODE === '0000');
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>XPay 인증결과</title>
</head>
<body<?php echo $authOk ? ' onload="document.getElementById(\'LGD_PAYRES\').submit();"' : ''; ?>>

<?php if ($authOk): ?>
  <p>최종 결제를 요청하고 있습니다.</p>
  <form method="post" name="LGD_PAYRES" id="LGD_PAYRES" action="payres.php">
    <input type="hidden" name="LGD_MID"    value="<?php echo $LGD_MID; ?>">
    <input type="hidden" name="LGD_PAYKEY" value="<?php echo $LGD_PAYKEY; ?>">
  </form>
<?php else: ?>
  <!-- 인증 실패에 대한 처리를 여기에 추가하세요. -->
  <p>인증 실패 — 결과코드 <?php echo $LGD_RESPCODE; ?>, <?php echo $LGD_RESPMSG; ?></p>
<?php endif; ?>

</body>
</html>
