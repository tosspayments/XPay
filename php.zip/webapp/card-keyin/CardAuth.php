<?php
/*
 * [카드 비인증 결제 요청 페이지]  토스페이먼츠 XPay — UTF-8
 *
 * 카드번호를 직접 받아 CardAuth 거래로 승인을 요청한다.
 * 결제는 성공했지만 상점 DB 처리에 실패하면 Rollback() 으로 자동취소한다.
 */

/* ---- 상점 설정 ★ 이 줄만 수정하세요 ---------------------------------- */

// 토스페이먼츠에서 제공한 환경파일(conf/lgdacom.conf, conf/mall.conf) 디렉터리
$configPath = 'C:/lgdacom';


/* ---- 요청 파라미터 --------------------------------------------------- */

$CST_PLATFORM = $_POST['CST_PLATFORM'];   // test 또는 service
$LGD_MID      = ($CST_PLATFORM === 'test' ? 't' : '') . $_POST['CST_MID'];   // 테스트는 앞에 't'
$LGD_OID            = $_POST['LGD_OID'];
$LGD_AMOUNT         = $_POST['LGD_AMOUNT'];
$LGD_BUYER          = $_POST['LGD_BUYER'];
$LGD_PRODUCTINFO    = $_POST['LGD_PRODUCTINFO'];
$LGD_PAN            = $_POST['LGD_PAN'];
$LGD_INSTALL        = $_POST['LGD_INSTALL'];
$VBV_ECI            = $_POST['VBV_ECI'];
$LGD_EXPYEAR        = $_POST['LGD_EXPYEAR'];
$LGD_EXPMON         = $_POST['LGD_EXPMON'];

/* ---- 요청 ----------------------------------------------------------- */

require_once __DIR__ . '/../lgdacom/XPayClient.php';

// CST_PLATFORM 값에 따라 lgdacom.conf 의 test_url / url 이 선택된다.
$xpay = new XPayClient($configPath, $CST_PLATFORM);
if (!$xpay->Init_TX($LGD_MID)) {
    header('Content-Type: text/plain; charset=UTF-8');
    exit('상점아이디 설정을 확인하세요: ' . $xpay->Response_Msg());
}

$xpay->Set('LGD_TXNAME', 'CardAuth');                       // 카드 승인
$xpay->Set('LGD_OID', $LGD_OID);                            // 주문번호. 최대 64자
$xpay->Set('LGD_AMOUNT', $LGD_AMOUNT);                      // 결제금액. 숫자만
$xpay->Set('LGD_PAN', $LGD_PAN);                            // 카드번호 (Swipe 는 트랙 데이터)
$xpay->Set('LGD_INSTALL', $LGD_INSTALL);                    // 할부개월. 00 일시불
$xpay->Set('VBV_ECI', $VBV_ECI);                            // 010 Key-in / 020 Swipe
$xpay->Set('LGD_BUYER', $LGD_BUYER);                        // 구매자명. 최대 10자
$xpay->Set('LGD_PRODUCTINFO', $LGD_PRODUCTINFO);            // 상품명. 최대 128자
$xpay->Set('LGD_BUYERIP', (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : ''));  // 결제를 요청한 구매자 IP

if ($VBV_ECI === '010') {                                  // Key-in 에만 해당
    $xpay->Set('LGD_EXPYEAR', $LGD_EXPYEAR);                    // 유효기간 연. YY
    $xpay->Set('LGD_EXPMON', $LGD_EXPMON);                      // 유효기간 월. MM
    // 아래 두 값은 선택. LGD_PRIVATENO 를 보내지 않으면 비밀번호도 확인하지 않는다.
    // $xpay->Set('LGD_PIN', $_POST['LGD_PIN']);                        // 카드 비밀번호 앞 2자리
    // $xpay->Set('LGD_PRIVATENO', $_POST['LGD_PRIVATENO']);            // 생년월일 6자리 또는 사업자번호 10자리
}

/* ---- 선택 파라미터 : 필요한 줄의 주석만 푸세요 (입력 화면에도 같은 이름의 입력란을 추가) ---- */
// $xpay->Set('LGD_BUYERID', $_POST['LGD_BUYERID']);                // 구매자 아이디. 최대 15자
// $xpay->Set('LGD_BUYERPHONE', $_POST['LGD_BUYERPHONE']);          // 구매자 휴대폰번호. 최대 11자
// $xpay->Set('LGD_BUYEREMAIL', $_POST['LGD_BUYEREMAIL']);          // 구매자 이메일. 최대 40자
// $xpay->Set('LGD_TAXFREEAMOUNT', $_POST['LGD_TAXFREEAMOUNT']);    // 면세금액. 부분면세 계약 시
// $xpay->Set('LGD_NOINT', '0');                               // 상점부담 무이자. 1 적용 / 0 일반할부 (별도 계약 필요)
// $xpay->Set('LGD_POINTUSE', 'N');                            // 포인트 사용. Y / N

$txOk     = $xpay->TX();          // lgdacom.conf 의 URL 로 통신
$respCode = $xpay->Response_Code();
$respMsg  = $xpay->Response_Msg();

// 응답 상세. 응답이 없으면 Response_Names() 가 null 을 반환한다.
$fields = array();
$names  = $xpay->Response_Names();
if (is_array($names)) {
    foreach ($names as $name) {
        $fields[$name] = $xpay->Response($name, 0);
    }
}

// 통신 성공 && 응답코드 "0000" 일 때만 성공. 그 외는 모두 실패로 처리한다.
$success = ($txOk && $respCode === '0000');

if ($success) {
    // 결제 성공 DB 처리를 여기에서 수행하세요.
    $isDBOK = true;
    if (!$isDBOK) {
        // 결제는 성공했지만 상점 DB 처리에 실패했다면 자동취소를 요청합니다.
        $tid = isset($fields['LGD_TID']) ? $fields['LGD_TID'] : '';
        $xpay->Rollback('상점 DB 처리 실패 [TID:' . $tid . ', OID:' . $LGD_OID . ']');
    }
} else {
    // 결제 실패 DB 처리를 여기에서 수행하세요.
}

$xpay->close();

/* ==================================================================
 * 응답 파라미터
 * ==================================================================
 * 주요 값은 활성, 나머지는 주석 처리해 두었습니다.
 * 필요한 줄의 // 만 지우면 화면에 함께 출력됩니다.
 */

$show = array(

    'LGD_RESPCODE'           => '응답코드. 0000 이면 성공',
    'LGD_RESPMSG'            => '응답메시지. 최대 160자',
    'LGD_MID'                => '상점아이디. 최대 15자',
    'LGD_OID'                => '주문번호. 최대 64자',
    'LGD_TID'                => '토스페이먼츠 거래번호. 최대 24자',
    'LGD_AMOUNT'             => '결제금액. 최대 12자',
    'LGD_PAYTYPE'            => '결제수단코드. 신용카드 SC0010',
    'LGD_PAYDATE'            => '결제일시. yyyyMMddHHmmss',
    'LGD_FINANCECODE'        => '결제기관코드. 최대 10자',
    'LGD_FINANCENAME'        => '결제기관명. 최대 20자',
    'LGD_FINANCEAUTHNUM'     => '결제기관 승인번호. 최대 20자',
    'LGD_CARDNUM'            => '신용카드번호. 일반 가맹점은 * 처리',
    'LGD_CARDINSTALLMONTH'   => '할부개월. 포인트 결제는 +60, 현대카드 포인트 +80, save 포인트 +40',

    /* ===== 구매자·상품 ===== */
    // 'LGD_BUYER'              => '구매자명',
    // 'LGD_BUYERID'            => '구매자 아이디',
    // 'LGD_BUYERPHONE'         => '구매자 휴대폰번호',
    // 'LGD_BUYEREMAIL'         => '구매자 이메일',
    // 'LGD_BUYERADDRESS'       => '구매자 주소',
    // 'LGD_BUYERSSN'           => '구매자 생년월일(또는 사업자번호)',
    // 'LGD_PRODUCTINFO'        => '상품명',
    // 'LGD_PRODUCTCODE'        => '상품코드',
    // 'LGD_RECEIVER'           => '수취인',
    // 'LGD_RECEIVERPHONE'      => '수취인 전화번호',

    /* ===== 카드 추가정보 ===== */
    // 'LGD_CARDACQUIRER'       => '카드 매입사 코드',
    // 'LGD_CARDGUBUN1'         => '0 개인 / 1 법인 / 9 미확인',
    // 'LGD_CARDGUBUN2'         => '0 신용 / 1 체크 / 2 기프트 / 9 미확인',
    // 'LGD_CARDNOINTEREST_YN'  => '카드사부담 무이자. 1 무이자 / 0 일반',
    // 'LGD_CARDNOINTYN'        => '상점부담 무이자. 1 무이자 / 0 일반',

    /* ===== 즉시할인·부분취소 ===== */
    // 'LGD_DCNO'               => '즉시할인 적용 거래면 DC',
    // 'LGD_DISCOUNTUSEYN'      => '즉시할인 적용. 1 적용 / 0 미적용',
    // 'LGD_DISCOUNTUSEAMOUNT'  => '즉시할인 금액',
    // 'LGD_PCANCELFLAG'        => '부분취소 가능. 1 가능 / 0 불가',
    // 'LGD_PCANCELSTR'         => '부분취소 불가 사유. 가능하면 0',

    /* ===== 기타 ===== */
    // 'LGD_TAXFREEAMOUNT'      => '면세금액',
    // 'LGD_ESCROWYN'           => '에스크로 적용. Y / N',
    // 'LGD_HASHDATA'           => '해쉬데이타',
    // 'LGD_TIMESTAMP'          => '타임스탬프',
);
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>카드 비인증 결제 결과</title>
<style>
  body { font-family: sans-serif; font-size: 14px; max-width: 860px; margin: 20px; }
  table { border-collapse: collapse; }
  th, td { border: 1px solid #ccc; padding: 4px 8px; text-align: left; vertical-align: top; }
</style>
</head>
<body>

<h1>카드 비인증 결제 결과</h1>

<?php if (!$txOk): ?>
  <p>통신 실패 — 요청을 완료하지 못했습니다. (<?php echo $respCode; ?> <?php echo $respMsg; ?>)</p>
<?php elseif ($success): ?>
  <p>결제 성공</p>
<?php else: ?>
  <p>결제 실패 (<?php echo $respCode; ?> <?php echo $respMsg; ?>)</p>
<?php endif; ?>

<table>
  <tr><th>변수명</th><th>설명</th><th>값</th></tr>
<?php foreach ($show as $name => $desc): ?>
  <tr>
    <th><?php echo $name; ?></th>
    <td><?php echo $desc; ?></td>
    <td><?php echo isset($fields[$name]) ? $fields[$name] : ''; ?></td>
  </tr>
<?php endforeach; ?>
</table>

<?php
/* 명세에 없는 값까지 전부 확인하려면 아래 주석을 푸세요.

echo '<h2>수신된 전체 응답</h2><table>';
foreach ($fields as $name => $value) {
    echo '<tr><th>' . $name . '</th><td>' . $value . '</td></tr>';
}
echo '</table>';

*/
?>

<p>이 페이지는 샘플입니다. 실제 연동에서는 결과를 화면에 노출하지 말고 DB에 기록하세요.</p>

</body>
</html>
