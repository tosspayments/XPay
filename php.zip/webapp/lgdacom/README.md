# PHP XPayClient 라이브러리

샘플 페이지는 이 폴더의 `XPayClient.php`를 `require_once`로 불러옵니다.

| 파일 | 설명 |
| --- | --- |
| `XPayClient.php` | API 클래스. 토스페이먼츠 XPayClient 4.0.0.0 (PHP)을 PHP 5.6 ~ 8.x 에서 동작하도록 고친 4.1.0.0 버전. User-Agent 는 `XPayClient (4.1.0.0/PHP)` |
| `JSON.php` | JSON 변환 클래스(Services_JSON). `json_decode()`가 없는 환경에서만 사용 |
| `.htaccess` | Apache 에서 이 폴더로의 직접 접근 차단 |

원본 라이브러리는 PHP 8.0 이상에서 **구문 오류로 불러올 수 없습니다.** 통신 규격, 해시 계산, 응답 처리 방식은 원본과 같고, 아래 부분만 고쳤습니다.

| 구분 | 원본 | 수정 |
| --- | --- | --- |
| PHP 8 구문 오류 | `$text{0}` 형태의 중괄호 문자열 오프셋 (XPayClient 1곳, JSON 40곳) | `$text[0]` |
| PHP 8 생성자 | 클래스 이름과 같은 메서드를 생성자로 사용. PHP 8 에서는 호출되지 않아 설정을 읽지 못함 | `__construct()` 추가. 기존 메서드는 호환용으로 유지 |
| 모든 버전의 치명적 오류 | `set_curl_error()`, `IsAcceptLog()`를 `$this->` 없이 호출 | `$this->` 추가 |
| 응답코드 덮어쓰기 | 오류 보고(`report_error = 1`)가 실패하면 원래 거래의 응답코드가 바뀜 | 보고 전후로 응답코드·메시지·거래ID 보관. `aux_url`이 없으면 보고하지 않음 |
| PHP 8 경고 | 상수 중복 정의, 미정의 배열 키·변수 접근, 동적 속성(8.2) | 정의 여부 확인, 기본값 지정, 속성 선언 |
| PHP 8.4 deprecated | `trigger_error(..., E_USER_ERROR)` | 예외(`Exception`) |
| PHP 7.2 제거 | `mcrypt_ecb()` | openssl (mcrypt 와 같은 결과. openssl 이 없을 때만 mcrypt) |
| PHP 8.5 deprecated | `(double)`, `(integer)` 캐스트, `curl_close()` | `(int)` 캐스트, `curl_close()`는 PHP 8 미만에서만 호출 |
| 로그 폴더 권한 | `mkdir(..., "0777")` (문자열이라 10진수 777 로 처리) | `0750` |
| 인코딩 | 파일 EUC-KR, 로그의 응답 메시지는 항상 EUC-KR | 파일 UTF-8. `output_UTF8 = 1`이면 로그도 UTF-8 |

`ca-bundle.crt`(SSL 인증서)는 설정 폴더(`C:/lgdacom/conf`)에 둡니다. 저장소의 `php/lgdacom/conf/`에 들어 있습니다.
