# 결제창 빌링키 발급

결제창에서 구매자 인증을 받아 빌링키(`LGD_BILLKEY`)를 발급받습니다. 결제는 하지 않습니다.

모바일 샘플은 `mobile/` 폴더에 있습니다. 모바일은 인증창으로 페이지가 이동하며(`LGD_WINDOW_TYPE=submit`, `LGD_PAYWINDOWTYPE=CardBillingAuth_smartphone`), `returnurl.php`가 인증 결과를 `CardBillingAuth_Res.php`로 넘깁니다.

## 흐름

```text
CardBillingAuth.html → CardBillingAuth_Req.php → (빌링 인증창) → returnurl.php → CardBillingAuth_Res.php
```

## 수정할 곳

| 파일 | 내용 |
| --- | --- |
| `CardBillingAuth_Req.php` | "상점 설정"의 `LGD_RETURNURL`을 실제 주소로 바꿉니다. 인증요청 페이지와 같은 프로토콜·호스트여야 합니다. |
| `CardBillingAuth_Res.php` | 발급받은 `LGD_BILLKEY`를 구매자 정보와 함께 암호화해서 저장하는 부분을 구현합니다. |

선택 파라미터는 모두 주석으로 들어 있습니다. 필요한 줄의 주석을 풀고, 입력 화면에도 같은 이름의 입력란을 추가합니다.

> **참고**
> 다른 응답값이 필요하면 `returnurl.php`의 필드 목록, `CardBillingAuth_Req.php`의 `payment_return()`과 결과확인 폼, 결과 페이지의 `show` 배열에 같은 이름을 추가합니다. 모바일은 `LGD_PAYWINDOWTYPE`을 `CardBillingAuth_smartphone`으로 바꿉니다.

## 연동 가이드

결제창 빌링키 발급, 카드 빌링 결제
