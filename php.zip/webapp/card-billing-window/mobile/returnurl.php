<?php
/*
 * [빌링 인증결과 수신 페이지]  토스페이먼츠 XPay (모바일용) — UTF-8
 *
 * 인증창이 인증을 마치면 이 페이지(LGD_RETURNURL)로 이동한다.
 * 인증에 성공하면 받은 값을 CardBillingAuth_Res.php 로 넘긴다.
 * 다른 응답값이 필요하면 아래 목록과 CardBillingAuth_Res.php 의 $show 배열에 같은 이름을 추가한다.
 */

$LGD_RESPCODE    = $_POST['LGD_RESPCODE'];
$LGD_RESPMSG     = $_POST['LGD_RESPMSG'];
$LGD_BILLKEY     = $_POST['LGD_BILLKEY'];
$LGD_PAYTYPE     = $_POST['LGD_PAYTYPE'];
$LGD_PAYDATE     = $_POST['LGD_PAYDATE'];
$LGD_FINANCECODE = $_POST['LGD_FINANCECODE'];
$LGD_FINANCENAME = $_POST['LGD_FINANCENAME'];
$authOk = ($LGD_RESPCODE === '0000');
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>XPay 빌링 인증결과</title>
</head>
<body<?php echo $authOk ? ' onload="document.getElementById(\'LGD_PAYRES\').submit();"' : ''; ?>>

<?php if ($authOk): ?>
  <p>빌링키 발급 결과를 확인하고 있습니다.</p>
  <form method="post" name="LGD_PAYRES" id="LGD_PAYRES" action="CardBillingAuth_Res.php">
    <input type="hidden" name="LGD_RESPCODE" value="<?php echo $LGD_RESPCODE; ?>">
    <input type="hidden" name="LGD_RESPMSG" value="<?php echo $LGD_RESPMSG; ?>">
    <input type="hidden" name="LGD_BILLKEY" value="<?php echo $LGD_BILLKEY; ?>">
    <input type="hidden" name="LGD_PAYTYPE" value="<?php echo $LGD_PAYTYPE; ?>">
    <input type="hidden" name="LGD_PAYDATE" value="<?php echo $LGD_PAYDATE; ?>">
    <input type="hidden" name="LGD_FINANCECODE" value="<?php echo $LGD_FINANCECODE; ?>">
    <input type="hidden" name="LGD_FINANCENAME" value="<?php echo $LGD_FINANCENAME; ?>">
  </form>
<?php else: ?>
  <!-- 인증 실패에 대한 처리를 여기에 추가하세요. -->
  <p>인증 실패 — 결과코드 <?php echo $LGD_RESPCODE; ?>, <?php echo $LGD_RESPMSG; ?></p>
<?php endif; ?>

</body>
</html>
