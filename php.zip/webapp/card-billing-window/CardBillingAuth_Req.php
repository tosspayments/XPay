<?php
/*
 * [빌링 인증요청 페이지]  토스페이먼츠 XPay — UTF-8
 *
 * 결제창에서 구매자 인증을 받아 빌링키를 발급받는다. 결제는 하지 않는다.
 * 선택 파라미터는 주석으로 넣어 두었으니 필요한 줄의 주석만 풀면 된다.
 *
 * 폼이 두 개인 이유
 *   LGD_PAYINFO : 인증창 호출용. openXpay() 가 이 폼의 action / target 을 덮어쓴다.
 *   LGD_PAYRES  : 인증결과 확인(CardBillingAuth_Res.php)용. 인증 성공 후 이 폼만 submit 한다.
 */

/* ---- 상점 설정 ★ 이 줄만 수정하세요 ---------------------------------- */

// 인증결과 수신 페이지(LGD_RETURNURL). 실제 주소로 바꾸세요.
$LGD_RETURNURL  = 'https://상점도메인/xpay/card-billing-window/returnurl.php';



/* ---- 요청 파라미터 --------------------------------------------------- */

$CST_PLATFORM = $_POST['CST_PLATFORM'];   // test 또는 service
$CST_MID      = $_POST['CST_MID'];
$LGD_MID      = ($CST_PLATFORM === 'test' ? 't' : '') . $CST_MID;   // 테스트는 앞에 't'

// 결제창 스크립트 (테스트 / 서비스)
$xpayScript = ($CST_PLATFORM === 'test')
    ? 'https://xpay-sandbox.tosspayments.com/xpay/js/xpay_crossplatform.js'
    : 'https://xpay.tosspayments.com/xpay/js/xpay_crossplatform.js';
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>XPay 빌링 인증요청</title>
<style>
  body { font-family: sans-serif; font-size: 14px; max-width: 640px; margin: 20px; }
</style>
<script src="<?php echo $xpayScript; ?>"></script>
</head>
<body>

<h1>빌링 인증요청</h1>

<form method="post" name="LGD_PAYINFO" id="LGD_PAYINFO">

  <p><button type="button" id="btnAuth">인증요청</button></p>

  <!-- ================================================================
       필수 파라미터
       ================================================================ -->

  <input type="hidden" name="LGD_MID"       value="<?php echo $LGD_MID; ?>">
  <input type="hidden" name="LGD_RETURNURL" value="<?php echo $LGD_RETURNURL; ?>">

  <!-- ================================================================
       이 샘플이 켜 둔 파라미터
       ================================================================ -->

  <!-- 문자 인코딩. 명세 기본값이 EUC-KR 이므로 UTF-8 을 반드시 명시한다. -->
  <input type="hidden" name="LGD_ENCODING"           value="UTF-8">
  <input type="hidden" name="LGD_ENCODING_RETURNURL" value="UTF-8">

  <!-- 빌링 인증창 연동 고정값 (수정 불가) -->
  <input type="hidden" name="LGD_WINDOW_TYPE"   value="iframe">
  <input type="hidden" name="LGD_PAYWINDOWTYPE" value="CardBillingAuth">   <!-- 모바일은 CardBillingAuth_smartphone -->
  <input type="hidden" name="LGD_VERSION"       value="PHP_Non-ActiveX_CardBilling">
  <input type="hidden" name="LGD_DOMAIN_URL"    value="xpayvvip">

  <!-- 인증창이 결과를 채워 넣는 필드 (id 변경 불가) -->
  <input type="hidden" id="LGD_RESPCODE" name="LGD_RESPCODE" value="">
  <input type="hidden" id="LGD_RESPMSG"  name="LGD_RESPMSG"  value="">

  <!-- ================================================================
       선택 파라미터
       필요한 줄의 주석만 풀어 사용하세요. value 는 예시값입니다.
       ================================================================ -->

  <!-- <input type="hidden" name="LGD_BUYERSSN"   value="<?php echo $_POST['LGD_BUYERSSN']; ?>">  구매자 생년월일 6자리 또는 사업자번호 10자리 -->
  <!-- <input type="hidden" name="LGD_CHECKSSNYN" value="Y">  Y 이면 인증창에서 입력한 생년월일과 일치하는지 확인. 기본 N -->
  <!-- <input type="hidden" name="LGD_CUSTOM_SELECTABLE_CARD_TYPES" value="PERSONAL">  노출할 카드 타입. PERSONAL / CORPORATE / FOREIGN -->

</form>

<!-- 인증결과 확인 폼 (CardBillingAuth_Res.php 로 전송). 위 폼의 </form> 뒤에 둔다. -->
<form method="post" name="LGD_PAYRES" id="LGD_PAYRES" action="CardBillingAuth_Res.php">
  <input type="hidden" name="LGD_RESPCODE" value="">
  <input type="hidden" name="LGD_RESPMSG" value="">
  <input type="hidden" name="LGD_BILLKEY" value="">
  <input type="hidden" name="LGD_PAYTYPE" value="">
  <input type="hidden" name="LGD_PAYDATE" value="">
  <input type="hidden" name="LGD_FINANCECODE" value="">
  <input type="hidden" name="LGD_FINANCENAME" value="">
</form>

<script>
  var lgdwin   = null;
  var returned = false;   // payment_return 중복 호출 방지

  /* 결제창 스크립트가 폼을 찾을 때 사용합니다. */
  function getFormObject() {
    return document.getElementById('LGD_PAYINFO');
  }

  /* 빌링 인증창 호출 */
  function launchCrossPlatform() {
    returned = false;
    lgdwin = openXpay(getFormObject(), '<?php echo $CST_PLATFORM; ?>', 'iframe', null, '', '');
  }

  /* returnurl.php 가 iframe 안에서 호출하는 인증결과 처리 함수 */
  function payment_return() {
    if (returned || !lgdwin) { return; }

    var doc = lgdwin.contentWindow ? lgdwin.contentWindow.document : lgdwin.contentDocument;
    if (!doc || !doc.getElementById('LGD_RESPCODE')) { closeIframe(); return; }

    returned = true;

    var respCode = doc.getElementById('LGD_RESPCODE').value;
    if (respCode === '0000') {
      // returnurl.php 가 받은 값을 결과확인 폼에 옮겨 submit 한다.
      var res = document.getElementById('LGD_PAYRES');
      res.elements.LGD_RESPCODE.value = doc.getElementById('LGD_RESPCODE').value;
      res.elements.LGD_RESPMSG.value = doc.getElementById('LGD_RESPMSG').value;
      res.elements.LGD_BILLKEY.value = doc.getElementById('LGD_BILLKEY').value;
      res.elements.LGD_PAYTYPE.value = doc.getElementById('LGD_PAYTYPE').value;
      res.elements.LGD_PAYDATE.value = doc.getElementById('LGD_PAYDATE').value;
      res.elements.LGD_FINANCECODE.value = doc.getElementById('LGD_FINANCECODE').value;
      res.elements.LGD_FINANCENAME.value = doc.getElementById('LGD_FINANCENAME').value;
      res.submit();
      return;
    }

    window.alert('결과코드 ' + respCode + '\n' + doc.getElementById('LGD_RESPMSG').value);
    closeIframe();
  }

  document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('btnAuth').addEventListener('click', launchCrossPlatform);
  });
</script>

</body>
</html>
