<?php
/*
 * [계좌 유효성 확인 요청 페이지]  토스페이먼츠 XPay — UTF-8
 *
 * 계좌번호와 예금주명이 일치하는지 AccCert 거래로 확인한다.
 */

/* ---- 상점 설정 ★ 이 줄만 수정하세요 ---------------------------------- */

// 토스페이먼츠에서 제공한 환경파일(conf/lgdacom.conf, conf/mall.conf) 디렉터리
$configPath = 'C:/lgdacom';


/* ---- 요청 파라미터 --------------------------------------------------- */

$CST_PLATFORM = $_POST['CST_PLATFORM'];   // test 또는 service
$LGD_MID      = ($CST_PLATFORM === 'test' ? 't' : '') . $_POST['CST_MID'];   // 테스트는 앞에 't'
$LGD_GUBUN          = $_POST['LGD_GUBUN'];
$LGD_BANKCODE       = $_POST['LGD_BANKCODE'];
$LGD_ACCOUNTNO      = $_POST['LGD_ACCOUNTNO'];
$LGD_NAME           = $_POST['LGD_NAME'];
$LGD_PRIVATENO      = $_POST['LGD_PRIVATENO'];

/* ---- 요청 ----------------------------------------------------------- */

require_once __DIR__ . '/../lgdacom/XPayClient.php';

// CST_PLATFORM 값에 따라 lgdacom.conf 의 test_url / url 이 선택된다.
$xpay = new XPayClient($configPath, $CST_PLATFORM);
if (!$xpay->Init_TX($LGD_MID)) {
    header('Content-Type: text/plain; charset=UTF-8');
    exit('상점아이디 설정을 확인하세요: ' . $xpay->Response_Msg());
}

$xpay->Set('LGD_TXNAME', 'AccCert');                        // 계좌 유효성 확인
$xpay->Set('LGD_GUBUN', $LGD_GUBUN);                        // 확인 구분. 2 ~ 6
$xpay->Set('LGD_BANKCODE', $LGD_BANKCODE);                  // 은행코드
$xpay->Set('LGD_ACCOUNTNO', $LGD_ACCOUNTNO);                // 계좌번호
$xpay->Set('LGD_NAME', $LGD_NAME);                          // 예금주명. 구분 2, 3 필수
$xpay->Set('LGD_PRIVATENO', $LGD_PRIVATENO);                // 생년월일 또는 사업자번호. 구분 3, 5 필수
$xpay->Set('LGD_BUYERIP', $_SERVER['REMOTE_ADDR']);         // 요청한 구매자 IP

/* ---- 선택 파라미터 : 필요한 줄의 주석만 푸세요 (입력 화면에도 같은 이름의 입력란을 추가) ---- */
// $xpay->Set('LGD_CHECKNHYN', $_POST['LGD_CHECKNHYN']);       // Y: 은행코드 011, 012 일 때 농협 중앙회·단위조합 여부 확인

$txOk     = $xpay->TX();          // lgdacom.conf 의 URL 로 통신
$respCode = $xpay->Response_Code();
$respMsg  = $xpay->Response_Msg();

// 응답 상세. 응답이 없으면 Response_Names() 가 null 을 반환한다.
$fields = array();
$names  = $xpay->Response_Names();
if (is_array($names)) {
    foreach ($names as $name) {
        $fields[$name] = $xpay->Response($name, 0);
    }
}

// 통신 성공 && 응답코드 "0000" 일 때만 성공. 그 외는 모두 실패로 처리한다.
$success = ($txOk && $respCode === '0000');

if ($success) {
    // 성공 결과를 DB 에 반영하세요.
} else {
    // 실패 결과를 DB 에 기록하세요.
}

$xpay->close();

/* ==================================================================
 * 응답 파라미터
 * ==================================================================
 * 주요 값은 활성, 나머지는 주석 처리해 두었습니다.
 * 필요한 줄의 // 만 지우면 화면에 함께 출력됩니다.
 */

$show = array(

    'LGD_RESPCODE'    => '응답코드. 0000 이면 성공',
    'LGD_RESPMSG'     => '응답메시지',
    'LGD_TID'         => '토스페이먼츠 거래번호',
    'LGD_FINANCECODE' => '은행코드',
    'LGD_FINANCENAME' => '은행명',
    'LGD_NAME'        => '예금주명. 구분 2, 3, 6 일 때',

    /* ===== 기타 ===== */
    // 'LGD_MID'      => '상점아이디',

);
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>계좌 유효성 확인 결과</title>
<style>
  body { font-family: sans-serif; font-size: 14px; max-width: 860px; margin: 20px; }
  table { border-collapse: collapse; }
  th, td { border: 1px solid #ccc; padding: 4px 8px; text-align: left; vertical-align: top; }
</style>
</head>
<body>

<h1>계좌 유효성 확인 결과</h1>

<?php if (!$txOk): ?>
  <p>통신 실패 — 요청을 완료하지 못했습니다. (<?php echo $respCode; ?> <?php echo $respMsg; ?>)</p>
<?php elseif ($success): ?>
  <p>확인 성공</p>
<?php else: ?>
  <p>확인 실패 (<?php echo $respCode; ?> <?php echo $respMsg; ?>)</p>
<?php endif; ?>

<table>
  <tr><th>변수명</th><th>설명</th><th>값</th></tr>
<?php foreach ($show as $name => $desc): ?>
  <tr>
    <th><?php echo $name; ?></th>
    <td><?php echo $desc; ?></td>
    <td><?php echo isset($fields[$name]) ? $fields[$name] : ''; ?></td>
  </tr>
<?php endforeach; ?>
</table>

<?php
/* 명세에 없는 값까지 전부 확인하려면 아래 주석을 푸세요.

echo '<h2>수신된 전체 응답</h2><table>';
foreach ($fields as $name => $value) {
    echo '<tr><th>' . $name . '</th><td>' . $value . '</td></tr>';
}
echo '</table>';

*/
?>

<p>이 페이지는 샘플입니다. 실제 연동에서는 결과를 화면에 노출하지 말고 DB에 기록하세요.</p>

</body>
</html>
