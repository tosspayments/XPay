<?php
/*
 * [결제 인증요청 페이지 (STEP 2-1)]  토스페이먼츠 XPay 분할정산 (PC용) — UTF-8
 *
 * 일반 결제창 결제에 LGD_DIVIDE_INFO(하위 상점별 정산 정보)를 추가하고,
 * LGD_PRODUCTINFO 를 padj 로 고정한다. 결제 해시는 일반 결제와 같다.
 *
 * 결제요청 파라미터는 아래 form 안의 hidden 필드로 직접 기술한다.
 * 선택 파라미터는 전부 주석으로 넣어 두었으니 필요한 줄의 주석만 풀면 된다.
 *
 * 폼이 두 개인 이유
 *   LGD_PAYINFO : 결제창 호출(인증요청)용. openXpay() 가 이 폼의 action / target 을
 *                 결제창 주소로 덮어쓰므로 최종 결제요청에 재사용하면 안 된다.
 *   LGD_PAYRES  : 최종 결제요청(payres.php)용. 인증 성공 후 이 폼만 submit 한다.
 */

/* ---- 상점 설정 ★ 이 줄만 수정하세요 ---------------------------------- */

// 토스페이먼츠에서 제공한 환경파일(conf/lgdacom.conf, conf/mall.conf) 디렉터리
$configPath = 'C:/lgdacom';                  // Windows 예: C:/lgdacom

// 인증결과 수신 페이지(LGD_RETURNURL). 실제 주소로 바꾸세요.
$LGD_RETURNURL  = 'https://상점도메인/xpay/split-settlement/returnurl.php';
// 가상계좌 결과수신 페이지(LGD_CASNOTEURL). 실제 주소로 바꾸세요. 표준포트(80, 443)만 사용할 수 있습니다.
$LGD_CASNOTEURL = 'https://상점도메인/xpay/virtual-account/cas_noteurl.php';




/* ---- 요청 파라미터 --------------------------------------------------- */

$CST_PLATFORM = $_POST['CST_PLATFORM'];   // test 또는 service
$CST_MID      = $_POST['CST_MID'];
$LGD_MID      = ($CST_PLATFORM === 'test' ? 't' : '') . $CST_MID;   // 테스트는 앞에 't'

$LGD_OID         = $_POST['LGD_OID'];
$LGD_AMOUNT      = $_POST['LGD_AMOUNT'];
$LGD_BUYER       = $_POST['LGD_BUYER'];
// 분할정산 상점은 반드시 padj 로 설정한다. (수정 불가)
// 실제 상품명은 하위 상점별 productinfo 에 넣는다.
$LGD_PRODUCTINFO = 'padj';

/* ---- 분할정산 정보 (LGD_DIVIDE_INFO) ------------------------------- */
// {"divideinfo":[{"sub_merchantid":"...","amount":"...","productinfo":"..."}, ...]}
// 과세·부가세·면세 금액이 필요하면 netamount, vat, taxfreeamount 를 같은 방식으로 추가합니다.
$LGD_DIVIDE_INFO = '{"divideinfo":['
    . '{"sub_merchantid":"' . $_POST['SUB_MID_1'] . '","amount":"' . $_POST['SUB_AMOUNT_1'] . '","productinfo":"' . $_POST['SUB_PRODUCT_1'] . '"},'
    . '{"sub_merchantid":"' . $_POST['SUB_MID_2'] . '","amount":"' . $_POST['SUB_AMOUNT_2'] . '","productinfo":"' . $_POST['SUB_PRODUCT_2'] . '"}'
    . ']}';

/* ---- 해시 생성 (거래 위변조 방지) ----------------------------------- */

require_once __DIR__ . '/../lgdacom/XPayClient.php';

$xpay = new XPayClient($configPath, $CST_PLATFORM);

if (!$xpay->Init_TX($LGD_MID)) {
    header('Content-Type: text/plain; charset=UTF-8');
    exit('상점아이디 설정을 확인하세요: ' . $xpay->Response_Msg());
}

$LGD_TIMESTAMP = $xpay->GetTimeStamp();
$LGD_HASHDATA  = $xpay->GetHashData($LGD_MID, $LGD_OID, $LGD_AMOUNT, $LGD_TIMESTAMP);
$xpay->close();

// 결제창 스크립트 (테스트 / 서비스)
$xpayScript = ($CST_PLATFORM === 'test')
    ? 'https://xpay-sandbox.tosspayments.com/xpay/js/xpay_crossplatform.js'
    : 'https://xpay.tosspayments.com/xpay/js/xpay_crossplatform.js';
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>XPay 결제 인증요청</title>
<style>
  body { font-family: sans-serif; font-size: 14px; max-width: 640px; margin: 20px; }
</style>
<script src="<?php echo $xpayScript; ?>"></script>
</head>
<body>

<h1>결제 인증요청</h1>

<!-- ==================================================================
     인증요청 폼 (결제창 호출용)
     openXpay() 가 이 폼의 action / target 을 덮어쓴다.
     ================================================================== -->
<form method="post" name="LGD_PAYINFO" id="LGD_PAYINFO">

  <dl>
    <dt>구매자명</dt><dd><?php echo $LGD_BUYER; ?></dd>
    <dt>분할정산</dt><dd><?php echo $LGD_DIVIDE_INFO; ?></dd>
    <dt>결제금액</dt><dd><?php echo $LGD_AMOUNT; ?>원</dd>
    <dt>주문번호</dt><dd><?php echo $LGD_OID; ?></dd>
  </dl>

  <p><button type="button" id="btnAuth">인증요청</button></p>


  <!-- ================================================================
       필수 파라미터
       ================================================================ -->

  <input type="hidden" name="LGD_MID"         value="<?php echo $LGD_MID; ?>">
  <input type="hidden" name="LGD_OID"         value="<?php echo $LGD_OID; ?>">
  <input type="hidden" name="LGD_AMOUNT"      value="<?php echo $LGD_AMOUNT; ?>">
  <input type="hidden" name="LGD_BUYER"       value="<?php echo $LGD_BUYER; ?>">
  <input type="hidden" name="LGD_PRODUCTINFO" value="<?php echo $LGD_PRODUCTINFO; ?>">
  <input type="hidden" name="LGD_TIMESTAMP"   value="<?php echo $LGD_TIMESTAMP; ?>">
  <input type="hidden" name="LGD_HASHDATA"    value="<?php echo $LGD_HASHDATA; ?>">

  <!-- 분할정산 정보. JSON 의 큰따옴표가 들어가므로 value 를 작은따옴표로 감싼다. (원본 샘플과 같은 방식) -->
  <input type="hidden" name="LGD_DIVIDE_INFO" value='<?php echo $LGD_DIVIDE_INFO; ?>'>


  <!-- ================================================================
       이 샘플이 켜 둔 파라미터
       ================================================================ -->

  <!-- 인증결과 수신 페이지 -->
  <input type="hidden" name="LGD_RETURNURL" value="<?php echo $LGD_RETURNURL; ?>">

  <!-- 문자 인코딩. 명세 기본값이 EUC-KR 이므로 UTF-8 을 반드시 명시한다. -->
  <input type="hidden" name="LGD_ENCODING"           value="UTF-8">
  <input type="hidden" name="LGD_ENCODING_RETURNURL" value="UTF-8">

  <!-- 가상계좌 할당·입금·취소 결과수신. 가상계좌 사용 시 필수. 표준포트(80, 443)만 -->
  <input type="hidden" name="LGD_CASNOTEURL"       value="<?php echo $LGD_CASNOTEURL; ?>">
  <input type="hidden" name="LGD_ENCODING_NOTEURL" value="UTF-8">

  <!-- N: NonActiveX. 이 값을 보내지 않으면 ActiveX 환경(IE)으로 동작한다. -->
  <input type="hidden" name="LGD_ACTIVEXYN" value="N">

  <!-- P: PC용 결제모듈. 모바일에서 PC용 모듈 실행을 방지한다. -->
  <input type="hidden" name="LGD_OSTYPE_CHECK" value="P">

  <!-- 결제창 연동 고정값 (수정 불가) -->
  <input type="hidden" name="LGD_WINDOW_TYPE"          value="iframe">
  <input type="hidden" name="LGD_WINDOW_VER"           value="2.5">
  <input type="hidden" name="LGD_CUSTOM_PROCESSTYPE"   value="TWOTR">
  <input type="hidden" name="LGD_CUSTOM_SWITCHINGTYPE" value="IFRAME">
  <input type="hidden" name="LGD_VERSION"              value="PHP_Non-ActiveX_Standard">
  <input type="hidden" name="LGD_DOMAIN_URL"           value="xpayvvip">

  <!-- 결제창이 인증결과를 채워 넣는 필드 (id 변경 불가) -->
  <input type="hidden" id="LGD_RESPCODE" name="LGD_RESPCODE" value="">
  <input type="hidden" id="LGD_RESPMSG"  name="LGD_RESPMSG"  value="">
  <input type="hidden" id="LGD_PAYKEY"   name="LGD_PAYKEY"   value="">


  <!-- 분할정산은 신용카드(간편결제 포함)·계좌이체·가상계좌에만 적용된다. -->
  <!-- <input type="hidden" name="LGD_CUSTOM_USABLEPAY" value="SC0010-SC0030-SC0040"> -->

  <!-- ================================================================
       선택 파라미터
       필요한 줄의 주석만 풀어 사용하세요. value 는 예시값입니다.
       ================================================================ -->

  <!-- ===== 공통 : 구매자 정보 ===== -->
  <!-- <input type="hidden" name="LGD_CURRENCY"      value="410">  통화코드. 기본 410, 원화만 가능 -->
  <!-- <input type="hidden" name="LGD_BUYERID"       value="">     구매자아이디. 최대 15자. 문화상품권 결제 시 필수 -->
  <!-- <input type="hidden" name="LGD_BUYERIP"       value="">     구매자아이피. 최대 15자. 문화상품권 결제 시 필수 -->
  <!-- <input type="hidden" name="LGD_BUYERPHONE"    value="">     구매자휴대폰번호. 최대 15자 -->
  <!-- <input type="hidden" name="LGD_BUYEREMAIL"    value="">     구매자메일. 최대 40자 -->
  <!-- <input type="hidden" name="LGD_BUYERADDRESS"  value="">     구매자주소. 최대 128자 -->

  <!-- ===== 공통 : 상품·배송 정보 ===== -->
  <!-- <input type="hidden" name="LGD_PRODUCTCODE"   value="">     상품코드. 최대 40자 -->
  <!-- <input type="hidden" name="LGD_RECEIVER"      value="">     수취인. 최대 10자 -->
  <!-- <input type="hidden" name="LGD_RECEIVERPHONE" value="">     수취인전화번호. 최대 15자 -->
  <!-- <input type="hidden" name="LGD_DELIVERYINFO"  value="">     배송정보. 최대 128자 -->

  <!-- ===== 공통 : 금액·기한 ===== -->
  <!-- <input type="hidden" name="LGD_TAXFREEAMOUNT" value="0">    면세금액. 기본 0. 숫자 최대 12자 -->
  <!-- <input type="hidden" name="LGD_CLOSEDATE" value="20261231235959">  결제가능일시(가상계좌 입금마감). yyyyMMddHHmmss 14자 -->

  <!-- ===== 공통 : 결제수단 지정 =====
       SC0010 신용카드 / SC0030 계좌이체 / SC0040 무통장입금(가상계좌)
       SC0060 휴대폰 / SC0070 유선전화결제 / SC0090 OK캐쉬백
       SC0111 문화상품권 / SC0112 게임문화상품권                        -->
  <!-- <input type="hidden" name="LGD_CUSTOM_FIRSTPAY"  value="SC0010">  처음 선택될 결제수단. 기본 SC0010 -->
  <!-- <input type="hidden" name="LGD_CUSTOM_USABLEPAY" value="SC0010-SC0030">  노출할 결제수단만 지정 -->

  <!-- ===== 공통 : 결제창 화면 ===== -->
  <!-- <input type="hidden" name="LGD_CUSTOM_SKIN"      value="red">  결제창 스킨. red, purple, yellow -->
  <!-- <input type="hidden" name="LGD_CUSTOM_LOGO"      value="">     로고 이미지 URL. 권장 크기 폭 200 높이 38 pixel -->
  <!-- <input type="hidden" name="LGD_CUSTOM_FOOTERMSG" value="">     결제창 하단 메시지. 최대 60자 -->
  <!-- <input type="hidden" name="LGD_CUSTOM_SMSMSG"    value="">     사용자정의 SMS 발송 메시지. 최대 40자 -->
  <!-- <input type="hidden" name="LGD_BACKBTN_YN"       value="Y">    결제수단 다시 선택 버튼. Y 사용 / N 미사용 -->
  <!-- <input type="hidden" name="LGD_DISABLE_AGREE"    value="N">    Y 약관 미표시 / N 약관 표시 -->
  <!-- <input type="hidden" name="LGD_DISPLAY_BUYERPHONE" value="Y">  휴대폰번호 입력란 표시. 기본 Y -->
  <!-- <input type="hidden" name="LGD_DISPLAY_BUYEREMAIL" value="Y">  이메일 입력란 표시. 기본 Y -->
  <!-- <input type="hidden" name="LGD_DISPLAY_ACCOUNTPID" value="Y">  가상계좌 생년월일 입력란 표시. 기본 Y -->

  <!-- ===== 공통 : 세션·타임아웃 ===== -->
  <!-- <input type="hidden" name="LGD_CUSTOM_SESSIONTIMEOUT" value="1200">  결제창 세션유지시간(초). 기본 1200 -->
  <!-- <input type="hidden" name="LGD_CUSTOM_NOTEURLTIMEOUT" value="30">    LGD_NOTEURL 응답대기시간(초). 기본 30 -->

  <!-- ===== 공통 : 서버 결과수신 ===== -->
  <!-- <input type="hidden" name="LGD_NOTEURL" value="https://상점도메인/noteurl.php">  해외카드 DB연동 페이지. 최대 255자. 표준포트만 -->
  <!-- <input type="hidden" name="LGD_CUSTOM_RESULTTYPE" value="SUBMIT">  Form submit 방식으로 결제창을 호출할 때만 사용 -->

  <!-- ===== 셀프커스텀(카드사 직접호출) : 표준 iframe 흐름과 함께 쓰지 마세요 =====
       아래 조합은 결제창 UI 를 건너뛰고 카드사 인증으로 바로 넘어가므로
       iframe 흐름(LGD_WINDOW_TYPE=iframe)에서는 반환 경로가 달라질 수 있습니다.
       사용 시에는 LGD_CUSTOM_USABLEPAY 를 SC0010(신용카드)으로 맞추세요.        -->
  <!-- <input type="hidden" name="LGD_SELF_CUSTOM"      value="Y">      셀프커스텀 사용 -->
  <!-- <input type="hidden" name="LGD_CARDTYPE"         value="61">     카드사 코드 -->
  <!-- <input type="hidden" name="LGD_INSTALL"          value="06">     할부개월 -->
  <!-- <input type="hidden" name="LGD_NOINT"            value="0">      0 일반할부 / 1 무이자할부 -->
  <!-- <input type="hidden" name="LGD_CUSTOM_USABLEPAY" value="SC0010"> 신용카드만 노출 -->

  <!-- ===== 에스크로 : 하나라도 사용하면 아래 전부 값이 있어야 함 ===== -->
  <!-- <input type="hidden" name="LGD_ESCROW_USEYN"      value="Y">  에스크로 사용유무 -->
  <!-- <input type="hidden" name="LGD_ESCROW_GOODID"     value="">   상품번호. 최대 40자 -->
  <!-- <input type="hidden" name="LGD_ESCROW_GOODNAME"   value="">   상품명. 최대 128자 -->
  <!-- <input type="hidden" name="LGD_ESCROW_GOODCODE"   value="">   상품코드. 최대 40자 -->
  <!-- <input type="hidden" name="LGD_ESCROW_UNITPRICE"  value="">   상품단가 -->
  <!-- <input type="hidden" name="LGD_ESCROW_QUANTITY"   value="">   상품수량 -->
  <!-- <input type="hidden" name="LGD_ESCROW_ZIPCODE"    value="">   배송지 우편번호. 최대 10자 -->
  <!-- <input type="hidden" name="LGD_ESCROW_ADDRESS1"   value="">   배송지 주소, 동까지. 최대 60자 -->
  <!-- <input type="hidden" name="LGD_ESCROW_ADDRESS2"   value="">   배송지 상세주소. 최대 60자 -->
  <!-- <input type="hidden" name="LGD_ESCROW_BUYERPHONE" value="">   구매자휴대폰번호. 최대 15자 -->

  <!-- ===== 신용카드 ===== -->
  <!-- <input type="hidden" name="LGD_INSTALLRANGE" value="0:2:3:4:5:6:7:8:9:10:11:12">  표시할 할부개월. 반드시 이 포맷 -->
  <!-- <input type="hidden" name="LGD_NOINTINF"     value="11-2:3,31-2:3">  무이자 할부정보. 카드사코드에 할부개월 -->
  <!-- <input type="hidden" name="LGD_MERT_NOINT"   value="N">  Y 상점부담 무이자만 표시 / N 카드사행사 무이자도 표시. 기본 N -->
  <!-- <input type="hidden" name="LGD_USABLECARD"   value="11-31-41">  노출할 카드사만 지정 -->
  <!-- <input type="hidden" name="LGD_DISABLECARD"  value="4V-4M-4J">  제외할 카드사 지정 -->
  <!-- <input type="hidden" name="LGD_AFFILIATECARDINFO" value="11-009010,31-032300">  제휴카드 정보. 카드사코드에 제휴코드 -->
  <!-- <input type="hidden" name="LGD_AFFILIATECARDONLY" value="Y">  Y 위 제휴카드만 결제 가능 -->
  <!-- <input type="hidden" name="LGD_CUSTOM_CARDPOINTUSEYN" value="N">  Y 포인트를 무조건 사용. 기본 N -->
  <!-- <input type="hidden" name="LGD_LANGUAGE" value="EN">  EN 해외카드 영문 결제창. 기본 국문. FIRSTPAY 와 함께 사용 -->

  <!-- ===== 계좌이체 ===== -->
  <!-- <input type="hidden" name="LGD_USABLEBANK"  value="03-06-11">  노출할 은행만 지정 -->
  <!-- <input type="hidden" name="LGD_DISABLEBANK" value="03-06-11">  제외할 은행 지정 -->

  <!-- ===== 휴대폰 : 이통사 코드 SKT 1, KT 2, LGU 3, KCT 4, CJ헬로비젼 5 ===== -->
  <!-- <input type="hidden" name="LGD_USABLETELCORP"  value="1-2">  노출할 이통사만 지정 -->
  <!-- <input type="hidden" name="LGD_DISABLETELCORP" value="1-2">  제외할 이통사 지정 -->
  <!-- <input type="hidden" name="LGD_PROVIDE_TERM"   value="1">    1 일반결제 / 2 월 자동결제. 기본 1 -->
  <!-- <input type="hidden" name="LGD_FIXED_BUYERPHONE" value="">   결제전화번호 자동채움 및 변경 방지. 최대 11자 -->

  <!-- ===== 가상계좌 ===== -->
  <!-- <input type="hidden" name="LGD_CASASSIGNNOTIYN"  value="Y">  N 할당결과를 CASNOTEURL 로 받지 않음. 기본 Y -->
  <!-- <input type="hidden" name="LGD_CUSTOM_CASSMSMSG" value="">   가상계좌 SMS 발송 메시지. 최대 40자 -->

  <!-- ===== 계좌이체·가상계좌 : 현금영수증 ===== -->
  <!-- <input type="hidden" name="LGD_CASHRECEIPTYN" value="Y">  발급 사용 여부. 기본 Y -->
  <!-- <input type="hidden" name="LGD_DEFAULTCASHRECEIPTUSE" value="1">  발급용도 기본 선택. 0 미발행 / 1 소득공제 / 2 지출증빙 -->
  <!-- <input type="hidden" name="LGD_CUSTOM_MERTNAME"    value="">  상점명. 최대 40자 -->
  <!-- <input type="hidden" name="LGD_CUSTOM_MERTPHONE"   value="">  상점 전화번호. 최대 20자 -->
  <!-- <input type="hidden" name="LGD_CUSTOM_BUSINESSNUM" value="">  사업자번호. 최대 10자 -->
  <!-- <input type="hidden" name="LGD_CUSTOM_CEONAME"     value="">  대표자명. 최대 16자 -->

  <!-- ===== 계좌이체·가상계좌 : 입력값 자동채움 ===== -->
  <!-- <input type="hidden" name="LGD_AUTOFILLYN_BUYER"    value="N">  Y 구매자명 자동채움. 기본 N -->
  <!-- <input type="hidden" name="LGD_AUTOFILLYN_BUYERSSN" value="N">  Y 생년월일 자동채움. 기본 N -->
  <!-- <input type="hidden" name="LGD_READONLYYN_BUYERSSN" value="N">  Y 생년월일 읽기전용. 기본 N -->

  <!-- ===== OK캐쉬백 : 사용 시 필수 ===== -->
  <!-- <input type="hidden" name="LGD_OCBITEMCODE" value="">  다날에서 제공한 대표아이템코드 -->

  <!-- ===== 간편결제 직접호출 : 사용 시 필수 =====
       PAYCO 페이코 / SSGPAY SSG 페이 / LGPAY LG 페이
       SAMSUNGPAY 삼성페이 / LPAY L 페이 / KAKAOPAY 카카오페이 / SMILEPAY 스마일클럽 -->
  <!-- <input type="hidden" name="LGD_EASYPAY_ONLY" value="PAYCO">  선택한 간편결제 화면을 직접 호출 -->

</form>

<!-- ==================================================================
     최종 결제요청 폼 (payres.php 로 전송)
     ★ 반드시 위 폼의 </form> 뒤에 두어야 한다. 폼은 중첩할 수 없으므로
       LGD_PAYINFO 안에 넣으면 파서가 이 태그를 버려서 폼이 생성되지 않는다.
     ★ LGD_PAYKEY 에 id 를 붙이지 않는다. id="LGD_PAYKEY" 는 결제창 스크립트가
       사용하는 고정 id 라서 문서 안에 중복되면 안 된다.
     ================================================================== -->
<form method="post" name="LGD_PAYRES" id="LGD_PAYRES" action="payres.php">
  <input type="hidden" name="CST_PLATFORM" value="<?php echo $CST_PLATFORM; ?>">
  <input type="hidden" name="CST_MID"      value="<?php echo $CST_MID; ?>">
  <input type="hidden" name="LGD_OID"      value="<?php echo $LGD_OID; ?>">
  <input type="hidden" name="LGD_PAYKEY"   value="">
</form>

<script>
  var lgdwin   = null;
  var returned = false;   // payment_return 중복 호출 방지

  /* 결제창 스크립트가 폼을 찾을 때 사용합니다. */
  function getFormObject() {
    return document.getElementById('LGD_PAYINFO');
  }

  /* 결제창 호출 */
  function launchCrossPlatform() {
    returned = false;
    lgdwin = openXpay(getFormObject(), '<?php echo $CST_PLATFORM; ?>', 'iframe', null, '', '');
  }

  /* returnurl.php 가 iframe 안에서 호출하는 인증결과 처리 함수 */
  function payment_return() {
    if (returned) { return; }        // 중복 호출 무시
    if (!lgdwin)  { return; }        // 결제창이 이미 정리된 경우

    var doc = lgdwin.contentWindow ? lgdwin.contentWindow.document : lgdwin.contentDocument;
    if (!doc || !doc.getElementById('LGD_RESPCODE')) { closeIframe(); return; }

    returned = true;

    var respCode = doc.getElementById('LGD_RESPCODE').value;

    if (respCode === '0000') {
      // 인증요청 폼이 아니라 최종 결제요청 폼을 submit 한다.
      var res = document.getElementById('LGD_PAYRES');
      res.elements.LGD_PAYKEY.value = doc.getElementById('LGD_PAYKEY').value;
      res.submit();
      return;
    }

    window.alert('결과코드 ' + respCode + '\n' + doc.getElementById('LGD_RESPMSG').value);
    closeIframe();
  }

  document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('btnAuth').addEventListener('click', launchCrossPlatform);
  });
</script>

</body>
</html>
