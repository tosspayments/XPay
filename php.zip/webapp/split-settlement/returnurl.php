<?php
/*
 * [인증결과 수신 페이지]  토스페이먼츠 XPay 분할정산 (PC용) — UTF-8
 *
 * 결제창이 인증결과를 이 페이지(LGD_RETURNURL)로 보낸다.
 * 이 페이지는 결제창 iframe 안에서 열리므로, 받은 값을 hidden 필드에 담고
 * 부모 페이지(payreq_crossplatform.php)의 payment_return() 을 호출한다.
 * 필드의 id 는 부모 페이지가 읽으므로 바꾸지 않는다.
 */


$LGD_RESPCODE = $_POST['LGD_RESPCODE'];
$LGD_RESPMSG  = $_POST['LGD_RESPMSG'];
$LGD_PAYKEY   = $_POST['LGD_PAYKEY'];
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>XPay 인증결과</title>
</head>
<body onload="parent.payment_return();">

<p>인증결과를 처리하고 있습니다.</p>

<form method="post" name="LGD_RETURNINFO" id="LGD_RETURNINFO">
  <input type="hidden" id="LGD_RESPCODE" name="LGD_RESPCODE" value="<?php echo $LGD_RESPCODE; ?>">
  <input type="hidden" id="LGD_RESPMSG"  name="LGD_RESPMSG"  value="<?php echo $LGD_RESPMSG; ?>">
  <input type="hidden" id="LGD_PAYKEY"   name="LGD_PAYKEY"   value="<?php echo $LGD_PAYKEY; ?>">
</form>

</body>
</html>
