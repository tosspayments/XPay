<?php
/*
 * [결제취소 요청 페이지]  토스페이먼츠 XPay — UTF-8
 *
 * 승인된 거래를 LGD_TID 로 전체 취소한다.
 * 부분취소와 가상계좌 환불에 필요한 파라미터는 주석으로 넣어 두었다.
 */

/* ---- 상점 설정 ★ 이 줄만 수정하세요 ---------------------------------- */

// 토스페이먼츠에서 제공한 환경파일(conf/lgdacom.conf, conf/mall.conf) 디렉터리
$configPath = 'C:/lgdacom';


/* ---- 요청 파라미터 --------------------------------------------------- */

$CST_PLATFORM = $_POST['CST_PLATFORM'];   // test 또는 service
$LGD_MID      = ($CST_PLATFORM === 'test' ? 't' : '') . $_POST['CST_MID'];   // 테스트는 앞에 't'
$LGD_TID            = $_POST['LGD_TID'];

/* ---- 요청 ----------------------------------------------------------- */

require_once __DIR__ . '/../lgdacom/XPayClient.php';

// CST_PLATFORM 값에 따라 lgdacom.conf 의 test_url / url 이 선택된다.
$xpay = new XPayClient($configPath, $CST_PLATFORM);
if (!$xpay->Init_TX($LGD_MID)) {
    header('Content-Type: text/plain; charset=UTF-8');
    exit('상점아이디 설정을 확인하세요: ' . $xpay->Response_Msg());
}

$xpay->Set('LGD_TXNAME', 'Cancel');                         // 전체취소
$xpay->Set('LGD_TID', $LGD_TID);                            // 토스페이먼츠 거래번호. 최대 24자

/* ---- 선택 파라미터 : 필요한 줄의 주석만 푸세요 (입력 화면에도 같은 이름의 입력란을 추가) ---- */
// $xpay->Set('LGD_CANCELREASON', $_POST['LGD_CANCELREASON']);      // 취소 사유

/* ===== 가상계좌 취소(환불) : 환불계좌 정보 필수 ===== */
// $xpay->Set('LGD_RFBANKCODE', $_POST['LGD_RFBANKCODE']);          // 환불계좌 은행코드. 최대 3자
// $xpay->Set('LGD_RFACCOUNTNUM', $_POST['LGD_RFACCOUNTNUM']);      // 환불계좌 번호. 최대 15자
// $xpay->Set('LGD_RFCUSTOMERNAME', $_POST['LGD_RFCUSTOMERNAME']);  // 환불계좌 예금주. 최대 32자
// $xpay->Set('LGD_RFPHONE', $_POST['LGD_RFPHONE']);                // 환불요청자 연락처. 최대 15자

/* ===== 부분취소 : 위의 'Cancel' 대신 아래를 사용 ===== */
// $xpay->Set('LGD_TXNAME', 'PartialCancel');                  // 부분취소
// $xpay->Set('LGD_CANCELAMOUNT', $_POST['LGD_CANCELAMOUNT']);      // 부분취소 금액. 콤마 없이 숫자만
// $xpay->Set('LGD_REMAINAMOUNT', '');                         // 취소 전 남은 금액. 카드만
// $xpay->Set('LGD_PCANCELCNT', '001');                        // 부분환불 요청횟수. 반드시 3자리 (001, 002 …)
// $xpay->Set('LGD_REQREMAIN', '1');                           // 1 취소 후 남은 금액 리턴. 카드·휴대폰만

$txOk     = $xpay->TX();          // lgdacom.conf 의 URL 로 통신
$respCode = $xpay->Response_Code();
$respMsg  = $xpay->Response_Msg();

// 응답 상세. 응답이 없으면 Response_Names() 가 null 을 반환한다.
$fields = array();
$names  = $xpay->Response_Names();
if (is_array($names)) {
    foreach ($names as $name) {
        $fields[$name] = $xpay->Response($name, 0);
    }
}

// 통신 성공 && 응답코드 "0000" 일 때만 성공. 그 외는 모두 실패로 처리한다.
$success = ($txOk && $respCode === '0000');

if ($success) {
    // 성공 결과를 DB 에 반영하세요.
} else {
    // 실패 결과를 DB 에 기록하세요.
}

$xpay->close();

/* ==================================================================
 * 응답 파라미터
 * ==================================================================
 * 주요 값은 활성, 나머지는 주석 처리해 두었습니다.
 * 필요한 줄의 // 만 지우면 화면에 함께 출력됩니다.
 */

$show = array(

    'LGD_RESPCODE'                 => '응답코드. 0000 이면 성공',
    'LGD_RESPMSG'                  => '응답메시지',

    /* ===== 전체취소 ===== */
    // 'LGD_RESPDATE'                 => '취소일시. YYYYMMDDhhmmss',
    // 'LGD_CANREQDATE'               => '취소요청일시. YYYYMMDDhhmmss',
    // 'LGD_TIMESTAMP'                => '타임스탬프',
    // 'LGD_HASHDATA'                 => '해쉬데이타',
    // 'LGD_CANCEL_DISCOUNT_AMOUNT'   => '할인 취소 금액. 복합결제는 포인트일 수 있음',

    /* ===== 부분취소 ===== */
    // 'LGD_PAYTYPE'                  => '결제수단코드',
    // 'LGD_MID'                      => '상점아이디',
    // 'LGD_OID'                      => '주문번호',
    // 'LGD_TID'                      => '토스페이먼츠 거래번호',
    // 'LGD_RESREMAINAMOUNT'          => '부분취소 후 결제잔액. LGD_REQREMAIN 사용 시만',
    // 'LGD_PARTIALCANCEL_SEQNO_SUB'  => '부분취소 고유번호. LGD_TID + _ + seqno',
    // 'LGD_CASSEQNO'                 => '가상계좌 일련번호. 000 고정',
);
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>결제취소 결과</title>
<style>
  body { font-family: sans-serif; font-size: 14px; max-width: 860px; margin: 20px; }
  table { border-collapse: collapse; }
  th, td { border: 1px solid #ccc; padding: 4px 8px; text-align: left; vertical-align: top; }
</style>
</head>
<body>

<h1>결제취소 결과</h1>

<?php if (!$txOk): ?>
  <p>통신 실패 — 요청을 완료하지 못했습니다. (<?php echo $respCode; ?> <?php echo $respMsg; ?>)</p>
<?php elseif ($success): ?>
  <p>취소 성공</p>
<?php else: ?>
  <p>취소 실패 (<?php echo $respCode; ?> <?php echo $respMsg; ?>)</p>
<?php endif; ?>

<table>
  <tr><th>변수명</th><th>설명</th><th>값</th></tr>
<?php foreach ($show as $name => $desc): ?>
  <tr>
    <th><?php echo $name; ?></th>
    <td><?php echo $desc; ?></td>
    <td><?php echo isset($fields[$name]) ? $fields[$name] : ''; ?></td>
  </tr>
<?php endforeach; ?>
</table>

<?php
/* 명세에 없는 값까지 전부 확인하려면 아래 주석을 푸세요.

echo '<h2>수신된 전체 응답</h2><table>';
foreach ($fields as $name => $value) {
    echo '<tr><th>' . $name . '</th><td>' . $value . '</td></tr>';
}
echo '</table>';

*/
?>

<p>이 페이지는 샘플입니다. 실제 연동에서는 결과를 화면에 노출하지 말고 DB에 기록하세요.</p>

</body>
</html>
