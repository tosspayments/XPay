<?php
/*
 * [현금영수증 발급·취소 요청 페이지]  토스페이먼츠 XPay — UTF-8
 *
 * LGD_METHOD 로 발급(AUTH)과 취소(CANCEL)를 나누고, 결제수단(LGD_PAYTYPE)에 따라 보내는 값이 다르다.
 */

/* ---- 상점 설정 ★ 이 줄만 수정하세요 ---------------------------------- */

// 토스페이먼츠에서 제공한 환경파일(conf/lgdacom.conf, conf/mall.conf) 디렉터리
$configPath = 'C:/lgdacom';


/* ---- 요청 파라미터 --------------------------------------------------- */

$CST_PLATFORM = $_POST['CST_PLATFORM'];   // test 또는 service
$LGD_MID      = ($CST_PLATFORM === 'test' ? 't' : '') . $_POST['CST_MID'];   // 테스트는 앞에 't'
$LGD_METHOD         = $_POST['LGD_METHOD'];
$LGD_PAYTYPE        = $_POST['LGD_PAYTYPE'];
$LGD_OID            = $_POST['LGD_OID'];
$LGD_AMOUNT         = $_POST['LGD_AMOUNT'];
$LGD_TID            = $_POST['LGD_TID'];
$LGD_CASHCARDNUM    = $_POST['LGD_CASHCARDNUM'];
$LGD_CASHRECEIPTUSE = $_POST['LGD_CASHRECEIPTUSE'];
$LGD_CUSTOM_MERTNAME = $_POST['LGD_CUSTOM_MERTNAME'];
$LGD_CUSTOM_BUSINESSNUM = $_POST['LGD_CUSTOM_BUSINESSNUM'];
$LGD_CUSTOM_MERTPHONE = $_POST['LGD_CUSTOM_MERTPHONE'];
$LGD_PRODUCTINFO    = $_POST['LGD_PRODUCTINFO'];

/* ---- 요청 ----------------------------------------------------------- */

require_once __DIR__ . '/../lgdacom/XPayClient.php';

// CST_PLATFORM 값에 따라 lgdacom.conf 의 test_url / url 이 선택된다.
$xpay = new XPayClient($configPath, $CST_PLATFORM);
if (!$xpay->Init_TX($LGD_MID)) {
    header('Content-Type: text/plain; charset=UTF-8');
    exit('상점아이디 설정을 확인하세요: ' . $xpay->Response_Msg());
}

$xpay->Set('LGD_TXNAME', 'CashReceipt');                    // 현금영수증
$xpay->Set('LGD_METHOD', $LGD_METHOD);                      // AUTH 발급 / CANCEL 취소
$xpay->Set('LGD_PAYTYPE', $LGD_PAYTYPE);                    // SC0030 계좌이체 / SC0040 가상계좌 / SC0100 무통장입금 단독

if ($LGD_METHOD === 'AUTH') {                              // 현금영수증 발급
    $xpay->Set('LGD_OID', $LGD_OID);                            // 주문번호. 최대 64자
    $xpay->Set('LGD_AMOUNT', $LGD_AMOUNT);                      // 금액
    $xpay->Set('LGD_CASHCARDNUM', $LGD_CASHCARDNUM);            // 발급번호. 최대 20자
    $xpay->Set('LGD_CASHRECEIPTUSE', $LGD_CASHRECEIPTUSE);      // 1 소득공제 / 2 지출증빙
    $xpay->Set('LGD_CUSTOM_MERTNAME', $LGD_CUSTOM_MERTNAME);    // 상점명. 최대 20자
    $xpay->Set('LGD_CUSTOM_BUSINESSNUM', $LGD_CUSTOM_BUSINESSNUM);  // 사업자등록번호. 최대 10자
    $xpay->Set('LGD_CUSTOM_MERTPHONE', $LGD_CUSTOM_MERTPHONE);  // 상점 전화번호. 최대 11자

    if ($LGD_PAYTYPE === 'SC0030') {                       // 기결제된 계좌이체 건
        $xpay->Set('LGD_TID', $LGD_TID);                            // 결제 때 받은 거래번호 (LGD_PAYKEY 아님)
    } elseif ($LGD_PAYTYPE === 'SC0040') {                 // 기결제된 가상계좌 건
        $xpay->Set('LGD_TID', $LGD_TID);                          
        $xpay->Set('LGD_SEQNO', '001');                             // 가상계좌 일련번호. 001 고정
    } else {                                               // 무통장입금 단독 건
        $xpay->Set('LGD_PRODUCTINFO', $LGD_PRODUCTINFO);            // 상품명. 최대 128자
    }

    /* ---- 선택 파라미터 : 필요한 줄의 주석만 푸세요 (입력 화면에도 같은 이름의 입력란을 추가) ---- */
    // $xpay->Set('LGD_CUSTOM_CEONAME', $_POST['LGD_CUSTOM_CEONAME']);  // 상점 대표자명. 최대 12자
    // $xpay->Set('LGD_CUSTOM_MERTADDRESS', $_POST['LGD_CUSTOM_MERTADDRESS']);  // 상점 주소. 최대 40자
    // $xpay->Set('LGD_TRADEDATE', $_POST['LGD_TRADEDATE']);            // 발급일자. yyyyMMddhhmmss, 거래일로부터 최대 D-2
    // $xpay->Set('LGD_TAXFREEAMOUNT', $_POST['LGD_TAXFREEAMOUNT']);    // 면세금액. 부분면세 계약 시
    // $xpay->Set('LGD_VAT', $_POST['LGD_VAT']);                        // 상점정의 부가세액
} else {                                                   // 현금영수증 취소
    $xpay->Set('LGD_TID', $LGD_TID);                            // 취소할 현금영수증의 거래번호
    if ($LGD_PAYTYPE === 'SC0040') {                       // 가상계좌 건
        $xpay->Set('LGD_SEQNO', '001');                             // 가상계좌 일련번호. 001 고정
    }
}

$txOk     = $xpay->TX();          // lgdacom.conf 의 URL 로 통신
$respCode = $xpay->Response_Code();
$respMsg  = $xpay->Response_Msg();

// 응답 상세. 응답이 없으면 Response_Names() 가 null 을 반환한다.
$fields = array();
$names  = $xpay->Response_Names();
if (is_array($names)) {
    foreach ($names as $name) {
        $fields[$name] = $xpay->Response($name, 0);
    }
}

// 통신 성공 && 응답코드 "0000" 일 때만 성공. 그 외는 모두 실패로 처리한다.
$success = ($txOk && $respCode === '0000');

if ($success) {
    // 성공 결과를 DB 에 반영하세요.
} else {
    // 실패 결과를 DB 에 기록하세요.
}

$xpay->close();

/* ==================================================================
 * 응답 파라미터
 * ==================================================================
 * 주요 값은 활성, 나머지는 주석 처리해 두었습니다.
 * 필요한 줄의 // 만 지우면 화면에 함께 출력됩니다.
 */

$show = array(

    'LGD_RESPCODE'        => '응답코드. 0000 이면 성공',
    'LGD_RESPMSG'         => '응답메시지',
    'LGD_OID'             => '주문번호',
    'LGD_TID'             => '토스페이먼츠 거래번호',
    'LGD_CASHRECEIPTNUM'  => '현금영수증 승인번호',
    'LGD_RESPDATE'        => '처리일시. YYYYMMDDhhmmss',
);
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>현금영수증 발급·취소 결과</title>
<style>
  body { font-family: sans-serif; font-size: 14px; max-width: 860px; margin: 20px; }
  table { border-collapse: collapse; }
  th, td { border: 1px solid #ccc; padding: 4px 8px; text-align: left; vertical-align: top; }
</style>
</head>
<body>

<h1>현금영수증 발급·취소 결과</h1>

<?php if (!$txOk): ?>
  <p>통신 실패 — 요청을 완료하지 못했습니다. (<?php echo $respCode; ?> <?php echo $respMsg; ?>)</p>
<?php elseif ($success): ?>
  <p>처리 성공</p>
<?php else: ?>
  <p>처리 실패 (<?php echo $respCode; ?> <?php echo $respMsg; ?>)</p>
<?php endif; ?>

<table>
  <tr><th>변수명</th><th>설명</th><th>값</th></tr>
<?php foreach ($show as $name => $desc): ?>
  <tr>
    <th><?php echo $name; ?></th>
    <td><?php echo $desc; ?></td>
    <td><?php echo isset($fields[$name]) ? $fields[$name] : ''; ?></td>
  </tr>
<?php endforeach; ?>
</table>

<?php
/* 명세에 없는 값까지 전부 확인하려면 아래 주석을 푸세요.

echo '<h2>수신된 전체 응답</h2><table>';
foreach ($fields as $name => $value) {
    echo '<tr><th>' . $name . '</th><td>' . $value . '</td></tr>';
}
echo '</table>';

*/
?>

<p>이 페이지는 샘플입니다. 실제 연동에서는 결과를 화면에 노출하지 말고 DB에 기록하세요.</p>

</body>
</html>
