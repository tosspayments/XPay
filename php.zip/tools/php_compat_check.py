# Flags PHP syntax/functions newer than PHP 5.6, and constructs removed in PHP 8.
import re,sys,os
RULES=[
 (r'\?\?=?', 'null coalescing ?? (7.0+)'),
 (r'\?->', 'nullsafe ?-> (8.0+)'),
 (r'\bfn\s*\(', 'arrow function (7.4+)'),
 (r'\bmatch\s*\(', 'match (8.0+)'),
 (r'function\s+\w*\s*\([^)]*\b(string|int|float|bool|array|iterable|object|mixed)\s+\$', 'scalar/typed parameter (7.0+)'),
 (r'\)\s*:\s*\??\s*(string|int|float|bool|array|void|self|static|mixed|iterable|object)\b', 'return type (7.0+)'),
 (r'<=>', 'spaceship (7.0+)'),
 (r'\b(str_contains|str_starts_with|str_ends_with|array_key_first|array_key_last|random_bytes|random_int|intdiv)\s*\(', 'function newer than 5.6'),
 (r'\bdeclare\s*\(\s*strict_types', 'strict_types (7.0+)'),
 (r'\$\w+\{\s*[\$\d\w(]', 'curly-brace string offset (removed in 8.0)'),
 (r'\bfunction\s+(\w+)\s*\(', None),  # placeholder (old-style ctor handled below)
 (r'\bmcrypt_\w+\s*\(', 'mcrypt (removed in 7.2)'),
 (r"trigger_error\s*\([^;]*E_USER_ERROR", 'trigger_error(E_USER_ERROR) (deprecated in 8.4)'),
 (r'\(\s*(double|integer|boolean|binary)\s*\)', 'non-canonical cast (deprecated in 8.5)'),
 (r'\b(each|create_function|split|ereg|eregi|mysql_\w+|get_magic_quotes_gpc|money_format)\s*\(', 'function removed in 7.x/8.0'),
 (r'(?<![\w>:$])list\s*\(\s*[\'"]', 'keyed list() (7.1+)'),
 (r'\[\s*\$\w+\s*,\s*\$\w+\s*\]\s*=(?!=)', 'short list destructuring (7.1+)'),
]
bad=0
for root,_,fs in os.walk(sys.argv[1]):
    for f in fs:
        if not f.endswith('.php'): continue
        p=os.path.join(root,f)
        for n,l in enumerate(open(p,encoding='utf-8'),1):
            s=re.sub(r"//.*$|#.*$","",l) if not l.strip().startswith(('*','/*')) else ''
            s=re.sub(r"'(?:\\.|[^'])*'|\"(?:\\.|[^\"])*\"","''",s)
            for rx,msg in RULES:
                if msg and re.search(rx,s): print(f'{p}:{n}: {msg} :: {l.strip()[:90]}'); bad+=1
for root,_,fs in os.walk(sys.argv[1]):
    for f in fs:
        if not f.endswith('.php'): continue
        p=os.path.join(root,f); src=open(p,encoding='utf-8').read()
        for cm in re.finditer(r'(?m)^\s*class\s+(\w+)',src):
            cls=cm.group(1); body=src[cm.end():]
            nxt=re.search(r'(?m)^\s*class\s+\w+',body); body=body[:nxt.start()] if nxt else body
            if re.search(r'function\s+'+cls+r'\s*\(',body,re.I) and not re.search(r'function\s+__construct\s*\(',body):
                print(f'{p}: class {cls}: old-style constructor (not called as constructor in 8.0)'); bad+=1
print('issues:',bad)
