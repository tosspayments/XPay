# PHP 샘플

PHP로 작성된 XPayClient 연동 샘플입니다. Java 샘플과 같은 구조이며, `webapp`을 웹 루트(또는 하위 폴더)에 두고 실행합니다.

## 요구 사항

- **PHP 5.6 ~ 8.x.** 샘플 코드는 PHP 5.6 에서 쓸 수 없는 문법(`??`, 타입 선언, 화살표 함수 등)과 PHP 8 에서 제거된 문법을 쓰지 않습니다. PHP 8.3 에서 모든 오류·경고 출력(`E_ALL`)을 켠 상태로 확인했습니다.
- TLS 1.2 통신이 가능한 OpenSSL (PHP 버전보다 PHP가 빌드된 OpenSSL 버전이 중요합니다. 연동 가이드의 설치 및 환경 구성 참고)
- cURL, OpenSSL 확장 (XPayClient 라이브러리가 사용). 에스크로 샘플은 cURL 이 없으면 `file_get_contents`로 보냅니다.

## 설치

### 1. 설정 폴더 배치

`lgdacom` 폴더를 **웹에서 접근할 수 없는 경로**(예: `C:/lgdacom`)에 복사합니다. `conf` 폴더에는 `ca-bundle.crt`(SSL 인증서)가 함께 들어 있습니다.

```text
C:/lgdacom/
├── conf/
│   ├── lgdacom.conf
│   ├── mall.conf          ← mall.conf.example을 복사해서 만듭니다.
│   └── ca-bundle.crt
└── log/
```

다른 경로를 쓰는 경우 아래 파일 맨 위 "상점 설정"의 `$configPath` 값을 바꿉니다.

- `webapp/acc-cert/AccCert.php`
- `webapp/cancel/Cancel.php`
- `webapp/card-billing/CardAuth.php`
- `webapp/card-keyin/CardAuth.php`
- `webapp/cash-receipt/CashReceipt.php`
- `webapp/mobile-billing/MobileBilling.php`
- `webapp/search/Search.php`
- `webapp/settlement/Settlement.php`
- `webapp/split-settlement/CancelRefund.php`
- `webapp/split-settlement/payreq_crossplatform.php`
- `webapp/split-settlement/payres.php`
- `webapp/unified-checkout/mobile/payreq_crossplatform.php`
- `webapp/unified-checkout/mobile/payres.php`
- `webapp/unified-checkout/pc/payreq_crossplatform.php`
- `webapp/unified-checkout/pc/payres.php`
- `webapp/virtual-account/CyberAccount.php`
- `webapp/virtual-account/cas_noteurl.php`

### 2. mall.conf 작성

맨 아래에 `MID = mertkey`(테스트 MID는 앞에 `t`)를 입력하고, `output_UTF8 = 1`은 그대로 둡니다. PHP 라이브러리는 오류 보고용 주소(`aux_url`)가 `lgdacom.conf`에 없으므로 `report_error = 0`을 기본값으로 둡니다.

### 3. 라이브러리

`webapp/lgdacom/`에 PHP 라이브러리(`XPayClient.php`, `JSON.php`)가 들어 있습니다. 토스페이먼츠 원본 라이브러리는 PHP 8.0 이상에서 구문 오류로 불러올 수 없어, PHP 5.6 ~ 8.x 에서 동작하도록 고친 버전을 넣었습니다. 바뀐 부분은 `webapp/lgdacom/README.md`에 정리했습니다.

### 4. 실행

`webapp`을 웹 서버에 두고 `index.html`에서 기능을 선택합니다. 로컬에서는 `webapp` 폴더에서 `php -S localhost:8080`으로도 실행할 수 있습니다.

## 샘플 작성 규칙

Java 샘플과 같습니다.

- 모든 파일은 UTF-8 이며, 외부 CSS 없이 한 파일 안에서 동작합니다.
- 각 파일 맨 위의 "상점 설정 ★ 이 줄만 수정하세요" 부분만 바꾸면 실행할 수 있습니다.
- 요청 파라미터는 필수 값과 샘플 실행에 필요한 고정값만 활성되어 있고, 선택 파라미터는 모두 주석입니다.
- 결과 페이지의 `$show` 배열에는 주요 응답값만 활성되어 있습니다. 필요한 줄의 `//`만 지우면 화면에 함께 출력됩니다.
- 해시는 XPayClient 의 `GetHashData()`, `GetHashDataCas()`로 만들기 때문에 코드에 mertkey를 쓰지 않습니다.
- 입력값 검증, 화면 출력 시 이스케이프 같은 문자열 처리는 넣지 않았습니다. 가맹점 환경에 맞게 구현합니다.
- `OK`만 응답해야 하는 결과수신 페이지(`cas_noteurl.php` 등)는 PHP 닫는 태그(`?>`)를 쓰지 않습니다. 뒤에 붙는 줄바꿈이 응답에 섞이지 않게 하기 위해서입니다.

## PHP 버전 호환성 확인

`tools/php_compat_check.py`는 PHP 5.6 에서 쓸 수 없는 문법과, PHP 8 에서 제거되거나 deprecated 된 문법·함수(중괄호 문자열 오프셋, 클래스 이름 생성자, `each()`, `mcrypt` 등)를 찾습니다. 샘플이나 라이브러리를 고친 뒤 아래처럼 확인합니다. `XPayClient.php`의 `mcrypt_ecb` 1건은 openssl 이 없는 환경을 위한 대체 경로라 의도된 것입니다.

```bash
python3 tools/php_compat_check.py webapp
```
