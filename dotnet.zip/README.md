# ASP.NET(C#) 샘플

ASP.NET Web Forms(C#)로 작성된 XPayClient 연동 샘플입니다. `webapp`은 그대로 배포할 수 있는 웹 애플리케이션이며, 라이브러리를 한 곳(`bin`)에 두고 기능별 샘플을 폴더로 나누었습니다. 구성은 Java·PHP 샘플과 같습니다.

## 요구 사항

- IIS 와 .NET Framework 4.5 이상 (애플리케이션 풀 .NET CLR v4.0). TLS 1.2 를 쓰려면 .NET Framework 4.5 이상이 필요합니다.
- Windows Server 에서 TLS 1.2 가 활성화되어 있어야 합니다. (연동 가이드의 설치 및 환경 구성 참고)
- 상점 서버에서 XPay 게이트웨이로 나가는 443 포트 허용 (연동 가이드의 방화벽 및 IP 정보 참고)

## 설치

### 1. 설정 폴더 배치

`lgdacom` 폴더를 **웹에서 접근할 수 없는 경로**(예: `C:\lgdacom`)에 복사합니다.

```text
C:\lgdacom\
├── conf\
│   ├── lgdacom.conf
│   └── mall.conf      ← mall.conf.example을 복사해서 만듭니다.
└── log\
```

다른 경로를 쓰는 경우 API 를 호출하는 페이지(`.aspx`) 맨 위 "상점 설정"의 `configPath` 값을 바꿉니다.

### 2. mall.conf 작성

1. `mall.conf.example`을 같은 폴더에 `mall.conf`로 복사합니다.
2. 맨 아래에 `MID = mertkey`를 입력합니다. 테스트 MID 는 앞에 `t`를 붙입니다.
3. `output_UTF8 = 1`과 `default_secure_protocols = 3072`(TLS 1.2)는 그대로 둡니다.

> **주의**
> `mall.conf`는 mertkey 가 들어 있으므로 저장소에 커밋하지 않습니다. (`.gitignore`에 등록되어 있습니다.)

### 3. 웹 애플리케이션 배포

`webapp` 폴더를 IIS 사이트(또는 가상 디렉터리)로 등록합니다. `webapp/bin/XPayClientNet.dll`은 ASP.NET 이 자동으로 참조합니다. 결제 결과를 받는 페이지(`returnurl`, `cas_noteurl` 등)는 각 요청 페이지 "상점 설정"의 주소(`https://상점도메인/...`)를 실제 주소로 바꿉니다.

### 4. 실행

브라우저에서 `index.html`을 열고 기능을 선택합니다.

## 파일 인코딩

모든 파일은 UTF-8 이며, `.aspx` 파일은 **BOM 이 있는 UTF-8**로 저장되어 있습니다. ASP.NET 은 BOM 이 없는 `.aspx`를 서버의 기본 문자셋(한국어 Windows 는 CP949)으로 읽기 때문에, BOM 이 없으면 페이지 안의 한글이 깨집니다. 편집할 때 BOM 을 유지합니다. (Visual Studio 와 메모장은 기본으로 유지합니다.)

## 샘플 작성 규칙

Java·PHP 샘플과 같습니다.

- 페이지는 `.aspx` 한 파일로 되어 있습니다. 코드는 파일 안의 `<% %>` 블록에 있습니다.
- 외부 CSS 없이 한 파일 안에서 동작합니다.
- 요청 파라미터는 필수 값과 샘플 실행에 필요한 고정값만 활성되어 있고, 선택 파라미터는 모두 주석입니다.
- 결과 페이지의 `show` 배열에는 주요 응답값만 활성되어 있습니다. 필요한 줄의 `//`만 지우면 화면에 함께 출력됩니다.
- 해시는 XPayClient 의 `GetHashData()`, `GetHashDataCas()`로 만들기 때문에 코드에 mertkey 를 쓰지 않습니다.
- 입력값 검증, 화면 출력 시 이스케이프 같은 문자열 처리는 넣지 않았습니다. 가맹점 환경에 맞게 구현합니다.
- `OK`만 응답해야 하는 결과수신 페이지는 결과를 쓰기 전에 `Response.Clear()`로 출력을 비웁니다.

## 라이브러리

| 파일 | 버전 | 비고 |
| --- | --- | --- |
| `webapp/bin/XPayClientNet.dll` | 4.0.0.0 | .NET 2.0 런타임용으로 빌드되었고 .NET Framework 4.x 애플리케이션에서 동작합니다. |

라이브러리는 원본 그대로입니다. 소스가 없어 수정하지 않았습니다. 서버 인증서와 호스트명 검증은 .NET 표준 검증 결과를 사용하므로 올바르게 동작합니다. 다만 아래 동작을 알고 사용합니다.

- **인증서 검증 콜백이 애플리케이션 전체에 적용됩니다.** 라이브러리가 `ServicePointManager.ServerCertificateValidationCallback`과 `ServicePointManager.SecurityProtocol`을 설정하므로, 같은 웹 애플리케이션의 다른 HTTPS 통신에도 적용됩니다. 특히 `verify_cert = 0`이면 애플리케이션 전체의 인증서 검증이 꺼집니다. 운영 환경에서는 `verify_cert = 1`을 유지합니다.
- **요청할 때마다 콜백이 추가됩니다.** 라이브러리는 요청마다 콜백을 덧붙이므로, 애플리케이션 풀이 재시작되지 않고 오래 실행되면 콜백이 계속 쌓입니다. IIS 애플리케이션 풀의 정기 재생(Recycling)을 유지합니다.
- **설정 파일과 로그는 EUC-KR 로 처리합니다.** 설정 값은 영문·숫자이므로 UTF-8 `mall.conf`도 정상 동작하며, 한글 주석만 깨져 보일 수 있습니다. 로그 파일은 EUC-KR 로 기록됩니다.
- 요청 본문은 UTF-8(`charset=utf-8`)로 전송됩니다.

## 폴더 구성

```text
dotnet/
├── lgdacom/conf/              # lgdacom.conf, mall.conf.example
└── webapp/
    ├── index.html             # 기능 목록
    ├── bin/XPayClientNet.dll
    ├── unified-checkout/pc/   # 통합결제창 (PC)
    ├── unified-checkout/mobile/
    ├── virtual-account/       # 가상계좌 발급·변경(CyberAccount), 결과수신(cas_noteurl)
    ├── cancel/                # 결제취소
    ├── cash-receipt/          # 현금영수증
    ├── card-keyin/            # 카드 비인증 결제
    ├── card-billing/          # 카드 빌링 결제
    ├── card-billing-window/   # 결제창 빌링키 발급 (PC), mobile/ (모바일)
    ├── mobile-billing/        # 휴대폰 빌링 결제
    ├── split-settlement/      # 분할정산
    ├── acc-cert/              # 계좌 유효성 확인
    ├── search/                # 거래 조회
    └── settlement/            # 수동정산
```

안심키인 결제창 샘플은 `no-xpayclient/ansim-keyin/dotnet`, 에스크로 샘플은 `https-api/escrow/dotnet`에 있습니다.

## 원본 샘플 패키지에서 제외한 것

- `patch.aspx`, `ping.aspx`, `cancel_url.aspx`
- 페이나우 전용 간편결제 샘플 (`TossPayments_Easypay_ASPNET`, `TossPayments_MobileXPay_Easypay_ASPNET`)
- 현금영수증 가맹등록 (`TossPayments_CashReceiptRegisterMert_ASPNET`, 비공개 기능)
- 이전 버전 라이브러리 `XPayClientNet.dll` 2.0.2.0 (`Tosspayments_Xpay_cardAPI_Crossplatform_ASPNET`에 포함)
- 원본 `mall.conf`에 들어 있던 mertkey

카드사·간편결제 직접호출(`LGD_SELF_CUSTOM`, `LGD_CARDTYPE`, `LGD_EASYPAY_ONLY`)은 통합결제창 페이지의 선택 파라미터 주석에 들어 있습니다.
