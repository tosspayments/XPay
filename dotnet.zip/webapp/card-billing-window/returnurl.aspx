﻿<%@ Page Language="C#" ContentType="text/html" ResponseEncoding="utf-8" %>
<%@ Import Namespace="XPayClientNet" %>
<%@ Import Namespace="System.Collections.Generic" %>
<%--
 * [빌링 인증결과 수신 페이지]  토스페이먼츠 XPay — UTF-8
 *
 * 인증창이 결과를 이 페이지(LGD_RETURNURL)로 보낸다. 이 페이지는 인증창 iframe 안에서 열린다.
 * 받은 값을 hidden 필드에 담고 부모 페이지의 payment_return() 을 호출한다.
 * 필드의 id 는 부모 페이지가 읽으므로 바꾸지 않는다.
 * 다른 응답값이 필요하면 아래 목록과 부모 페이지의 payment_return() 에 같은 이름을 추가한다.
--%>
<%
    string LGD_RESPCODE    = Request.Form["LGD_RESPCODE"];
    string LGD_RESPMSG     = Request.Form["LGD_RESPMSG"];
    string LGD_BILLKEY     = Request.Form["LGD_BILLKEY"];
    string LGD_PAYTYPE     = Request.Form["LGD_PAYTYPE"];
    string LGD_PAYDATE     = Request.Form["LGD_PAYDATE"];
    string LGD_FINANCECODE = Request.Form["LGD_FINANCECODE"];
    string LGD_FINANCENAME = Request.Form["LGD_FINANCENAME"];
%>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>XPay 빌링 인증결과</title>
</head>
<body onload="parent.payment_return();">

<p>인증결과를 처리하고 있습니다.</p>

<form method="post" name="LGD_RETURNINFO" id="LGD_RETURNINFO">
  <input type="hidden" id="LGD_RESPCODE" name="LGD_RESPCODE" value="<%= LGD_RESPCODE %>">
  <input type="hidden" id="LGD_RESPMSG" name="LGD_RESPMSG" value="<%= LGD_RESPMSG %>">
  <input type="hidden" id="LGD_BILLKEY" name="LGD_BILLKEY" value="<%= LGD_BILLKEY %>">
  <input type="hidden" id="LGD_PAYTYPE" name="LGD_PAYTYPE" value="<%= LGD_PAYTYPE %>">
  <input type="hidden" id="LGD_PAYDATE" name="LGD_PAYDATE" value="<%= LGD_PAYDATE %>">
  <input type="hidden" id="LGD_FINANCECODE" name="LGD_FINANCECODE" value="<%= LGD_FINANCECODE %>">
  <input type="hidden" id="LGD_FINANCENAME" name="LGD_FINANCENAME" value="<%= LGD_FINANCENAME %>">
</form>

</body>
</html>
