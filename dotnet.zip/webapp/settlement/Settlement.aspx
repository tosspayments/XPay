﻿<%@ Page Language="C#" ContentType="text/html" ResponseEncoding="utf-8" %>
<%@ Import Namespace="XPayClientNet" %>
<%@ Import Namespace="System.Collections.Generic" %>
<%--
 * [수동정산 요청 페이지]  토스페이먼츠 XPay — UTF-8
 *
 * 매입할 거래의 정산을 Settlement 거래로 요청한다.
--%>
<%

    /* ---- 상점 설정 ★ 이 줄만 수정하세요 ---------------------------------- */

    // 토스페이먼츠에서 제공한 환경파일(conf/lgdacom.conf, conf/mall.conf) 디렉터리
    string configPath = "C:\\lgdacom";

    /* ---- 요청 파라미터 --------------------------------------------------- */

    string CST_PLATFORM = Request.Form["CST_PLATFORM"];   // test 또는 service
    string LGD_MID      = ("test".Equals(CST_PLATFORM) ? "t" : "") + Request.Form["CST_MID"];   // 테스트는 앞에 't'
    string LGD_TID            = Request.Form["LGD_TID"];

    /* ---- 요청 ----------------------------------------------------------- */

    // CST_PLATFORM 값에 따라 lgdacom.conf 의 test_url / url 이 선택된다.
    XPayClient xpay = new XPayClient();
    if (!xpay.Init(configPath, CST_PLATFORM) || !xpay.Init_TX(LGD_MID)) {
        Response.ContentType = "text/plain";
        Response.Write("환경파일 또는 상점아이디 설정을 확인하세요: " + xpay.m_szResMsg);
        return;
    }

    xpay.Set("LGD_TXNAME", "Settlement");                         // 수동정산
    xpay.Set("LGD_ENCODING", "UTF-8");                            // 요청 값의 문자셋 (.NET 원본 샘플과 같이 지정)
    xpay.Set("LGD_TID", LGD_TID);                                 // 토스페이먼츠 거래번호
    xpay.Set("LGD_BUYERIP", Request.UserHostAddress);             // 요청한 구매자 IP

    bool txOk     = xpay.TX();          // lgdacom.conf 의 URL 로 통신
    string  respCode = xpay.m_szResCode;
    string  respMsg  = xpay.m_szResMsg;

    // 응답 상세
    Dictionary<string, string> fields = new Dictionary<string, string>();
    for (int i = 0; i < xpay.ResponseNameCount(); i++) {
        string name = xpay.ResponseName(i);
        fields[name] = xpay.Response(name, 0);
    }

    // 통신 성공 && 응답코드 "0000" 일 때만 성공. 그 외는 모두 실패로 처리한다.
    bool success = txOk && "0000".Equals(respCode);

    if (success) {
        // 성공 결과를 DB 에 반영하세요.
    } else {
        // 실패 결과를 DB 에 기록하세요.
    }

    /* ==================================================================
     * 응답 파라미터
     * ==================================================================
     * 주요 값은 활성, 나머지는 주석 처리해 두었습니다.
     * 필요한 줄의 // 만 지우면 화면에 함께 출력됩니다.
     */
    string[][] show = new string[][] {

        new string[] { "LGD_RESPCODE", "응답코드. 0000 이면 성공" },
        new string[] { "LGD_RESPMSG",  "응답메시지" },
    };
%>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>수동정산 결과</title>
<style>
  body { font-family: sans-serif; font-size: 14px; max-width: 860px; margin: 20px; }
  table { border-collapse: collapse; }
  th, td { border: 1px solid #ccc; padding: 4px 8px; text-align: left; vertical-align: top; }
</style>
</head>
<body>

<h1>수동정산 결과</h1>

<% if (!txOk) { %>
  <p>통신 실패 — 요청을 완료하지 못했습니다. (<%= respCode %> <%= respMsg %>)</p>
<% } else if (success) { %>
  <p>정산 요청 성공</p>
<% } else { %>
  <p>정산 요청 실패 (<%= respCode %> <%= respMsg %>)</p>
<% } %>

<table>
  <tr><th>변수명</th><th>설명</th><th>값</th></tr>
<% foreach (string[] f in show) { string v = (fields.ContainsKey(f[0]) ? fields[f[0]] : null); %>
  <tr>
    <th><%= f[0] %></th>
    <td><%= f[1] %></td>
    <td><%= (v != null) ? v : "" %></td>
  </tr>
<% } %>
</table>

<%
/* 명세에 없는 값까지 전부 확인하려면 아래 주석을 푸세요.

Response.Write("<h2>수신된 전체 응답</h2><table>");
foreach (KeyValuePair<string, string> e in fields) {
    Response.Write("<tr><th>" + e.Key + "</th><td>" + e.Value + "</td></tr>");
}
Response.Write("</table>");

*/
%>

<p>이 페이지는 샘플입니다. 실제 연동에서는 결과를 화면에 노출하지 말고 DB에 기록하세요.</p>

</body>
</html>
