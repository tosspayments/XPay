# 분할정산

하나의 결제 금액을 여러 하위 상점으로 나누어 정산합니다. 결제창 결제 요청에 `LGD_DIVIDE_INFO`를 추가하고 `LGD_PRODUCTINFO`를 `padj`로 고정합니다. 취소할 때는 `LGD_DIVIDE_YN=Y`를 보냅니다.

## 흐름

```text
sample_crossplatform.html → payreq_crossplatform.aspx → (통합결제창) → returnurl.aspx → payres.aspx
CancelRefund.html → CancelRefund.aspx
```

## 수정할 곳

| 파일 | 내용 |
| --- | --- |
| `payreq_crossplatform.aspx` | `configPath`. 하위 상점 수가 다르면 `LGD_DIVIDE_INFO`를 만드는 반복문을 고칩니다. |
| `CancelRefund.aspx` | `configPath`. 부분취소는 취소 금액이 발생한 하위 상점아이디(`LGD_DIVIDE_MID_SUB`)가 필요합니다. |

선택 파라미터는 모두 주석으로 들어 있습니다. 필요한 줄의 주석을 풀고, 입력 화면에도 같은 이름의 입력란을 추가합니다.

> **참고**
> 분할정산은 신용카드(간편결제 포함)·계좌이체·가상계좌·빌링 승인에만 적용됩니다. 결제 해시는 일반 결제와 같으며 `GetHashData()`로 만들기 때문에 코드에 mertkey를 쓰지 않습니다.

## 연동 가이드

분할정산, 취소·부분취소
