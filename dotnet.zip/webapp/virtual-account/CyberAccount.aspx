﻿<%@ Page Language="C#" ContentType="text/html" ResponseEncoding="utf-8" %>
<%@ Import Namespace="XPayClientNet" %>
<%@ Import Namespace="System.Collections.Generic" %>
<%--
 * [가상계좌 발급·변경 요청 페이지]  토스페이먼츠 XPay — UTF-8
 *
 * 가상계좌를 발급(ASSIGN)하거나 변경(CHANGE)한다. 입금 결과는 cas_noteurl.aspx 로 받는다.
--%>
<%

    /* ---- 상점 설정 ★ 이 줄만 수정하세요 ---------------------------------- */

    // 토스페이먼츠에서 제공한 환경파일(conf/lgdacom.conf, conf/mall.conf) 디렉터리
    string configPath = "C:\\lgdacom";

    /* ---- 요청 파라미터 --------------------------------------------------- */

    string CST_PLATFORM = Request.Form["CST_PLATFORM"];   // test 또는 service
    string LGD_MID      = ("test".Equals(CST_PLATFORM) ? "t" : "") + Request.Form["CST_MID"];   // 테스트는 앞에 't'
    string LGD_METHOD         = Request.Form["LGD_METHOD"];
    string LGD_OID            = Request.Form["LGD_OID"];
    string LGD_AMOUNT         = Request.Form["LGD_AMOUNT"];
    string LGD_PRODUCTINFO    = Request.Form["LGD_PRODUCTINFO"];
    string LGD_BUYER          = Request.Form["LGD_BUYER"];
    string LGD_BANKCODE       = Request.Form["LGD_BANKCODE"];
    string LGD_ACCOUNTOWNER   = Request.Form["LGD_ACCOUNTOWNER"];
    string LGD_ACCOUNTPID     = Request.Form["LGD_ACCOUNTPID"];

    /* ---- 요청 ----------------------------------------------------------- */

    // CST_PLATFORM 값에 따라 lgdacom.conf 의 test_url / url 이 선택된다.
    XPayClient xpay = new XPayClient();
    if (!xpay.Init(configPath, CST_PLATFORM) || !xpay.Init_TX(LGD_MID)) {
        Response.ContentType = "text/plain";
        Response.Write("환경파일 또는 상점아이디 설정을 확인하세요: " + xpay.m_szResMsg);
        return;
    }

    // 가상계좌 결과수신 페이지(LGD_CASNOTEURL). 실제 주소로 바꾸세요. 표준포트(80, 443)만 사용할 수 있습니다.
    string LGD_CASNOTEURL = "https://상점도메인/xpay/virtual-account/cas_noteurl.aspx";

    xpay.Set("LGD_TXNAME", "CyberAccount");                       // 가상계좌
    xpay.Set("LGD_ENCODING", "UTF-8");                            // 요청 값의 문자셋 (.NET 원본 샘플과 같이 지정)
    xpay.Set("LGD_METHOD", LGD_METHOD);                           // ASSIGN 발급 / CHANGE 변경
    xpay.Set("LGD_OID", LGD_OID);                                 // 주문번호. 최대 64자
    xpay.Set("LGD_AMOUNT", LGD_AMOUNT);                           // 결제금액. 숫자만
    xpay.Set("LGD_PRODUCTINFO", LGD_PRODUCTINFO);                 // 상품명
    xpay.Set("LGD_BUYER", LGD_BUYER);                             // 구매자명
    xpay.Set("LGD_BANKCODE", LGD_BANKCODE);                       // 은행코드. 발급 시 필수
    xpay.Set("LGD_ACCOUNTOWNER", LGD_ACCOUNTOWNER);               // 입금자명
    xpay.Set("LGD_ACCOUNTPID", LGD_ACCOUNTPID);                   // 구매자 생년월일 또는 사업자번호
    xpay.Set("LGD_CASNOTEURL", LGD_CASNOTEURL);                   // 입금·취소 결과수신 페이지
    xpay.Set("LGD_BUYERIP", Request.UserHostAddress);             // 요청한 구매자 IP

    /* ---- 선택 파라미터 : 필요한 줄의 주석만 푸세요 (입력 화면에도 같은 이름의 입력란을 추가) ---- */
    // xpay.Set("LGD_BUYERPHONE", Request.Form["LGD_BUYERPHONE"]);   // 구매자 휴대폰번호
    // xpay.Set("LGD_BUYEREMAIL", Request.Form["LGD_BUYEREMAIL"]);   // 구매자 이메일
    // xpay.Set("LGD_CLOSEDATE", Request.Form["LGD_CLOSEDATE"]);     // 입금 마감일시. yyyyMMddHHmmss
    // xpay.Set("LGD_CASHRECEIPTUSE", Request.Form["LGD_CASHRECEIPTUSE"]);  // 현금영수증 용도. 1 소득공제 / 2 지출증빙
    // xpay.Set("LGD_CASHCARDNUM", Request.Form["LGD_CASHCARDNUM"]);  // 현금영수증 발급번호
    // xpay.Set("LGD_TAXFREEAMOUNT", Request.Form["LGD_TAXFREEAMOUNT"]);  // 면세금액
    // xpay.Set("LGD_ESCROW_USEYN", Request.Form["LGD_ESCROW_USEYN"]);  // 에스크로 적용. Y / N

    bool txOk     = xpay.TX();          // lgdacom.conf 의 URL 로 통신
    string  respCode = xpay.m_szResCode;
    string  respMsg  = xpay.m_szResMsg;

    // 응답 상세
    Dictionary<string, string> fields = new Dictionary<string, string>();
    for (int i = 0; i < xpay.ResponseNameCount(); i++) {
        string name = xpay.ResponseName(i);
        fields[name] = xpay.Response(name, 0);
    }

    // 통신 성공 && 응답코드 "0000" 일 때만 성공. 그 외는 모두 실패로 처리한다.
    bool success = txOk && "0000".Equals(respCode);

    if (success) {
        // 성공 결과를 DB 에 반영하세요.
    } else {
        // 실패 결과를 DB 에 기록하세요.
    }

    /* ==================================================================
     * 응답 파라미터
     * ==================================================================
     * 주요 값은 활성, 나머지는 주석 처리해 두었습니다.
     * 필요한 줄의 // 만 지우면 화면에 함께 출력됩니다.
     */
    string[][] show = new string[][] {

        new string[] { "LGD_RESPCODE",        "응답코드. 0000 이면 성공" },
        new string[] { "LGD_RESPMSG",         "응답메시지" },
        new string[] { "LGD_OID",             "주문번호" },
        new string[] { "LGD_TID",             "토스페이먼츠 거래번호" },
        new string[] { "LGD_AMOUNT",          "결제금액" },
        new string[] { "LGD_FINANCECODE",     "은행코드" },
        new string[] { "LGD_FINANCENAME",     "은행명" },
        new string[] { "LGD_ACCOUNTNUM",      "발급된 가상계좌 번호" },
        new string[] { "LGD_SAOWNER",         "입금할 때 표시되는 계좌주명" },
        new string[] { "LGD_CLOSEDATE",       "입금 마감일시" },

        /* ===== 현금영수증 ===== */
        // new string[] { "LGD_CASHRECEIPTNUM",  "현금영수증 승인번호" },
        // new string[] { "LGD_CASHRECEIPTKIND", "0 소득공제 / 1 지출증빙" },

        /* ===== 기타 ===== */
        // new string[] { "LGD_PAYTYPE",         "결제수단코드" },
        // new string[] { "LGD_PAYDATE",         "처리일시" },
        // new string[] { "LGD_ESCROWYN",        "에스크로 적용" },
    };
%>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>가상계좌 발급·변경 결과</title>
<style>
  body { font-family: sans-serif; font-size: 14px; max-width: 860px; margin: 20px; }
  table { border-collapse: collapse; }
  th, td { border: 1px solid #ccc; padding: 4px 8px; text-align: left; vertical-align: top; }
</style>
</head>
<body>

<h1>가상계좌 발급·변경 결과</h1>

<% if (!txOk) { %>
  <p>통신 실패 — 요청을 완료하지 못했습니다. (<%= respCode %> <%= respMsg %>)</p>
<% } else if (success) { %>
  <p>처리 성공</p>
<% } else { %>
  <p>처리 실패 (<%= respCode %> <%= respMsg %>)</p>
<% } %>

<table>
  <tr><th>변수명</th><th>설명</th><th>값</th></tr>
<% foreach (string[] f in show) { string v = (fields.ContainsKey(f[0]) ? fields[f[0]] : null); %>
  <tr>
    <th><%= f[0] %></th>
    <td><%= f[1] %></td>
    <td><%= (v != null) ? v : "" %></td>
  </tr>
<% } %>
</table>

<%
/* 명세에 없는 값까지 전부 확인하려면 아래 주석을 푸세요.

Response.Write("<h2>수신된 전체 응답</h2><table>");
foreach (KeyValuePair<string, string> e in fields) {
    Response.Write("<tr><th>" + e.Key + "</th><td>" + e.Value + "</td></tr>");
}
Response.Write("</table>");

*/
%>

<p>이 페이지는 샘플입니다. 실제 연동에서는 결과를 화면에 노출하지 말고 DB에 기록하세요.</p>

</body>
</html>
