# 휴대폰 빌링 결제

휴대폰 결제를 자동결제(빌링)로 요청합니다. 원본 샘플과 같이 `LGD_TXNAME=Mobile`, `LGD_AUTHMODE=BILLING`으로 요청합니다.

## 흐름

```text
MobileBilling.html → MobileBilling.jsp
```

## 수정할 곳

| 파일 | 내용 |
| --- | --- |
| `MobileBilling.jsp` | `configPath`. 결제 성공·실패 DB 처리를 구현합니다. DB 처리에 실패하면 `Rollback()`으로 자동취소합니다. 발급받은 빌링키로 결제할 때는 `LGD_BILLKEY` 줄의 주석을 풉니다. |

선택 파라미터는 모두 주석으로 들어 있습니다. 필요한 줄의 주석을 풀고, 입력 화면에도 같은 이름의 입력란을 추가합니다.

## 연동 가이드

휴대폰 빌링
