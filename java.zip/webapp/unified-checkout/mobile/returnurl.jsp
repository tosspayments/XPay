<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%--
 * [인증결과 수신 페이지]  토스페이먼츠 XPay (모바일용) — UTF-8
 *
 * 결제창이 인증을 마치면 이 페이지(LGD_RETURNURL)로 이동한다.
 * 인증에 성공하면 받은 LGD_PAYKEY 로 payres.jsp 에 최종 결제를 요청한다.
--%>
<%
    request.setCharacterEncoding("UTF-8");
    String LGD_RESPCODE = request.getParameter("LGD_RESPCODE");
    String LGD_RESPMSG  = request.getParameter("LGD_RESPMSG");
    String LGD_PAYKEY   = request.getParameter("LGD_PAYKEY");
    String LGD_MID      = request.getParameter("LGD_MID");
    boolean authOk = "0000".equals(LGD_RESPCODE);
%>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>XPay 인증결과</title>
</head>
<body<%= authOk ? " onload=\"document.getElementById('LGD_PAYRES').submit();\"" : "" %>>

<% if (authOk) { %>
  <p>최종 결제를 요청하고 있습니다.</p>
  <form method="post" name="LGD_PAYRES" id="LGD_PAYRES" action="payres.jsp">
    <input type="hidden" name="LGD_MID"    value="<%= LGD_MID %>">
    <input type="hidden" name="LGD_PAYKEY" value="<%= LGD_PAYKEY %>">
  </form>
<% } else { %>
  <!-- 인증 실패에 대한 처리를 여기에 추가하세요. -->
  <p>인증 실패 — 결과코드 <%= LGD_RESPCODE %>, <%= LGD_RESPMSG %></p>
<% } %>

</body>
</html>
