# 통합결제창 결제 (모바일)

결제창으로 페이지를 이동해 인증한 뒤, XPayClient로 최종 승인을 요청합니다.

## 흐름

```text
sample_crossplatform.html → payreq_crossplatform.jsp → (통합결제창) → returnurl.jsp → payres.jsp
```

## 수정할 곳

| 파일 | 내용 |
| --- | --- |
| `payreq_crossplatform.jsp` | `configPath`. 상점 앱(WebView)에서 결제할 때는 주석으로 넣어 둔 앱 스킴 파라미터(`LGD_KVPMISPWAPURL` 등)를 설정합니다. |
| `payres.jsp` | `configPath`와 `CST_PLATFORM`. 모바일은 결제창이 연동 환경을 돌려주지 않으므로, 서비스로 전환할 때 `CST_PLATFORM`을 `service`로 바꿉니다. |

선택 파라미터는 모두 주석으로 들어 있습니다. 필요한 줄의 주석을 풀고, 입력 화면에도 같은 이름의 입력란을 추가합니다.

## 연동 가이드

통합결제창 결제, XPayClient 호출 패턴(결제창 결제 - 모바일)
