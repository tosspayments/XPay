# 가상계좌

결제창 없이 API 로 가상계좌를 발급·변경하는 샘플(`CyberAccount`)과, 입금 결과를 받는 결과수신 페이지(`cas_noteurl`)가 들어 있습니다.

가상계좌 할당(`R`)·입금(`I`)·입금취소(`C`) 결과를 토스페이먼츠로부터 받아 처리합니다. 결제창 결제의 `LGD_CASNOTEURL`에 이 페이지 주소를 지정합니다. (통합결제창 샘플은 이미 지정되어 있습니다.)

## 흐름

```text
CyberAccount.html → CyberAccount.jsp            (발급·변경)
토스페이먼츠 → cas_noteurl.jsp (서버 간 호출) → "OK" 응답   (할당·입금·입금취소 결과)
```

## 수정할 곳

| 파일 | 내용 |
| --- | --- |
| `CyberAccount.jsp` | `configPath`, 그리고 "상점 설정"의 `LGD_CASNOTEURL`을 실제 주소로 바꿉니다. 발급(`ASSIGN`)은 은행코드(`LGD_BANKCODE`)가 필요합니다. |
| `cas_noteurl.jsp` | `configPath`. 할당·입금·입금취소별 DB 처리를 구현합니다. 응답 해시는 `GetHashDataCas()`가 `mall.conf`의 mertkey로 검증합니다. |

선택 파라미터는 모두 주석으로 들어 있습니다. 필요한 줄의 주석을 풀고, 입력 화면에도 같은 이름의 입력란을 추가합니다.

> **참고**
> DB 처리를 마쳤으면 `OK`만 출력해야 합니다. 입금통보는 표준 포트(80, 443)로만 받을 수 있고, 토스페이먼츠 입금통보 IP를 방화벽에 허용해야 합니다.

## 연동 가이드

가상계좌 발급·변경, 방화벽 및 IP 정보(인바운드 IP)
