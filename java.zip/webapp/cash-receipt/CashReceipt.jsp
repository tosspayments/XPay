<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="lgdacom.XPayClient.XPayClient, java.util.LinkedHashMap, java.util.Map" %>
<%--
 * [현금영수증 발급·취소 요청 페이지]  토스페이먼츠 XPay — UTF-8
 *
 * LGD_METHOD 로 발급(AUTH)과 취소(CANCEL)를 나누고, 결제수단(LGD_PAYTYPE)에 따라 보내는 값이 다르다.
--%>
<%
    request.setCharacterEncoding("UTF-8");

    /* ---- 상점 설정 ★ 이 줄만 수정하세요 ---------------------------------- */

    // 토스페이먼츠에서 제공한 환경파일(conf/lgdacom.conf, conf/mall.conf) 디렉터리
    String configPath = "C:/lgdacom";

    /* ---- 요청 파라미터 --------------------------------------------------- */

    String CST_PLATFORM = request.getParameter("CST_PLATFORM");   // test 또는 service
    String LGD_MID      = ("test".equals(CST_PLATFORM) ? "t" : "") + request.getParameter("CST_MID");   // 테스트는 앞에 't'
    String LGD_METHOD         = request.getParameter("LGD_METHOD");
    String LGD_PAYTYPE        = request.getParameter("LGD_PAYTYPE");
    String LGD_OID            = request.getParameter("LGD_OID");
    String LGD_AMOUNT         = request.getParameter("LGD_AMOUNT");
    String LGD_TID            = request.getParameter("LGD_TID");
    String LGD_CASHCARDNUM    = request.getParameter("LGD_CASHCARDNUM");
    String LGD_CASHRECEIPTUSE = request.getParameter("LGD_CASHRECEIPTUSE");
    String LGD_CUSTOM_MERTNAME = request.getParameter("LGD_CUSTOM_MERTNAME");
    String LGD_CUSTOM_BUSINESSNUM = request.getParameter("LGD_CUSTOM_BUSINESSNUM");
    String LGD_CUSTOM_MERTPHONE = request.getParameter("LGD_CUSTOM_MERTPHONE");
    String LGD_PRODUCTINFO    = request.getParameter("LGD_PRODUCTINFO");

    /* ---- 요청 ----------------------------------------------------------- */

    // CST_PLATFORM 값에 따라 lgdacom.conf 의 test_url / url 이 선택된다.
    XPayClient xpay = new XPayClient();
    if (!xpay.Init(configPath, CST_PLATFORM) || !xpay.Init_TX(LGD_MID)) {
        response.setContentType("text/plain; charset=UTF-8");
        out.print("환경파일 또는 상점아이디 설정을 확인하세요: " + xpay.m_szResMsg);
        return;
    }

    xpay.Set("LGD_TXNAME", "CashReceipt");                          // 현금영수증
    xpay.Set("LGD_METHOD", LGD_METHOD);                             // AUTH 발급 / CANCEL 취소
    xpay.Set("LGD_PAYTYPE", LGD_PAYTYPE);                           // SC0030 계좌이체 / SC0040 가상계좌 / SC0100 무통장입금 단독

    if ("AUTH".equals(LGD_METHOD)) {                         // 현금영수증 발급
        xpay.Set("LGD_OID", LGD_OID);                                   // 주문번호. 최대 64자
        xpay.Set("LGD_AMOUNT", LGD_AMOUNT);                             // 금액
        xpay.Set("LGD_CASHCARDNUM", LGD_CASHCARDNUM);                   // 발급번호. 최대 20자
        xpay.Set("LGD_CASHRECEIPTUSE", LGD_CASHRECEIPTUSE);             // 1 소득공제 / 2 지출증빙
        xpay.Set("LGD_CUSTOM_MERTNAME", LGD_CUSTOM_MERTNAME);           // 상점명. 최대 20자
        xpay.Set("LGD_CUSTOM_BUSINESSNUM", LGD_CUSTOM_BUSINESSNUM);     // 사업자등록번호. 최대 10자
        xpay.Set("LGD_CUSTOM_MERTPHONE", LGD_CUSTOM_MERTPHONE);         // 상점 전화번호. 최대 11자

        if ("SC0030".equals(LGD_PAYTYPE)) {                  // 기결제된 계좌이체 건
            xpay.Set("LGD_TID", LGD_TID);                                   // 결제 때 받은 거래번호 (LGD_PAYKEY 아님)
        } else if ("SC0040".equals(LGD_PAYTYPE)) {           // 기결제된 가상계좌 건
            xpay.Set("LGD_TID", LGD_TID);                                 
            xpay.Set("LGD_SEQNO", "001");                                   // 가상계좌 일련번호. 001 고정
        } else {                                             // 무통장입금 단독 건
            xpay.Set("LGD_PRODUCTINFO", LGD_PRODUCTINFO);                   // 상품명. 최대 128자
        }

        /* ---- 선택 파라미터 : 필요한 줄의 주석만 푸세요 (입력 화면에도 같은 이름의 입력란을 추가) ---- */
        // xpay.Set("LGD_CUSTOM_CEONAME", request.getParameter("LGD_CUSTOM_CEONAME"));  // 상점 대표자명. 최대 12자
        // xpay.Set("LGD_CUSTOM_MERTADDRESS", request.getParameter("LGD_CUSTOM_MERTADDRESS"));  // 상점 주소. 최대 40자
        // xpay.Set("LGD_TRADEDATE", request.getParameter("LGD_TRADEDATE"));  // 발급일자. yyyyMMddhhmmss, 거래일로부터 최대 D-2
        // xpay.Set("LGD_TAXFREEAMOUNT", request.getParameter("LGD_TAXFREEAMOUNT"));  // 면세금액. 부분면세 계약 시
        // xpay.Set("LGD_VAT", request.getParameter("LGD_VAT"));       // 상점정의 부가세액
    } else {                                                 // 현금영수증 취소
        xpay.Set("LGD_TID", LGD_TID);                                   // 취소할 현금영수증의 거래번호
        if ("SC0040".equals(LGD_PAYTYPE)) {                  // 가상계좌 건
            xpay.Set("LGD_SEQNO", "001");                                   // 가상계좌 일련번호. 001 고정
        }
    }

    boolean txOk     = xpay.TX();          // lgdacom.conf 의 URL 로 통신
    String  respCode = xpay.m_szResCode;
    String  respMsg  = xpay.m_szResMsg;

    // 응답 상세
    Map<String, String> fields = new LinkedHashMap<String, String>();
    for (int i = 0; i < xpay.ResponseNameCount(); i++) {
        String name = xpay.ResponseName(i);
        fields.put(name, xpay.Response(name, 0));
    }

    // 통신 성공 && 응답코드 "0000" 일 때만 성공. 그 외는 모두 실패로 처리한다.
    boolean success = txOk && "0000".equals(respCode);

    if (success) {
        // 성공 결과를 DB 에 반영하세요.
    } else {
        // 실패 결과를 DB 에 기록하세요.
    }

    /* ==================================================================
     * 응답 파라미터
     * ==================================================================
     * 주요 값은 활성, 나머지는 주석 처리해 두었습니다.
     * 필요한 줄의 // 만 지우면 화면에 함께 출력됩니다.
     */
    String[][] show = {

        { "LGD_RESPCODE",       "응답코드. 0000 이면 성공" },
        { "LGD_RESPMSG",        "응답메시지" },
        { "LGD_OID",            "주문번호" },
        { "LGD_TID",            "토스페이먼츠 거래번호" },
        { "LGD_CASHRECEIPTNUM", "현금영수증 승인번호" },
        { "LGD_RESPDATE",       "처리일시. YYYYMMDDhhmmss" },
    };
%>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>현금영수증 발급·취소 요청 페이지 결과</title>
<style>
  body { font-family: sans-serif; font-size: 14px; max-width: 860px; margin: 20px; }
  table { border-collapse: collapse; }
  th, td { border: 1px solid #ccc; padding: 4px 8px; text-align: left; vertical-align: top; }
</style>
</head>
<body>

<h1>현금영수증 발급·취소 요청 페이지 결과</h1>

<% if (!txOk) { %>
  <p>통신 실패 — 요청을 완료하지 못했습니다. (<%= respCode %> <%= respMsg %>)</p>
<% } else if (success) { %>
  <p>처리 성공</p>
<% } else { %>
  <p>처리 실패 (<%= respCode %> <%= respMsg %>)</p>
<% } %>

<table>
  <tr><th>변수명</th><th>설명</th><th>값</th></tr>
<% for (String[] f : show) { String v = fields.get(f[0]); %>
  <tr>
    <th><%= f[0] %></th>
    <td><%= f[1] %></td>
    <td><%= (v != null) ? v : "" %></td>
  </tr>
<% } %>
</table>

<%
/* 명세에 없는 값까지 전부 확인하려면 아래 주석을 푸세요.

out.println("<h2>수신된 전체 응답</h2><table>");
for (Map.Entry<String, String> e : fields.entrySet()) {
    out.println("<tr><th>" + e.getKey() + "</th><td>" + e.getValue() + "</td></tr>");
}
out.println("</table>");

*/
%>

<p>이 페이지는 샘플입니다. 실제 연동에서는 결과를 화면에 노출하지 말고 DB에 기록하세요.</p>

</body>
</html>
