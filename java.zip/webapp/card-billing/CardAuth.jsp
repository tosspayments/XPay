<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="lgdacom.XPayClient.XPayClient, java.util.LinkedHashMap, java.util.Map" %>
<%--
 * [카드 빌링 결제 요청 페이지]  토스페이먼츠 XPay — UTF-8
 *
 * 발급받은 빌링키로 CardAuth 거래 승인을 요청한다. 빌링키는 LGD_PAN 으로 보낸다.
 * 빌링키 발급은 card-billing-window 샘플을 참고한다.
 * 결제는 성공했지만 상점 DB 처리에 실패하면 Rollback() 으로 자동취소한다.
--%>
<%
    request.setCharacterEncoding("UTF-8");

    /* ---- 상점 설정 ★ 이 줄만 수정하세요 ---------------------------------- */

    // 토스페이먼츠에서 제공한 환경파일(conf/lgdacom.conf, conf/mall.conf) 디렉터리
    String configPath = "C:/lgdacom";

    /* ---- 요청 파라미터 --------------------------------------------------- */

    String CST_PLATFORM = request.getParameter("CST_PLATFORM");   // test 또는 service
    String LGD_MID      = ("test".equals(CST_PLATFORM) ? "t" : "") + request.getParameter("CST_MID");   // 테스트는 앞에 't'
    String LGD_OID            = request.getParameter("LGD_OID");
    String LGD_AMOUNT         = request.getParameter("LGD_AMOUNT");
    String LGD_BUYER          = request.getParameter("LGD_BUYER");
    String LGD_PRODUCTINFO    = request.getParameter("LGD_PRODUCTINFO");
    String LGD_PAN            = request.getParameter("LGD_PAN");
    String LGD_INSTALL        = request.getParameter("LGD_INSTALL");

    /* ---- 요청 ----------------------------------------------------------- */

    // CST_PLATFORM 값에 따라 lgdacom.conf 의 test_url / url 이 선택된다.
    XPayClient xpay = new XPayClient();
    if (!xpay.Init(configPath, CST_PLATFORM) || !xpay.Init_TX(LGD_MID)) {
        response.setContentType("text/plain; charset=UTF-8");
        out.print("환경파일 또는 상점아이디 설정을 확인하세요: " + xpay.m_szResMsg);
        return;
    }

    xpay.Set("LGD_TXNAME", "CardAuth");                             // 카드 승인
    xpay.Set("LGD_OID", LGD_OID);                                   // 주문번호. 최대 64자
    xpay.Set("LGD_AMOUNT", LGD_AMOUNT);                             // 결제금액. 숫자만
    xpay.Set("LGD_PAN", LGD_PAN);                                   // 카드번호 대신 발급받은 빌링키
    xpay.Set("LGD_INSTALL", LGD_INSTALL);                           // 할부개월. 00 일시불
    xpay.Set("VBV_ECI", "010");                                     // 빌링 고정값
    xpay.Set("LGD_BUYER", LGD_BUYER);                               // 구매자명. 최대 10자
    xpay.Set("LGD_PRODUCTINFO", LGD_PRODUCTINFO);                   // 상품명. 최대 128자
    xpay.Set("LGD_BUYERIP", request.getRemoteAddr());               // 결제를 요청한 구매자 IP

    /* ---- 선택 파라미터 : 필요한 줄의 주석만 푸세요 (입력 화면에도 같은 이름의 입력란을 추가) ---- */
    // xpay.Set("LGD_BUYERID", request.getParameter("LGD_BUYERID"));  // 구매자 아이디. 최대 15자
    // xpay.Set("LGD_BUYERPHONE", request.getParameter("LGD_BUYERPHONE"));  // 구매자 휴대폰번호. 최대 11자
    // xpay.Set("LGD_BUYEREMAIL", request.getParameter("LGD_BUYEREMAIL"));  // 구매자 이메일. 최대 40자
    // xpay.Set("LGD_TAXFREEAMOUNT", request.getParameter("LGD_TAXFREEAMOUNT"));  // 면세금액. 부분면세 계약 시
    // xpay.Set("LGD_BUYERADDRESS", "");                               // 구매자 주소. 최대 128자
    // xpay.Set("LGD_RECEIVER", "");                                   // 수취인. 최대 10자
    // xpay.Set("LGD_RECEIVERPHONE", "");                              // 수취인 전화번호. 최대 15자
    // xpay.Set("LGD_DELIVERYINFO", "");                               // 배송정보. 최대 128자
    // xpay.Set("LGD_PRODUCTCODE", "");                                // 상품코드. 최대 40자

    boolean txOk     = xpay.TX();          // lgdacom.conf 의 URL 로 통신
    String  respCode = xpay.m_szResCode;
    String  respMsg  = xpay.m_szResMsg;

    // 응답 상세
    Map<String, String> fields = new LinkedHashMap<String, String>();
    for (int i = 0; i < xpay.ResponseNameCount(); i++) {
        String name = xpay.ResponseName(i);
        fields.put(name, xpay.Response(name, 0));
    }

    // 통신 성공 && 응답코드 "0000" 일 때만 성공. 그 외는 모두 실패로 처리한다.
    boolean success = txOk && "0000".equals(respCode);

    if (success) {
        // 결제 성공 DB 처리를 여기에서 수행하세요.
        boolean isDBOK = true;
        if (!isDBOK) {
            // 결제는 성공했지만 상점 DB 처리에 실패했다면 자동취소를 요청합니다.
            xpay.Rollback("상점 DB 처리 실패 [TID:" + fields.get("LGD_TID") + ", OID:" + fields.get("LGD_OID") + "]");
        }
    } else {
        // 결제 실패 DB 처리를 여기에서 수행하세요.
    }

    /* ==================================================================
     * 응답 파라미터
     * ==================================================================
     * 주요 값은 활성, 나머지는 주석 처리해 두었습니다.
     * 필요한 줄의 // 만 지우면 화면에 함께 출력됩니다.
     */
    String[][] show = {

        { "LGD_RESPCODE",          "응답코드. 0000 이면 성공" },
        { "LGD_RESPMSG",           "응답메시지. 최대 160자" },
        { "LGD_MID",               "상점아이디. 최대 15자" },
        { "LGD_OID",               "주문번호. 최대 64자" },
        { "LGD_TID",               "토스페이먼츠 거래번호. 최대 24자" },
        { "LGD_AMOUNT",            "결제금액. 최대 12자" },
        { "LGD_PAYTYPE",           "결제수단코드. 신용카드 SC0010" },
        { "LGD_PAYDATE",           "결제일시. yyyyMMddHHmmss" },
        { "LGD_FINANCECODE",       "결제기관코드. 최대 10자" },
        { "LGD_FINANCENAME",       "결제기관명. 최대 20자" },
        { "LGD_FINANCEAUTHNUM",    "결제기관 승인번호. 최대 20자" },
        { "LGD_CARDNUM",           "신용카드번호. 일반 가맹점은 * 처리" },
        { "LGD_CARDINSTALLMONTH",  "할부개월. 포인트 결제는 +60, 현대카드 포인트 +80, save 포인트 +40" },

        /* ===== 구매자·상품 ===== */
        // { "LGD_BUYER",             "구매자명" },
        // { "LGD_BUYERID",           "구매자 아이디" },
        // { "LGD_BUYERPHONE",        "구매자 휴대폰번호" },
        // { "LGD_BUYEREMAIL",        "구매자 이메일" },
        // { "LGD_BUYERADDRESS",      "구매자 주소" },
        // { "LGD_BUYERSSN",          "구매자 생년월일(또는 사업자번호)" },
        // { "LGD_PRODUCTINFO",       "상품명" },
        // { "LGD_PRODUCTCODE",       "상품코드" },
        // { "LGD_RECEIVER",          "수취인" },
        // { "LGD_RECEIVERPHONE",     "수취인 전화번호" },

        /* ===== 카드 추가정보 ===== */
        // { "LGD_CARDACQUIRER",      "카드 매입사 코드" },
        // { "LGD_CARDGUBUN1",        "0 개인 / 1 법인 / 9 미확인" },
        // { "LGD_CARDGUBUN2",        "0 신용 / 1 체크 / 2 기프트 / 9 미확인" },
        // { "LGD_CARDNOINTEREST_YN", "카드사부담 무이자. 1 무이자 / 0 일반" },
        // { "LGD_CARDNOINTYN",       "상점부담 무이자. 1 무이자 / 0 일반" },

        /* ===== 즉시할인·부분취소 ===== */
        // { "LGD_DCNO",              "즉시할인 적용 거래면 DC" },
        // { "LGD_DISCOUNTUSEYN",     "즉시할인 적용. 1 적용 / 0 미적용" },
        // { "LGD_DISCOUNTUSEAMOUNT", "즉시할인 금액" },
        // { "LGD_PCANCELFLAG",       "부분취소 가능. 1 가능 / 0 불가" },
        // { "LGD_PCANCELSTR",        "부분취소 불가 사유. 가능하면 0" },

        /* ===== 기타 ===== */
        // { "LGD_TAXFREEAMOUNT",     "면세금액" },
        // { "LGD_ESCROWYN",          "에스크로 적용. Y / N" },
        // { "LGD_HASHDATA",          "해쉬데이타" },
        // { "LGD_TIMESTAMP",         "타임스탬프" },
        // { "LGD_BILLKEY",           "빌링키" },
    };
%>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>카드 빌링 결제 요청 페이지 결과</title>
<style>
  body { font-family: sans-serif; font-size: 14px; max-width: 860px; margin: 20px; }
  table { border-collapse: collapse; }
  th, td { border: 1px solid #ccc; padding: 4px 8px; text-align: left; vertical-align: top; }
</style>
</head>
<body>

<h1>카드 빌링 결제 요청 페이지 결과</h1>

<% if (!txOk) { %>
  <p>통신 실패 — 요청을 완료하지 못했습니다. (<%= respCode %> <%= respMsg %>)</p>
<% } else if (success) { %>
  <p>결제 성공</p>
<% } else { %>
  <p>결제 실패 (<%= respCode %> <%= respMsg %>)</p>
<% } %>

<table>
  <tr><th>변수명</th><th>설명</th><th>값</th></tr>
<% for (String[] f : show) { String v = fields.get(f[0]); %>
  <tr>
    <th><%= f[0] %></th>
    <td><%= f[1] %></td>
    <td><%= (v != null) ? v : "" %></td>
  </tr>
<% } %>
</table>

<%
/* 명세에 없는 값까지 전부 확인하려면 아래 주석을 푸세요.

out.println("<h2>수신된 전체 응답</h2><table>");
for (Map.Entry<String, String> e : fields.entrySet()) {
    out.println("<tr><th>" + e.getKey() + "</th><td>" + e.getValue() + "</td></tr>");
}
out.println("</table>");

*/
%>

<p>이 페이지는 샘플입니다. 실제 연동에서는 결과를 화면에 노출하지 말고 DB에 기록하세요.</p>

</body>
</html>
