<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%--
 * [빌링키 확인 페이지]  토스페이먼츠 XPay — UTF-8
 *
 * 인증 결과와 발급된 빌링키(LGD_BILLKEY)를 확인하고 저장한다.
 * 빌링키는 카드 정보에 준하는 민감 정보이므로 암호화해서 저장하고 화면이나 로그에 남기지 않는다.
 * 이후 결제는 card-billing 샘플처럼 LGD_PAN 에 빌링키를 넣어 CardAuth 로 요청한다.
--%>
<%
    request.setCharacterEncoding("UTF-8");

    String LGD_RESPCODE = request.getParameter("LGD_RESPCODE");
    String LGD_BILLKEY  = request.getParameter("LGD_BILLKEY");
    boolean success = "0000".equals(LGD_RESPCODE) && LGD_BILLKEY != null && !"".equals(LGD_BILLKEY);

    if (success) {
        // 인증 성공. LGD_BILLKEY 를 구매자 정보와 함께 암호화해서 DB 에 저장하세요.
    } else {
        // 인증 실패 결과를 기록하세요.
    }

    /* ==================================================================
     * 인증 응답 파라미터
     * ==================================================================
     * 주요 값은 활성, 나머지는 주석 처리해 두었습니다.
     * 필요한 줄의 // 만 지우면 화면에 함께 출력됩니다.
     */
    String[][] show = {
        { "LGD_RESPCODE",    "응답코드. 0000 이면 성공" },
        { "LGD_RESPMSG",     "응답메시지. 최대 160자" },
        { "LGD_BILLKEY",     "빌링키. 최대 128자. 이후 결제 시 카드번호 대신 사용" },
        { "LGD_PAYTYPE",     "결제수단코드" },
        { "LGD_PAYDATE",     "인증일시. yyyyMMddHHmmss" },
        { "LGD_FINANCECODE", "결제기관코드" },
        { "LGD_FINANCENAME", "결제기관명" },

        /* ===== 카드 추가정보 ===== */
        // { "LGD_MID",          "상점아이디" },
        // { "LGD_CARDNUM",      "신용카드번호. 일반 가맹점은 * 처리" },
        // { "LGD_CARDGUBUN1",   "0 개인 / 1 법인 / 9 미확인" },
        // { "LGD_CARDGUBUN2",   "0 신용 / 1 체크 / 2 기프트 / 9 미확인" },
        // { "LGD_CARDACQUIRER", "카드 매입사 코드" },
    };
%>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>XPay 빌링키 발급 결과</title>
<style>
  body { font-family: sans-serif; font-size: 14px; max-width: 860px; margin: 20px; }
  table { border-collapse: collapse; }
  th, td { border: 1px solid #ccc; padding: 4px 8px; text-align: left; vertical-align: top; }
</style>
</head>
<body>

<h1>빌링키 발급 결과</h1>

<p><%= success ? "빌링키 발급 성공" : "빌링키 발급 실패" %></p>

<table>
  <tr><th>변수명</th><th>설명</th><th>값</th></tr>
<% for (String[] f : show) { String v = request.getParameter(f[0]); %>
  <tr>
    <th><%= f[0] %></th>
    <td><%= f[1] %></td>
    <td><%= (v != null) ? v : "" %></td>
  </tr>
<% } %>
</table>

<p>이 페이지는 샘플입니다. 실제 연동에서는 빌링키를 화면에 노출하지 말고 암호화해서 저장하세요.</p>

</body>
</html>
