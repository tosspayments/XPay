# Java(JSP) 샘플

JSP로 작성된 XPayClient 연동 샘플입니다. `webapp`은 그대로 배포할 수 있는 웹 애플리케이션이며, 공통 라이브러리를 한 곳(`WEB-INF/lib`)에 두고 기능별 샘플을 폴더로 나누었습니다.

## XPayClient 빌드 선택

XPayClient 4.1.0.0 은 서버 JDK 에 따라 두 가지 빌드가 있습니다. JSP 페이지는 같고, `WEB-INF/lib`의 라이브러리와 `mall.conf` 설정만 다릅니다.

| 서버 JDK | 빌드 | HttpClient | `mall.conf`의 `tx_version` | 배포용 패키지 |
| --- | --- | --- | --- | --- |
| JDK 1.8 ~ 17 | JDK 1.8 ~ 17 빌드 | 3.x, 4.x | `tx_version = 4` (4.x 사용) | `xpay-samples-java-jdk1.8-17.zip` |
| JDK 1.7 | JDK 1.7 전용 빌드 | 3.x 만 | 쓰지 않음 | `xpay-samples-java-jdk1.7.zip` |

- **배포용 패키지로 받은 경우:** `webapp/WEB-INF/lib`와 `lgdacom/conf/mall.conf.example`에 해당 JDK 용 파일이 이미 들어 있습니다. 아래 설치 순서대로 진행합니다.
- **저장소에서 받은 경우:** `webapp/WEB-INF/lib`에는 JDK 1.8 ~ 17 빌드가 들어 있습니다. JDK 1.7 서버는 [JDK 1.7 에서 사용하기](#jdk17)를 참고합니다.

## 요구 사항

- JDK 1.7 또는 JDK 1.8 ~ 17
- Tomcat 등 서블릿 컨테이너
- TLS 1.2 통신. JDK 1.7 은 버전에 따라 TLS 1.2 가 기본으로 켜져 있지 않을 수 있으므로 `mall.conf`의 `default_secure_protocols = 2048`(TLS 1.2)을 유지합니다.
- 상점 서버에서 XPay 게이트웨이로 나가는 443 포트 허용 (연동 가이드의 방화벽 및 IP 정보 참고)

## 설치

### 1. 설정 폴더 배치

`lgdacom` 폴더를 **웹에서 접근할 수 없는 경로**에 복사합니다. 샘플은 `C:/lgdacom`을 기준으로 작성되어 있습니다.

```text
C:/lgdacom/
├── conf/
│   ├── lgdacom.conf
│   └── mall.conf          ← mall.conf.example을 복사해서 만듭니다.
└── log/                   ← 로그가 저장됩니다. 폴더가 있어야 로그가 쌓입니다.
```

Linux나 macOS처럼 다른 경로를 쓰는 경우, 아래 파일 맨 위 "상점 설정"의 `configPath` 값을 실제 경로로 바꿉니다.

- `webapp/acc-cert/AccCert.jsp`
- `webapp/cancel/Cancel.jsp`
- `webapp/card-billing/CardAuth.jsp`
- `webapp/card-keyin/CardAuth.jsp`
- `webapp/cash-receipt/CashReceipt.jsp`
- `webapp/mobile-billing/MobileBilling.jsp`
- `webapp/search/Search.jsp`
- `webapp/settlement/Settlement.jsp`
- `webapp/split-settlement/CancelRefund.jsp`
- `webapp/split-settlement/payreq_crossplatform.jsp`
- `webapp/split-settlement/payres.jsp`
- `webapp/unified-checkout/mobile/payreq_crossplatform.jsp`
- `webapp/unified-checkout/mobile/payres.jsp`
- `webapp/unified-checkout/pc/payreq_crossplatform.jsp`
- `webapp/unified-checkout/pc/payres.jsp`
- `webapp/virtual-account/CyberAccount.jsp`
- `webapp/virtual-account/cas_noteurl.jsp`

### 2. mall.conf 작성

`mall.conf.example`을 `mall.conf`로 복사하고 아래 값을 확인합니다.

- 맨 아래 `MID = mertkey`: 서비스 MID와 테스트 MID(앞에 `t`)를 함께 등록합니다. mertkey는 토스페이먼츠 개발자센터에서 확인합니다.
- `output_UTF8 = 1`: 샘플은 모두 UTF-8 이므로 이 값을 바꾸지 않습니다.
- `log_dir`: 1단계에서 만든 `log` 폴더의 전체 경로
- `tx_version = 4`: JDK 1.8 ~ 17 빌드에서 HttpClient 4.x 를 씁니다. 지우면 HttpClient 3.x 로 동작합니다. JDK 1.7 용 예시 파일에는 이 줄이 없습니다.
- `keystore_cacerts_dir`: 비워 두면 JDK 기본 `cacerts`로 서버 인증서를 검증합니다. (권장) 다른 신뢰 저장소를 쓸 때만 경로를 지정하며, 지정한 경로에 파일이 없으면 오류가 납니다.

`lgdacom.conf`의 게이트웨이 주소는 바꾸지 않습니다.

### 3. 배포와 실행

`webapp` 폴더를 서블릿 컨테이너에 배포합니다. 예를 들어 Tomcat의 `webapps/xpay`로 복사하면 `http://localhost:8080/xpay/index.html`에서 기능별 샘플을 선택할 수 있습니다.

결과수신 주소(`LGD_RETURNURL`, `LGD_CASNOTEURL`)는 각 요청 페이지 맨 위 "상점 설정"에 `https://상점도메인/xpay/...` 형태로 들어 있습니다. 배포한 실제 주소로 바꿉니다. 가상계좌 입금통보는 표준 포트(80, 443)로만 받을 수 있습니다. 기능별로 수정할 값은 각 폴더의 `README.md`를 참고합니다.

## JDK 1.7 에서 사용하기 {#jdk17}

저장소에서 받은 샘플을 JDK 1.7 서버에 배포할 때는 두 가지를 바꿉니다. 배포용 패키지(`xpay-samples-java-jdk1.7.zip`)는 이미 바뀌어 있습니다.

1. `webapp/WEB-INF/lib`의 jar 를 모두 지우고 `lib-jdk1.7`의 jar 를 넣습니다. 두 빌드의 jar 가 섞이면 어느 쪽이 로드될지 알 수 없으므로 반드시 모두 지운 뒤 넣습니다.
2. `lgdacom/conf/mall.conf.jdk1.7.example`을 `mall.conf`로 복사해서 씁니다. (`tx_version` 없음)

JDK 1.7 빌드는 `tx_version = 4`가 있어도 HttpClient 3.x 로 동작하고 로그에 경고를 남깁니다.

## 라이브러리

XPayClient 는 두 빌드 모두 4.1.0.0 입니다. 공개 API 와 해시 계산 결과는 4.0.0.x 와 같습니다.

**JDK 1.8 ~ 17 (`webapp/WEB-INF/lib`)**

| 파일 | 버전 | 비고 |
| --- | --- | --- |
| `XPayClient.jar` | 4.1.0.0 (JDK 1.8 ~ 17 빌드) | API 호출 라이브러리 |
| `commons-httpclient-3.1.jar` | 3.1 | HttpClient 3.x (`tx_version`이 4 가 아닐 때) |
| `httpclient-4.5.14.jar` | 4.5.14 | HttpClient 4.x (`tx_version = 4`) |
| `httpcore-4.4.16.jar` | 4.4.16 | HttpClient 4.x |
| `commons-codec-1.16.0.jar` | 1.16.0 | 공통 |
| `commons-logging-1.3.0.jar` | 1.3.0 | 공통 |
| `json_simple.jar` | - | 공통 |

**JDK 1.7 (`lib-jdk1.7`)**

| 파일 | 버전 | 비고 |
| --- | --- | --- |
| `XPayClient.jar` | 4.1.0.0 (JDK 1.7 빌드) | API 호출 라이브러리 |
| `commons-httpclient-3.1.jar` | 3.1 | HttpClient 3.x |
| `commons-codec-1.3.jar` | 1.3 | 공통 |
| `commons-logging.jar` | - | 공통 |
| `json_simple.jar` | - | 공통 |

라이브러리는 모든 샘플이 함께 사용합니다. 기능별 샘플 폴더에 jar 를 따로 두지 않습니다. XPayClient 외 라이브러리는 모두 Apache License 2.0 입니다.

## 폴더 구성

```text
java/
├── lgdacom/conf/              # lgdacom.conf, mall.conf.example (JDK 1.8 ~ 17), mall.conf.jdk1.7.example
├── lib-jdk1.7/                # JDK 1.7 빌드와 라이브러리 (저장소에만 있음)
└── webapp/                    # 아래 구성

webapp/
├── index.html                 # 기능 선택 페이지
├── WEB-INF/lib/               # 라이브러리
├── unified-checkout/pc/       # 통합결제창 결제 (PC)
├── unified-checkout/mobile/   # 통합결제창 결제 (모바일)
├── virtual-account/           # 가상계좌 발급·변경(CyberAccount), 결과수신(cas_noteurl)
├── cancel/                    # 취소
├── cash-receipt/              # 현금영수증 발급·취소
├── card-keyin/                # 카드 비인증 결제
├── card-billing/              # 카드 빌링 결제
├── card-billing-window/       # 결제창 빌링키 발급 (PC), mobile/ (모바일)
├── mobile-billing/            # 휴대폰 빌링 결제
├── split-settlement/          # 분할정산 결제·취소
├── acc-cert/                  # 계좌 유효성 확인
├── search/                    # 거래 조회
└── settlement/                # 수동정산
```

## 샘플 작성 규칙

- 모든 파일은 UTF-8 이며, 외부 CSS 없이 한 파일 안에서 동작합니다.
- 각 JSP 맨 위의 "상점 설정 ★ 이 줄만 수정하세요" 부분만 바꾸면 실행할 수 있습니다.
- 요청 파라미터는 필수 값과 샘플 실행에 필요한 고정값만 활성되어 있습니다. 선택 파라미터는 모두 주석으로 넣어 두었으니, 필요한 줄의 주석을 풀고 입력 화면(`.html`)에도 같은 이름의 입력란을 추가합니다.
- 결과 페이지의 `show` 배열에는 주요 응답값만 활성되어 있습니다. 필요한 줄의 `//`만 지우면 화면에 함께 출력됩니다.
- 해시는 XPayClient 의 `GetHashData()`, `GetHashDataCas()`로 만들기 때문에 코드에 mertkey를 쓰지 않습니다. mertkey는 `mall.conf`에만 둡니다.
- 입력값 검증, 화면 출력 시 이스케이프 같은 문자열 처리는 넣지 않았습니다. 가맹점 환경에 맞게 구현합니다.

## 배포용 패키지 만들기

저장소 루트에서 아래 명령을 실행하면 `dist/`에 JDK 별 배포용 zip 이 만들어집니다. (zip 명령 필요)

```bash
tools/package-java.sh
```

| 파일 | 내용 |
| --- | --- |
| `dist/xpay-samples-java-jdk1.8-17.zip` | `webapp` 그대로, `mall.conf.example`에 `tx_version = 4` |
| `dist/xpay-samples-java-jdk1.7.zip` | `WEB-INF/lib`를 `lib-jdk1.7`로 바꾸고, `tx_version`이 없는 `mall.conf.example` |

